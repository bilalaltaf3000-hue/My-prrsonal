"""Data capture by function POCs: each employee's region, and the activities each employee performs."""
import uuid
from datetime import datetime
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..logic import (FREQUENCIES, vol_type_value, freq_names, HANDLING, NATURE_LEGACY, nature_label, nature_value, SERVICE_TYPES, Calc, employee_work, function_heads, function_payload,
                     function_summary, items_by_employee, link_counts, missing_fields, ser_item, summarise)
from ..security import audit, can_edit_function, can_read_function, current_user, input_ids, read_ids, unit_scope, view_ids

router = APIRouter(prefix="/api/capture")


# ---------- helpers ----------
def _fn(db: Session, fid: int, user: models.User, edit: bool = False) -> models.Function:
    fn = db.get(models.Function, fid)
    if not fn:
        raise HTTPException(404, "Function not found.")
    if not can_read_function(user, fid):
        raise HTTPException(403, "You do not have access to this function.")
    if edit and not can_edit_function(user, fn):
        raise HTTPException(403, "You have view-only access to this function.")
    return fn


def _units_for(user, fn) -> Optional[set]:
    """Units a dashboard-only login sees in this function (None = the whole function). Logins that can fill in
    the function always see all of it."""
    if can_edit_function(user, fn):
        return None
    us = unit_scope(user)
    return us.get(fn.id) if us else None


def _whole_function(user, fn):
    """Pages that cover the whole function are closed to a login limited to some of its units."""
    if _units_for(user, fn) is not None:
        raise HTTPException(403, "This login sees only some units of this function.")


def _touch(fn: models.Function):
    if fn.status == "Not started":
        fn.status = "In progress"
        fn.status_at = datetime.utcnow()


def _emp(db, fid, code) -> models.Employee:
    e = db.get(models.Employee, code)
    if not e or e.function_id != fid:
        raise HTTPException(404, "Employee not in this function.")
    return e


def _item(db, iid, user, edit=True):
    w = db.get(models.WorkItem, iid)
    if not w:
        raise HTTPException(404, "Activity not found.")
    e = db.get(models.Employee, w.employee_code)
    if not e or not e.function_id:
        raise HTTPException(404, "Employee not found.")
    fn = _fn(db, e.function_id, user, edit=edit)
    return w, e, fn


def _emp_out(db, e, c=None):
    c = c or Calc(db, e.function_id)
    items = items_by_employee(db, codes={e.code}).get(e.code, [])
    out = {"code": e.code}
    out.update(summarise(items, c, e.service_role or ""))
    return out


# ---------- read ----------
@router.get("/functions")
def functions(user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    rows = function_summary(db)
    readable, editable, viewable = read_ids(user, db), input_ids(user, db), view_ids(user, db)
    out = []
    for r in rows:
        if r["id"] in readable:
            r["can_edit"] = r["id"] in editable
            r["can_view_dashboard"] = r["id"] in viewable
            out.append(r)
    return out


@router.get("/employee/{code}")
def employee_detail(code: str, user=Depends(current_user), db: Session = Depends(get_db)):
    e = db.get(models.Employee, code)
    if not e or not e.function_id:
        raise HTTPException(404, "Employee not found.")
    fn = _fn(db, e.function_id, user)
    us = _units_for(user, fn)
    if us is not None and (e.unit_name or "") not in us:
        raise HTTPException(403, "This employee is outside your units.")
    data = employee_work(db, fn)
    row = next((x for x in data["employees"] if x["code"] == code), None)
    return {"settings": data["settings"], "function": data["function"], "employee": row}


@router.get("/{fid}/employees")
def employees_work(fid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user)
    data = employee_work(db, fn)
    us = _units_for(user, fn)
    if us is not None:
        data["employees"] = [x for x in data["employees"] if x["unit"] in us]
    return data


class PdfIn(BaseModel):
    codes: Optional[List[str]] = None


@router.post("/{fid}/activities-pdf")
def activities_pdf(fid: int, body: PdfIn, user=Depends(current_user), db: Session = Depends(get_db)):
    """Employee activities as a PDF: each employee's organogram, then their activities. Several employees
    get a cover page and a table of contents. Function 0 = every function this login can read."""
    import io
    from fastapi.responses import StreamingResponse
    from ..emppdf import build_pdf
    if fid:
        fns = [_fn(db, fid, user)]
    else:
        ok = read_ids(user, db)
        fns = [f for f in db.query(models.Function).order_by(models.Function.name) if f.id in ok]
        if not fns:
            raise HTTPException(403, "You do not have access to any function.")
    codes = [c for c in (body.codes or []) if c][:5000] or None
    uscope = {f.id: _units_for(user, f) for f in fns}
    if any(v is not None for v in uscope.values()):   # a unit login: only employees of its units
        inside = {e.code for e in db.query(models.Employee).filter(models.Employee.function_id.in_(list(uscope)))
                  if uscope.get(e.function_id) is None or (e.unit_name or "") in uscope[e.function_id]}
        codes = [c for c in (codes or sorted(inside)) if c in inside] or None
        if not codes:
            raise HTTPException(400, "None of these employees can be exported.")
    ids = {f.id for f in fns}
    if codes and not db.query(models.Employee).filter(models.Employee.code.in_(codes[:999]), models.Employee.function_id.in_(ids)).first():
        raise HTTPException(400, "None of these employees can be exported.")
    data = build_pdf(db, fns, codes, user.full_name or user.username)
    who = fns[0].name if len(fns) == 1 else "Operations_Services"
    if codes and len(codes) == 1:
        e = db.get(models.Employee, codes[0])
        who = e.name if e else who
    audit(db, user, "export_activities_pdf", f"{who}: {len(codes) if codes else 'all'} employees")
    db.commit()
    safe = "".join(ch if ch.isalnum() else "_" for ch in who)[:50].strip("_") or "employees"
    return StreamingResponse(io.BytesIO(data), media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename={safe}_activities_{datetime.now():%Y%m%d}.pdf"})


@router.get("/{fid}")
def get_function(fid: int, user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user)
    _whole_function(user, fn)
    return function_payload(db, fn)


# ---------- staff and regions ----------
ROLES = ("Service", "Support")


class StaffIn(BaseModel):
    region: Optional[str] = None
    unit: Optional[str] = None
    service_role: Optional[str] = None
    cascade: bool = False   # also apply to everyone below this person who has not been set individually


def _region_ok(db, region):
    if region and not db.query(models.Region).filter(models.Region.name == region).first():
        raise HTTPException(400, "Unknown region. Ask the admin to add it.")


def _cascade(db, fid, e, field, src_field, value):
    """Set field on everyone below e in this function. People set individually keep their value,
    and their own team follows them instead."""
    kids = {}
    for x in db.query(models.Employee).filter(models.Employee.function_id == fid):
        if x.manager_code:
            kids.setdefault(x.manager_code, []).append(x)
    n = 0
    stack = list(kids.get(e.code, []))
    while stack:
        x = stack.pop()
        if getattr(x, src_field) == "manual" and getattr(x, field) and getattr(x, field) != value:
            continue
        setattr(x, field, value)
        setattr(x, src_field, "inherited" if value else None)
        n += 1
        stack.extend(kids.get(x.code, []))
    return n


@router.patch("/{fid}/staff/{code}")
def edit_staff(fid: int, code: str, body: StaffIn, user=Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user, edit=True)
    e = _emp(db, fid, code)
    moved = 0
    if body.region is not None:
        _region_ok(db, body.region)
        e.region = body.region or None
        e.region_source = "manual" if body.region else None
        if body.cascade:
            moved = max(moved, _cascade(db, fid, e, "region", "region_source", e.region))
    if body.unit is not None:
        if e.code in function_heads(db, fid):
            raise HTTPException(400, "The function head covers all units and does not need one.")
        u = " ".join(body.unit.split())[:200] or None
        e.unit_name = u
        e.unit_name_source = "manual" if u else None
        if body.cascade:
            moved = max(moved, _cascade(db, fid, e, "unit_name", "unit_name_source", u))
    if body.service_role is not None:
        if body.service_role not in ROLES + ("",):
            raise HTTPException(400, "Choose Service or Support.")
        e.service_role = body.service_role or None
        e.service_role_source = "manual" if body.service_role else None
        if body.cascade:
            moved = max(moved, _cascade(db, fid, e, "service_role", "service_role_source", e.service_role))
    _touch(fn)
    if body.cascade:
        audit(db, user, "staff_cascade", f"{code}: region {body.region}, unit {body.unit}, type {body.service_role}, {moved} people followed")
    db.commit()
    out = function_payload(db, fn)
    out["followed"] = moved
    return out


class BulkIn(BaseModel):
    region: Optional[str] = None
    unit: Optional[str] = None
    service_role: Optional[str] = None
    emp_type: Optional[str] = None   # FTE / FTC
    codes: List[str] = []       # empty = everyone in the function
    only_empty: bool = False    # keep values already set


@router.post("/{fid}/regions")
def set_bulk(fid: int, body: BulkIn, user=Depends(current_user), db: Session = Depends(get_db)):
    """Set one region and/or unit for the ticked employees (or everyone), then change exceptions individually."""
    fn = _fn(db, fid, user, edit=True)
    if body.region is not None:
        _region_ok(db, body.region)
    unit = " ".join(body.unit.split())[:200] if body.unit is not None else None
    wanted = set(body.codes)
    heads = function_heads(db, fid)
    n = 0
    for e in db.query(models.Employee).filter(models.Employee.function_id == fid, models.Employee.resigned != True):  # noqa
        if wanted and e.code not in wanted:
            continue
        hit = False
        if body.region is not None and not (body.only_empty and e.region):
            e.region, e.region_source = body.region or None, ("manual" if body.region else None)
            hit = True
        if unit is not None and e.code not in heads and not (body.only_empty and e.unit_name):  # heads cover all units
            e.unit_name, e.unit_name_source = unit or None, ("manual" if unit else None)
            hit = True
        if body.service_role is not None and body.service_role in ROLES + ("",) and not (body.only_empty and e.service_role):
            e.service_role, e.service_role_source = body.service_role or None, ("manual" if body.service_role else None)
            hit = True
        if body.emp_type in ("FTE", "FTC") and e.emp_type != body.emp_type:
            e.emp_type = body.emp_type
            e.overrides = sorted(set(e.overrides or []) | {"emp_type"})   # kept at the next master sheet import
            hit = True
        n += hit
    _touch(fn)
    audit(db, user, "staff_bulk", f"{fn.name}: {n} people, region {body.region}, unit {unit}, type of work {body.service_role}, type {body.emp_type}")
    db.commit()
    out = function_payload(db, fn)
    out["updated"] = n
    return out


class CheckIn(BaseModel):
    code: str
    name: str = ""


@router.post("/{fid}/check-employee")
def check_employee(fid: int, body: CheckIn, user=Depends(current_user), db: Session = Depends(get_db)):
    _fn(db, fid, user, edit=True)
    code = body.code.strip()
    if not code:
        raise HTTPException(400, "Enter the employee code.")
    e = db.get(models.Employee, code) or db.query(models.Employee).filter(models.Employee.code.ilike(code)).first()
    if e and e.function_id == fid:
        return {"result": "same_function", "employee": {"code": e.code, "name": e.name, "region": e.region}}
    if e:
        other = db.get(models.Function, e.function_id)
        mgr = db.get(models.Employee, e.manager_code) if e.manager_code else None
        pending = db.query(models.RetagRequest).filter(models.RetagRequest.code == e.code, models.RetagRequest.to_function_id == fid,
                                                        models.RetagRequest.status == "Pending").first()
        return {"result": "other_function", "employee": {"code": e.code, "name": e.name, "grade": e.grade,
                "function": other.name if other else None, "manager": mgr.name if mgr else None}, "pending": bool(pending)}
    words = [w for w in body.name.lower().split() if len(w) > 2]
    similar = []
    if words:
        q = db.query(models.Employee)
        for w in words:
            q = q.filter(models.Employee.name.ilike(f"%{w}%"))
        for s in q.limit(5):
            f = db.get(models.Function, s.function_id)
            similar.append({"code": s.code, "name": s.name, "function": f.name if f else None})
    return {"result": "similar" if similar else "new", "similar": similar}


class AddEmpIn(BaseModel):
    code: str
    name: str
    grade: str = ""
    position: str = ""
    emp_type: str = "FTE"
    region: Optional[str] = None
    unit: Optional[str] = None
    manager_code: Optional[str] = None


@router.post("/{fid}/employees")
def add_employee(fid: int, body: AddEmpIn, user=Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user, edit=True)
    code = body.code.strip()
    if not code or not body.name.strip():
        raise HTTPException(400, "Employee code and name are both required.")
    if db.get(models.Employee, code):
        raise HTTPException(409, "This employee code already exists. Use a re-tagging request instead.")
    _region_ok(db, body.region)
    mgr = (body.manager_code or "").strip() or None
    if mgr and not db.get(models.Employee, mgr):
        raise HTTPException(400, "Manager code not found.")
    from ..importer import grade_label, grade_rank, is_outsourced
    raw_g = body.grade.strip()[:80]   # labelled as at import: outsourced staff show as FTC
    db.add(models.Employee(code=code, name=body.name.strip(), grade=grade_label(raw_g) if raw_g else "Not verified", grade_raw=raw_g,
                           grade_rank=grade_rank(raw_g) if raw_g else -2, position=body.position.strip(), function_id=fid,
                           emp_type="FTC" if (body.emp_type == "FTC" or is_outsourced(raw_g)) else "FTE",
                           source="added", verified=False, region=body.region or None, region_source="manual" if body.region else None,
                           unit_name=(body.unit or "").strip()[:200] or None, unit_name_source="manual" if (body.unit or "").strip() else None,
                           manager_code=mgr, added_by=user.username, added_at=datetime.utcnow()))
    _touch(fn)
    audit(db, user, "employee_add", f"{fn.name}: {code} {body.name}")
    db.commit()
    return function_payload(db, fn)


class ManagerReqIn(BaseModel):
    code: str
    manager_code: str
    note: str = ""


@router.post("/{fid}/manager-request")
def manager_request(fid: int, body: ManagerReqIn, user=Depends(current_user), db: Session = Depends(get_db)):
    """A POC asks for an employee's reporting line to change. The admin approves it in Admin, Requests."""
    from .staffadmin import _would_loop
    fn = _fn(db, fid, user, edit=True)
    e = _emp(db, fid, body.code.strip())
    m = body.manager_code.strip()
    if not db.get(models.Employee, m):
        raise HTTPException(400, "No employee has that manager code.")
    if m == e.code or _would_loop(db, e.code, m):
        raise HTTPException(400, "That would create a circular reporting line.")
    if m == e.manager_code:
        raise HTTPException(400, "This employee already reports to that manager.")
    for r in db.query(models.RetagRequest).filter(models.RetagRequest.code == e.code, models.RetagRequest.kind == "manager",
                                                 models.RetagRequest.status == "Pending"):
        r.status, r.resolved_by, r.resolved_at = "Replaced", user.username, datetime.utcnow()
    db.add(models.RetagRequest(kind="manager", code=e.code, from_function_id=fid, to_function_id=fid, from_manager=e.manager_code,
                               to_manager=m, requested_by=user.username, note=body.note[:300]))
    audit(db, user, "manager_request", f"{e.code}: {e.manager_code} -> {m}")
    db.commit()
    return function_payload(db, fn)


class RetagIn(BaseModel):
    code: str
    note: str = ""


@router.post("/{fid}/retag")
def retag(fid: int, body: RetagIn, user=Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user, edit=True)
    e = db.get(models.Employee, body.code.strip())
    if not e:
        raise HTTPException(404, "Employee code not found.")
    if e.function_id == fid:
        raise HTTPException(400, "This employee is already in your function.")
    exists = db.query(models.RetagRequest).filter(models.RetagRequest.code == e.code, models.RetagRequest.to_function_id == fid,
                                                   models.RetagRequest.status == "Pending").first()
    if not exists:
        db.add(models.RetagRequest(code=e.code, from_function_id=e.function_id, to_function_id=fid, requested_by=user.username, note=body.note[:300]))
        audit(db, user, "retag_request", f"{e.code} to {fn.name}")
    _touch(fn)
    db.commit()
    return function_payload(db, fn)


# ---------- activities ----------
TEXT = {"unit": 200, "product": 200, "process": 250, "channel": 200, "category": 200}


class ItemIn(BaseModel):
    unit: Optional[str] = None
    product: Optional[str] = None
    process: Optional[str] = None
    channel: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    service_type: Optional[str] = None
    frequency: Optional[str] = None
    volume: Optional[float] = None
    volume_type: Optional[str] = None
    peak_som: Optional[float] = None
    peak_eom: Optional[float] = None
    handling: Optional[str] = None
    minutes: Optional[float] = None
    automation: Optional[str] = None
    clear: List[str] = []   # numeric fields to empty (volume, peak_som, peak_eom, minutes)


def _apply(w: models.WorkItem, body: ItemIn):
    d = body.model_dump(exclude_unset=True)
    for k, n in TEXT.items():
        if k in d and d[k] is not None:
            setattr(w, k, " ".join(d[k].split())[:n])
    if d.get("product") is not None:
        from .staffadmin import clean_products
        w.product = clean_products(d["product"])
    if d.get("description") is not None:
        w.description = d["description"].strip()[:4000]
    if d.get("service_type") is not None:
        if d["service_type"] not in SERVICE_TYPES + [""]:
            raise HTTPException(400, "Choose Service or Support.")
        w.service_type = d["service_type"]
    if d.get("frequency") is not None:
        if d["frequency"] not in freq_names():
            raise HTTPException(400, "Choose a frequency from the list.")
        w.frequency = d["frequency"]
    if d.get("handling") is not None:
        if d["handling"] not in HANDLING and d["handling"].strip().lower() in NATURE_LEGACY:   # the names before 2.11
            d["handling"] = NATURE_LEGACY[d["handling"].strip().lower()]
        d["handling"] = nature_value(d["handling"])   # an option the admin renamed or removed since
        if d["handling"] not in HANDLING + [""]:
            raise HTTPException(400, f"{nature_label()} must be one of: {', '.join(HANDLING)}.")
        w.handling = d["handling"]
    if d.get("volume_type") is not None:
        vt = vol_type_value(d["volume_type"])
        if vt is None:
            raise HTTPException(400, "Volume type must be file based or activity based.")
        w.volume_type = vt
    if d.get("automation") is not None:
        if d["automation"] not in ("Yes", "No", ""):
            raise HTTPException(400, "Automation opportunity must be Yes or No.")
        w.automation = d["automation"]
    for k in ("volume", "peak_som", "peak_eom", "minutes"):
        if d.get(k) is not None:
            if d[k] < 0:
                raise HTTPException(400, "Numbers cannot be negative.")
            setattr(w, k, float(d[k]))
    for k in body.clear:
        if k in ("volume", "peak_som", "peak_eom", "minutes"):
            setattr(w, k, None)
    w.updated_at = datetime.utcnow()


def _item_out(db, w, e, c=None):
    c = c or Calc(db, e.function_id)
    n = link_counts(db, [w.link_id]).get(w.link_id, 1) - 1 if w.link_id else 0
    return {"item": ser_item(w, c, n), "employee": _emp_out(db, e, c)}


@router.get("/{fid}/staff/{code}/items")
def list_items(fid: int, code: str, user=Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user)
    e = _emp(db, fid, code)
    us = _units_for(user, fn)
    if us is not None and (e.unit_name or "") not in us:
        raise HTTPException(404, "Employee not found")
    c = Calc(db, fid)
    items = items_by_employee(db, codes={code}).get(code, [])
    links = link_counts(db, [w.link_id for w in items])
    return {"employee": _emp_out(db, e, c), "items": [ser_item(w, c, links.get(w.link_id, 1) - 1 if w.link_id else 0) for w in items]}


@router.post("/{fid}/staff/{code}/items")
def add_item(fid: int, code: str, body: ItemIn, user=Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user, edit=True)
    e = _emp(db, fid, code)
    n = db.query(models.WorkItem).filter(models.WorkItem.employee_code == code).count()
    w = models.WorkItem(employee_code=code, frequency=freq_names()[0], sort=n + 1, created_by=user.username)
    _apply(w, body)
    db.add(w)
    _touch(fn)
    db.commit()
    return _item_out(db, w, e)


@router.patch("/items/{iid}")
def edit_item(iid: int, body: ItemIn, user=Depends(current_user), db: Session = Depends(get_db)):
    w, e, fn = _item(db, iid, user)
    _apply(w, body)
    _touch(fn)
    db.commit()
    return _item_out(db, w, e)


@router.delete("/items/{iid}")
def delete_item(iid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    w, e, fn = _item(db, iid, user)
    db.delete(w)
    db.commit()
    return {"employee": _emp_out(db, e)}


COPY_FIELDS = ("unit", "product", "process", "channel", "description", "category", "service_type", "frequency",
               "handling", "minutes", "automation", "volume_type")
VOLUME_FIELDS = ("volume", "peak_som", "peak_eom")


def _clone(src: models.WorkItem, code: str, user, with_volume=True, sort=0) -> models.WorkItem:
    w = models.WorkItem(employee_code=code, created_by=user.username, sort=sort)
    for f in COPY_FIELDS + (VOLUME_FIELDS if with_volume else ()):
        setattr(w, f, getattr(src, f))
    return w


@router.post("/items/{iid}/duplicate")
def duplicate_item(iid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    """A copy for the same employee (e.g. the same activity for another product or channel)."""
    w, e, fn = _item(db, iid, user)
    n = db.query(models.WorkItem).filter(models.WorkItem.employee_code == e.code).count()
    c = _clone(w, e.code, user, True, n + 1)
    db.add(c)
    db.commit()
    return _item_out(db, c, e)


class CopyIn(BaseModel):
    source: str
    targets: List[str]
    item_ids: List[int] = []                  # empty = all of the source's activities
    volume_mode: str = "same"                 # same / blank / region
    region_volumes: Dict[str, Dict[str, float]] = {}   # region -> {item id: volume}, for volume_mode "region"
    mode: str = "append"                      # append: add to their activities; replace: remove theirs first


@router.post("/{fid}/copy")
def copy_work(fid: int, body: CopyIn, user=Depends(current_user), db: Session = Depends(get_db)):
    """Give colleagues in the same function the same activities as one employee. The copies stay linked,
    so their volumes can be compared and set side by side, and later detail changes can be applied to all."""
    fn = _fn(db, fid, user, edit=True)
    src = _emp(db, fid, body.source)
    staff = {e.code: e for e in db.query(models.Employee).filter(models.Employee.function_id == fid)}
    targets = [t for t in dict.fromkeys(body.targets) if t in staff and t != src.code]
    if not targets:
        raise HTTPException(400, "Choose at least one colleague to copy to.")
    items = items_by_employee(db, codes={src.code}).get(src.code, [])
    if body.item_ids:
        want = set(body.item_ids)
        items = [w for w in items if w.id in want]
    if not items:
        raise HTTPException(400, "There are no activities to copy.")
    if body.volume_mode not in ("same", "blank", "region"):
        raise HTTPException(400, "Unknown volume option.")
    if body.mode not in ("append", "replace"):
        raise HTTPException(400, "Choose append or replace.")
    replaced = 0
    if body.mode == "replace":
        replaced = db.query(models.WorkItem).filter(models.WorkItem.employee_code.in_(targets)).delete(synchronize_session=False)
    for t in targets:   # service or support goes with the work, unless the colleague already has their own
        if src.service_role and not staff[t].service_role:
            staff[t].service_role, staff[t].service_role_source = src.service_role, "inherited"
    for w in items:
        if not w.link_id:
            w.link_id = uuid.uuid4().hex
    db.flush()
    have = {}
    for x in db.query(models.WorkItem).filter(models.WorkItem.employee_code.in_(targets)):
        have.setdefault(x.employee_code, []).append(x)
    created = skipped = 0
    for t in targets:
        mine = have.get(t, [])
        linked = {x.link_id for x in mine if x.link_id}
        n = len(mine)
        for w in items:
            if w.link_id in linked:
                skipped += 1
                continue
            n += 1
            c = _clone(w, t, user, body.volume_mode == "same", n)
            c.link_id = w.link_id
            if body.volume_mode == "region":
                reg = staff[t].region or ""
                v = (body.region_volumes.get(reg) or {}).get(str(w.id))
                c.volume = float(v) if v not in (None, "") else None
            db.add(c)
            created += 1
    _touch(fn)
    audit(db, user, "copy_work", f"{fn.name}: {src.code} -> {len(targets)} people, {len(items)} activities, {body.volume_mode}, {body.mode}")
    db.commit()
    return {"created": created, "skipped": skipped, "replaced": replaced, "people": len(targets), "activities": len(items),
            "link_ids": [w.link_id for w in items]}


class ClearIn(BaseModel):
    codes: List[str]


@router.post("/{fid}/clear")
def clear_work(fid: int, body: ClearIn, user=Depends(current_user), db: Session = Depends(get_db)):
    """Remove every activity of the chosen employees of the function, in one step."""
    fn = _fn(db, fid, user, edit=True)
    codes = {c for (c,) in db.query(models.Employee.code).filter(models.Employee.function_id == fid, models.Employee.code.in_(body.codes or ["-"]))}
    if not codes:
        raise HTTPException(400, "Choose at least one employee.")
    n = db.query(models.WorkItem).filter(models.WorkItem.employee_code.in_(codes)).delete(synchronize_session=False)
    _touch(fn)
    audit(db, user, "clear_work", f"{fn.name}: {n} activities of {len(codes)} employees removed")
    db.commit()
    out = function_payload(db, fn)
    out["removed"] = n
    return out


@router.get("/items/{iid}/linked")
def linked_items(iid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    """The same activity across colleagues, to compare and set volumes (e.g. different by region)."""
    w, e, fn = _item(db, iid, user, edit=False)
    us = _units_for(user, fn)
    if us is not None and (e.unit_name or "") not in us:
        raise HTTPException(404, "Activity not found.")
    if not w.link_id:
        rows = [w]
    else:
        rows = db.query(models.WorkItem).filter(models.WorkItem.link_id == w.link_id).all()
    c = Calc(db, fn.id)
    emps = {x.code: x for x in db.query(models.Employee).filter(models.Employee.code.in_([r.employee_code for r in rows]))}
    out = []
    for r in rows:
        x = emps.get(r.employee_code)
        if not x or x.function_id != fn.id or (us is not None and (x.unit_name or "") not in us):
            continue
        out.append({"id": r.id, "code": x.code, "name": x.name, "grade": x.grade, "region": x.region or "",
                    "volume": r.volume, "peak_som": r.peak_som, "peak_eom": r.peak_eom,
                    "daily_hours": round(c.daily_hours(r), 3), "same_details": all(getattr(r, f) == getattr(w, f) for f in COPY_FIELDS)})
    out.sort(key=lambda r: (r["region"] or "~", r["name"]))
    return {"item": ser_item(w, c, len(out) - 1), "rows": out}


class VolRow(BaseModel):
    id: int
    volume: Optional[float] = None
    peak_som: Optional[float] = None
    peak_eom: Optional[float] = None


class VolumesIn(BaseModel):
    rows: List[VolRow]


@router.put("/items/{iid}/linked")
def set_linked_volumes(iid: int, body: VolumesIn, user=Depends(current_user), db: Session = Depends(get_db)):
    w, e, fn = _item(db, iid, user)
    allowed = {w.id} if not w.link_id else {x.id for x in db.query(models.WorkItem.id).filter(models.WorkItem.link_id == w.link_id)}
    n = 0
    for r in body.rows:
        if r.id not in allowed:
            continue
        x = db.get(models.WorkItem, r.id)
        owner = db.get(models.Employee, x.employee_code)
        if not owner or owner.function_id != fn.id:
            continue
        for f in VOLUME_FIELDS:
            v = getattr(r, f)
            if v is not None and v < 0:
                raise HTTPException(400, "Volumes cannot be negative.")
            setattr(x, f, v)
        x.updated_at = datetime.utcnow()
        n += 1
    _touch(fn)
    audit(db, user, "linked_volumes", f"{fn.name}: {n} rows")
    db.commit()
    return linked_items(iid, user, db)


@router.post("/items/{iid}/sync")
def sync_linked(iid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    """Apply this activity's details (everything except volumes) to all its linked copies."""
    w, e, fn = _item(db, iid, user)
    if not w.link_id:
        return {"updated": 0}
    n = 0
    for x in db.query(models.WorkItem).filter(models.WorkItem.link_id == w.link_id, models.WorkItem.id != w.id):
        owner = db.get(models.Employee, x.employee_code)
        if not owner or owner.function_id != fn.id:
            continue
        for f in COPY_FIELDS:
            setattr(x, f, getattr(w, f))
        x.updated_at = datetime.utcnow()
        n += 1
    audit(db, user, "sync_linked", f"{fn.name}: activity {iid} to {n} copies")
    db.commit()
    return {"updated": n}


@router.post("/items/{iid}/unlink")
def unlink(iid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    w, e, fn = _item(db, iid, user)
    w.link_id = None
    db.commit()
    return _item_out(db, w, e)


# ---------- Excel template ----------
@router.get("/{fid}/template")
def template(fid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    """The function's employees and activities in an Excel template to fill in and upload."""
    from datetime import datetime as dt
    from ..logic import function_fields
    from .staffadmin import build_workbook, safe, xlsx_response
    fn = _fn(db, fid, user)
    _whole_function(user, fn)
    data = build_workbook(db, {fn.id: fn}, user, template=True, fields=function_fields(db, fid))
    return xlsx_response(data, f"{safe(fn.name)}_data_capture_{dt.now():%Y%m%d_%H%M}.xlsx")


@router.post("/{fid}/upload")
async def upload(fid: int, file: UploadFile = File(...), dry_run: bool = Form(True), user=Depends(current_user), db: Session = Depends(get_db)):
    from .staffadmin import import_data, read_workbook
    fn = _fn(db, fid, user, edit=True)
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload the filled template as an Excel file (.xlsx).")
    rep = import_data(db, read_workbook(await file.read()), user, dry_run=dry_run, only_fid=fid, apply_settings=False)
    if not dry_run:
        _touch(fn)
        audit(db, user, "template_upload", f"{fn.name}: {file.filename}, {rep['activities']} activities for {rep['employees_replaced']} employees")
        db.commit()
    return rep


# ---------- fields used by this function ----------
class FieldsIn(BaseModel):
    hidden: List[str]


@router.put("/{fid}/fields")
def set_fields(fid: int, body: FieldsIn, user=Depends(current_user), db: Session = Depends(get_db)):
    """The POC hides optional fields their function does not use. Required fields cannot be hidden."""
    from ..logic import field_config
    from ..security import set_setting
    fn = _fn(db, fid, user, edit=True)
    cfg = field_config(db)
    hidden = sorted({f for f in body.hidden if cfg.get(f) == "optional"})
    set_setting(db, f"hidden_fields:{fid}", hidden)
    audit(db, user, "fields", f"{fn.name}: hidden {', '.join(hidden) or 'none'}")
    db.commit()
    return function_payload(db, fn)


# ---------- review ----------
def review_issues(db: Session, fn: models.Function):
    from ..logic import active_staff
    staff = active_staff(db, fn.id)
    heads = function_heads(db, fn.id, staff)
    work = items_by_employee(db, fn.id)
    issues, notes = [], []
    no_role = [e for e in staff if not e.service_role]
    if no_role:
        issues.append(f"{len(no_role)} employees are not marked as service or support yet (step 2, at the top of each employee).")
    no_region = [e for e in staff if not e.region]
    if no_region:
        issues.append(f"{len(no_region)} employees do not have a region yet (step 1).")
    no_unit = [e for e in staff if not e.unit_name and e.code not in heads]
    if no_unit and any(e.unit_name for e in staff):   # units are optional; only flag gaps once the function uses them
        notes.append(f"{len(no_unit)} employees do not have a unit (step 1). Units are optional; leave them blank if the function does not use units.")
    bad = [(e, w) for e in staff for w in work.get(e.code, []) if missing_fields(w, fn.id)]
    if bad:
        issues.append(f"{len(bad)} activities are missing required details (across {len({e.code for e, _ in bad})} employees).")
    none = [e for e in staff if e.code not in heads and not work.get(e.code)]
    if none:
        notes.append(f"{len(none)} employees have no activities recorded.")
    return issues, notes


@router.get("/{fid}/review")
def review(fid: int, user=Depends(current_user), db: Session = Depends(get_db)):
    fn = _fn(db, fid, user)
    _whole_function(user, fn)
    b, w = review_issues(db, fn)
    return {"blocking": b, "warnings": w}
