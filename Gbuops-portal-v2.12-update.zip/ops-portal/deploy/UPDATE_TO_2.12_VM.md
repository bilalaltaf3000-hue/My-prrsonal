# Updating the VM to version 2.12 (keeps all captured data)

This update replaces **the code only**. The database (`portal.db`), `secret.key`, the SSL certificate and the Python environment (`venv`) stay as they are. Nobody needs a new password, and no `pip install` is needed.

On first start, version 2.12 adds new columns (`work_items.volume_type`, `users.can_decisions`, `users.can_emp_changes`, and `employees.hr_manager_code` / `hr_function_id`, which hold the manager and function **as per HR**) and two new tables, `decisions` (Recommendations) and `vacancies`. Every existing activity starts as **Activity Based**. No existing value is changed.

What is new:

- **Short volume figures** on the dashboard pages: 950, 1.5K, 150K, 1.2M, 16.9M. Hover over a figure to see the exact number.
- **Volume type:** each activity's volume is **File Based** (for example, the rows of an uploaded file) or **Activity Based**.
  - Set it in Data Capture, in the template, or in the Review in Excel file.
  - Avg Daily Volume shows the two side by side, never added together. This shows on the Dashboard Activities box, the Activity Insights card and the volume charts.
  - To rename either type, use Admin → Labels ("File Based", "Activity Based").
- **Dashboard, Activities section:**
  - an **FTE / FTC** filter;
  - **View All Themes** to see every theme, not only the top 10;
  - each theme shows how many **functions** it covers and its employees split into **FTE / FTC**;
  - volumes show as two figures, activity based and file based, never as a total.
- **Filter bar when a theme or category is opened** (Dashboard and Activity Insights):
  - **Function** (only the functions that have activities in the theme opened); once a function is picked, **Unit** appears. With one function on show, only Unit is offered.
  - **All Activities / Volume Based / Non Volume Based**; once Volume Based is picked, **Activity Based / File Based** appears.
  - The bar starts from what was clicked.
- **Recommendations** (a button above Share Feedback):
  - Record recommendations for each function: date, subject, the recommendation and its status (**Recommended**, Approved, Implemented or On hold).
  - Search and filter by function, and download to Excel.
  - Only the admin and logins given **Recommendations** access can see them (Admin → Users → Edit access; the HR / executive preset ticks it).
  - Others can edit or delete only the recommendations they recorded; the admin can change all of them.
- **Access:** Recommendations and Employee Changes are two separate ticks in Admin → Users → Edit access. The HR / executive preset ticks both. Logins that had the single tick in an earlier 2.12 package keep both.
- **Employee Changes** (a new page in the menu, for the admin and logins given **Employee Changes** access): what differs here from the HR master sheet, so HR can update its record. Filter by function, search, and download all the lists to Excel.
  - **Reporting Line Changes:** the manager as per HR and the manager now.
  - **Function Changes:** the function as per HR and the function now.
  - **Not in HR Record:** employees added here who exist but are not in the HR sheet.
  - **Marked Resigned:** resigned here, still in the HR sheet.
  - **To Be Hired:** the open vacant positions.

  When HR's next master sheet includes a change, it leaves the page by itself.
- **Full Export (HR Sheet Format)** (on Employee Changes): the full employee list in the HR master sheet's own columns and order, as it is in the portal now. It has every column, from N Employee No through the N-1 to N-7 managers to Comments. Two columns are added at the end:
  - **Portal Change:** one of five: **Line manager changed**, **Function changed**, **Resigned**, **Added** (working, not in the HR record) or **To be hired**.
  - **Change Details:** what it was and what it is now, for example *Line manager: 623188 Faisal Muhammad Amin -> 443502 Abdul Aleem Khan*.

  How the rows are filled:
  - Rows with no change keep the HR sheet's values; only the team size, layers and higher managers are kept up to date when someone above moves.
  - For a changed line, the manager columns, Layers, Hierarchy Path and Direct Span of Control are worked out again. The changed cells are shaded yellow.
  - Other rows are shaded by row: added employees green, resigned red, and to be hired orange. To be hired rows have one row per open position and no employee number.
  - It follows the function filter. An employee moved out of a function still shows in that function's file.
  - Until the HR sheet is loaded for reference (see step 6), the export is built from the portal's own data, and N Job Name, N Group, N Division and Comments are blank.
- **Vacant positions:** Admin → **Vacant Positions**.
  - Add vacant or to be hired positions for a function: position, FTE or FTC, number of positions, grade, unit, a note, and who the position reports to. That can be an employee or **another vacant position** (for example a vacant team under a vacant unit head).
  - **Job Description / Activities:** type the JD of the position. Clicking the vacant box in the organogram (or its row in View List) opens it in a popup.
  - **Fill** marks one position as filled, optionally naming the employee who took it. A filled position leaves the chart; positions reporting to it then show under that employee. **Reopen** undoes the last fill.
  - They show in the Dashboard organogram when one function is selected (not for the whole of COSO) and **Show To Be Hired** is clicked (top right of the Organogram section). They appear as dashed boxes under their manager. Hidden by default.
  - With them on show, a collapsed manager shows "+N vacant", and a line above the chart gives the totals (FTE / FTC) and View List.
  - **Old TBH placeholder employees** (added as employees with a dummy code before this version) are listed under **Employees Added Outside the HR Record**, at the bottom of the same tab. Ones that look like placeholders (named TBH, vacant, to be hired and so on) are shown first. **Convert to Vacant Position** turns each one into a vacant position:
    - same manager, position, grade and type;
    - its activities become the job description;
    - anyone reporting to it moves to its manager;
    - the placeholder employee is removed, so it is no longer counted.
  - They are never counted as employees.
- **Activity Insights:** in a theme's activity list, click an employee's name to open the same popup as Employee Activities (activities, filters, Previous / Next, Export PDF). The employee PDF and popup now show the **Grade**.
- **Dashboard organogram, one function selected:** the classic chart is back. Click anyone to open or close their team without hiding the others, use Expand One More Level and Collapse, and double-click to centre on a person. The whole-COSO view keeps the simple chart.
- **Activity tables:** volumes show as whole numbers (in the popups, the activity lists and the employee PDF).
- **Rename a function:** Admin → Capture Progress → **Rename** next to the function. The new name shows everywhere. The HR master sheet's name is kept (shown as "HR: …"), so importing the HR sheet still finds the function and moves nobody, and the Full Export still uses HR's name.
- **Bulk title (position) changes:** Admin → Data Transfer. Export, change the *Position* column, delete the Activities, Settings and Frequencies sheets, and import with the box ticked. A blank Position leaves the title as it is. Changed titles are kept when the HR sheet is imported again.
- **Employees added with grade Outsourced Staff** (in Data Capture, Admin → Employees or a Data Transfer file) show as FTC, the same as at the HR import. Any added before this update are corrected when the portal starts.
- **Share Feedback:** only **Suggestion** and **Employee Change**. Feedback sent earlier keeps its topic.
- **Dashboard, Activities section:** livelier colours, Title Case column headings, no heading above the theme list. Volume Based / Non Volume Based have their own plum pair, apart from FTE / FTC.
- **One-page summary PDF:** built but hidden for now; it can be switched on in a later update.
- **Colours:** one muted palette based on the HBL green (sage, bronze and slate), replacing the yellow, blue and purple.
- **Geographical Spread:** Regions at a Glance shows the top 10 regions: 5 to a line on wide screens, 4 on laptop screens.
- **Employee Activities:** the white figures bar shows Service and Support employees with their share (of the employees marked), on the right. The unit filter no longer shows "Unit not set" just because the function head has no unit.
- **Review in Excel:**
  - **Download Activities** asks which function, or all functions.
  - The file can change the unit, service / support, product, process, channel, description, category, theme, frequency, volume, volume type, peaks, nature of work, processing time and automation.
  - It can **delete** activities: write Yes in the red *Delete activity* column.
  - It can **add** activities: a row with an employee code and no Activity ID.
  - You get a preview first, and Undo Last Upload reverses everything.

VM folder: `/data/opt/ops-portal`. Service: `ops-portal`. Run the steps one by one; each block can be pasted as a whole.

---

## Step 1: Copy the zip to the VM

```
scp ops-portal-v2.12-update.zip YOUR_VM_USER@hblassist.domestic.hbl.com:/tmp/
```

## Step 2: Back up first (do not skip)

```
sudo systemctl stop ops-portal
STAMP=$(date +%Y%m%d_%H%M)
sudo mkdir -p /data/opt/ops-portal/backups
sudo python3 -c "import sqlite3,sys; s=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); d=sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close(); print('database backed up')" /data/opt/ops-portal/backups/portal_before_2.12_$STAMP.db
sudo tar -czf /data/opt/ops-portal/backups/code_before_2.12_$STAMP.tgz -C /data/opt/ops-portal --exclude backend/venv --exclude backend/data --exclude backups .
sudo python3 -c "import sqlite3,glob; f=sorted(glob.glob('/data/opt/ops-portal/backups/portal_before_2.12_*.db'))[-1]; c=sqlite3.connect(f); print(f); print(c.execute('pragma integrity_check').fetchone()[0], c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities')"
```

The last command should print `ok`, then your employee and activity counts. **Write the two numbers down.**

## Step 3: Install the new code

```
rm -rf /tmp/ops-update && python3 -m zipfile -e /tmp/ops-portal-v2.12-update.zip /tmp/ops-update
ls /tmp/ops-update/ops-portal/backend/app/main.py && echo "zip OK"
sudo rsync -a --exclude 'backend/data' --exclude 'backend/venv' --exclude 'backups' --exclude 'wheels' /tmp/ops-update/ops-portal/ /data/opt/ops-portal/
```

If `rsync` is not installed, use this instead:

```
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo cp -r /tmp/ops-update/ops-portal/backend/app /tmp/ops-update/ops-portal/backend/static /data/opt/ops-portal/backend/
sudo cp -r /tmp/ops-update/ops-portal/deploy /data/opt/ops-portal/
```

## Step 4: Set the owner and permissions

```
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 700 /data/opt/ops-portal/backend/data
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/secret.key
sudo chmod -R a+rX /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo chmod 755 /data/opt/ops-portal/backend/venv/bin/*
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
```

## Step 5: Start the portal and check it

```
sudo systemctl start ops-portal
sleep 8
sudo systemctl status ops-portal --no-pager | head -5
sudo journalctl -u ops-portal -n 30 --no-pager
sudo -u opsportal python3 -c "import sqlite3; c=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); print(c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities'); print('volume types:', c.execute('select volume_type, count(*) from work_items group by 1').fetchall()); print('new tables:', [r[0] for r in c.execute(\"select name from sqlite_master where name in ('decisions','vacancies')\")]); print('HR record filled for', c.execute('select count(*) from employees where hr_function_id is not null').fetchone()[0], 'employees')"
```

Check three things:

- The status shows **active (running)**.
- The log has no `Traceback`.
- The counts match step 2, and the volume types line shows only `('', N)`, meaning everything is still Activity Based.

## Step 6: In the browser

Press **Ctrl+F5**. Then look at:

- the Dashboard, Activities section;
- Activity Insights;
- Admin, Activity Categories, Download Activities.

**Then, once only, load the HR sheet for reference (not an import).** Open Admin → Import, click **Load HR Sheet (Reference)**, choose the same HR employee list you imported before, then **Check the Sheet** and **Keep as HR Reference**.
- Nothing in the portal changes: no employee is added, removed or edited, and activities, flags and your changes stay as they are.
- The portal only keeps HR's manager, function and full row for each employee, to compare with. This fills in the "Not known yet" values and gives the Full Export every HR column (Job Name, Group, Division, Comments).
- If the sheet doesn't hold most of the portal's employees, it is refused.

```
rm -rf /tmp/ops-update /tmp/ops-portal-v2.12-update.zip
```

---

## Converting the old TBH employees

1. Admin → **Vacant Positions**, and choose the function.
2. At the bottom, **Employees Added Outside the HR Record** lists the likely placeholders. To see every added employee, choose **All Added**.
3. Click **Convert to Vacant Position** on each placeholder and confirm. Do not convert real employees who are only missing from the HR record: they belong on the Employee Changes page as Not in HR Record.
4. On the Dashboard, select the function, open the Organogram and click **Show To Be Hired**.

Take a backup first (`sudo /data/opt/ops-portal/deploy/backup_db.sh`). A conversion cannot be undone from the screen; to bring a placeholder back, add it again in Admin → Employees.

## Marking file based volumes

Choose whichever way suits the number of activities:

- **A few activities:** go to Data Capture, step 2. Each activity has a **Volume type** switch next to the volume.
- **Many at once:** use **Admin, Activity Categories, Review in Excel, Download Activities**. In the *Volume type* column, choose **File Based** and correct the *Avg volume* if needed, then upload.
- **POCs:** the data capture template has a **Volume type** column with a drop-down. A template downloaded before 2.12, without that column, keeps each activity's volume type as it was.

## Review by functional heads (one Excel per function)

1. **Admin, Activity Categories, Review in Excel, Download Activities.** Choose the function and click **Download**. Repeat for each function. Each file has only that function's employees and activities.
2. The functional head edits the **green** columns. Blank cells leave the portal's value as it is.
   - **Unit** and **Service / support** belong to the employee. Use the same value on all of the employee's rows; if the rows differ, the value used most is applied and the preview lists the conflict.
   - **Activity theme** belongs to the category: every activity of a category gets the same theme.
   - **Delete an activity:** write **Yes** in the red *Delete activity* column.
   - **Add an activity:** add a row with the **Employee code** and the details, and leave the *Activity ID* empty.
   - Sorting and filtering the rows is fine. Do not change the Activity ID. If an Activity ID no longer matches (copied from an older file, or the column sorted on its own), the row is found by its employee and activity details instead, and the preview says how many.
3. **Take a backup:** `sudo /data/opt/ops-portal/deploy/backup_db.sh`.
4. **Upload Changes.** The preview shows what the file changes:
   - activities added and deleted;
   - each field changed;
   - employees whose unit or service / support changes;
   - rows left out;
   - values not accepted.

   Nothing changes until you click **Apply Changes**.
5. **Undo Last Upload** reverses the whole of the last upload:
   - changed fields go back;
   - added activities are taken out;
   - deleted activities come back;
   - employee units and service / support are restored.

   Only the last upload can be undone, so check each one before uploading the next.

Employees and functions that are not in the file are never changed. Uploading one function's file therefore leaves every other function as it is.

The boss's earlier files (the Excel export, or files with **Revised ...** columns and no Activity ID) still work as before. From those files the portal reads only descriptions, categories, themes, volumes and the Revised columns, and the preview says so.

---

## Roll back to 2.11 (about 2 minutes)

```
sudo systemctl stop ops-portal
DB=$(ls -t /data/opt/ops-portal/backups/portal_before_2.12_*.db | head -1); CODE=$(ls -t /data/opt/ops-portal/backups/code_before_2.12_*.tgz | head -1); echo "$DB"; echo "$CODE"
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo tar -xzf "$CODE" -C /data/opt/ops-portal
sudo cp "$DB" /data/opt/ops-portal/backend/data/portal.db
sudo rm -f /data/opt/ops-portal/backend/data/portal.db-wal /data/opt/ops-portal/backend/data/portal.db-shm
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
sudo systemctl start ops-portal
```

Rolling back the database also removes anything entered after the update. Only do it if 2.12 does not work.
