from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import (audit, current_user, get_setting, hash_password, input_ids, make_token, unit_scope,
                        require_dashboard, sees_everything, verify_password, view_ids)
from ..orgdata import org_rows
from ..logic import HANDLING, field_config, frequency_list, hide_resigned, nature_label
from ..cache import cached_json

router = APIRouter(prefix="/api")


class LoginIn(BaseModel):
    username: str
    password: str


class PasswordIn(BaseModel):
    current: str
    new: str


SUPER = "admin"   # the one login that owns the grade benchmark and gives it to others


def user_out(u: models.User, db: Session):
    names = {f.id: f.name for f in db.query(models.Function)}
    inp = sorted(input_ids(u, db), key=lambda i: names.get(i, ""))
    vw = sorted(view_ids(u, db), key=lambda i: names.get(i, ""))
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "role": u.role, "is_admin": u.role == "admin",
            "input_functions": [{"id": i, "name": names.get(i)} for i in inp if i in names],
            "view_mode": "all" if u.role == "admin" else (u.view_mode or "none"),
            "view_functions": [{"id": i, "name": names.get(i)} for i in vw if i in names],
            "sees_everything": sees_everything(u), "can_export": u.role == "admin" or bool(u.can_export),
            "can_decisions": u.role == "admin" or bool(u.can_decisions),
            "can_emp_changes": u.role == "admin" or bool(u.can_emp_changes),
            "can_role_overlap": u.role == "admin" or bool(u.can_role_overlap),
            "can_summary": u.role == "admin" or bool(u.can_summary),
            "is_super": u.username == SUPER,
            "can_bm_edit": u.username == SUPER or (u.role == "admin" and bool(u.can_benchmark) and bool(u.can_bm_edit)), "can_benchmark": u.username == SUPER or bool(u.can_benchmark)}


@router.post("/auth/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    u = db.query(models.User).filter(models.User.username == body.username.strip().lower()).first()
    if not u or not u.active or not verify_password(body.password, u.password_hash):
        raise HTTPException(401, "Username or password is incorrect.")
    audit(db, u, "login")
    db.commit()
    return {"token": make_token(u), "user": user_out(u, db)}


@router.get("/auth/me")
def me(user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    return user_out(user, db)


@router.post("/auth/password")
def change_password(body: PasswordIn, user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    if not verify_password(body.current, user.password_hash):
        raise HTTPException(400, "Current password is incorrect.")
    if len(body.new) < 8:
        raise HTTPException(400, "New password must be at least 8 characters.")
    user.password_hash = hash_password(body.new)
    audit(db, user, "password_change")
    db.commit()
    return {"ok": True}


@router.get("/lookups")
def lookups(user: models.User = Depends(current_user), db: Session = Depends(get_db)):
    return {
        "categories": [c.name for c in db.query(models.Category).order_by(models.Category.sort, models.Category.name)],
        "regions": [r.name for r in db.query(models.Region).order_by(models.Region.sort, models.Region.name)],
        "productive_hours": float(get_setting(db, "productive_hours") or 7.5),
        "senior_rank": int(get_setting(db, "senior_rank") or 68),
        "large_team": int(get_setting(db, "large_team") or 40),
        "working_days_week": float(get_setting(db, "working_days_week") or 5),
        "working_days_month": float(get_setting(db, "working_days_month") or 22),
        "group_label": get_setting(db, "group_label") or "COSO",
        "capture_fields": field_config(db),
        "show_time": bool(get_setting(db, "show_time")),
        "frequencies": [n for n, _ in frequency_list(db)],
        "frequency_days": {n: d for n, d in frequency_list(db)},
        "handling": list(HANDLING),
        "handling_label": nature_label(),
        "hide_resigned": hide_resigned(),
        "show_themes": bool(get_setting(db, "show_themes")),
        "show_categories": get_setting(db, "show_categories") is not False,
        "labels": get_setting(db, "labels") or {},
        "category_themes": (get_setting(db, "category_themes") or {}) if get_setting(db, "show_themes") else {},
        "theme_list": list(get_setting(db, "themes") or []),
    }


@router.get("/org")
@cached_json
def org(user: models.User = Depends(require_dashboard), db: Session = Depends(get_db)):
    """Organisation in a compact form, limited to the functions the user may see. People outside
    those functions who sit in their reporting line upwards are included as context only."""
    return org_rows(db, None if sees_everything(user) else view_ids(user, db), unit_scope(user))
