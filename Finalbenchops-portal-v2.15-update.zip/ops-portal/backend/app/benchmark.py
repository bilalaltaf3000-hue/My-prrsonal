"""Grade benchmark: the highest grade each level of the structure may hold, and where people are below it
(room to grow), at it, or above it (an anomaly). Also where a function has more layers than the model.

The model (the grid from HR): Layer 1 COSO (the Group Head), Layer 2 Division, Layer 3 Department, Layer 4 Unit,
Layer 5 Team Lead / Senior Manager / Manager, and below them Teams, who have no direct reports (FTC staff only).
The layer comes from the level: a Department head reporting straight to the Group Head is Layer 3.
A function is marked by the admin as a Division, a Department or a Unit; its head holds that level. The levels below
follow the position in the reporting line (and can be changed per person by the admin):
    - each layer below a manager is the next level after the manager's (Division -> Department -> Unit -> Team Leader);
      a level set by the admin on a manager carries down to their team
    - below a Team Lead                                      -> Teams; anyone permanent below a Teams member is an extra layer
    - no one reports to them, above Teams                      -> Team Lead / Senior Manager / Manager tier
The max grade of each level depends on the size of the function: its permanent headcount (FTE only, not
outsourced or FTC, not external, not resigned) below 50, or 50 and more (both tables are admin settings).
Only permanent staff are benchmarked; the Group Head is not."""
import threading
from typing import Dict, List, Optional

from sqlalchemy.orm import Session

from . import models
from .security import get_setting, set_setting

LEVELS = ["division", "department", "unit", "team", "others"]
LEVEL_NAME = {"division": "Division", "department": "Department", "unit": "Unit", "team": "Team Lead / SM / Manager",
              "others": "Teams", "extra": "Extra layer"}
LEVEL_TAG = {"division": "DIV", "department": "DEPT", "unit": "UNIT", "team": "TL", "others": "TEAMS", "extra": "EXTRA"}
# the layer is set by the level, not by how far down the reporting line someone is (COSO, the Group Head, is Layer 1):
# a Department head reporting straight to the Group Head is Layer 3. Teams sit below Layer 5 and have no direct reports
# of their own (FTC staff only, where applicable).
LAYER_OF = {"division": 2, "department": 3, "unit": 4, "team": 5, "others": None}
ORG_TYPES = ("division", "department", "unit")
# ranks are the numbers in front of the grades in the HR sheet (084-GM I = 84)
DEFAULTS = {"threshold": 50, "max_layers": 5,
            "small": {"division": 84, "department": 80, "unit": 76, "team": 72, "others": 64},
            "large": {"division": 86, "department": 84, "unit": 80, "team": 76, "others": 68},
            # the lower grade of each band (the grid: Division DGM II / GM I under 50 ...)
            "small_min": {"division": 80, "department": 76, "unit": 72, "team": 68, "others": 52},
            "large_min": {"division": 84, "department": 80, "unit": 76, "team": 72, "others": 52}}
KNOWN = {52: "AM I", 56: "AM II", 60: "MA I", 64: "MA II", 68: "SM I", 72: "SM II", 76: "DGM I", 80: "DGM II",
         84: "GM I", 86: "GM II", 88: "GM III"}


def settings(db) -> dict:
    s = get_setting(db, "grade_benchmark") or {}
    out = {"threshold": int(s.get("threshold") or DEFAULTS["threshold"]), "max_layers": int(s.get("max_layers") or DEFAULTS["max_layers"])}
    for band in ("small", "large", "small_min", "large_min"):
        out[band] = {lv: int((s.get(band) or {}).get(lv) or DEFAULTS[band][lv]) for lv in LEVELS}
    return out


def save_settings(db, new: dict) -> dict:
    cur = settings(db)
    if "threshold" in new and new["threshold"]:
        cur["threshold"] = max(1, int(new["threshold"]))
    if new.get("max_layers"):
        cur["max_layers"] = max(2, int(new["max_layers"]))
    for band in ("small", "large", "small_min", "large_min"):
        for lv, v in (new.get(band) or {}).items():
            if lv in LEVELS and v:
                cur[band][lv] = int(v)
    set_setting(db, "grade_benchmark", cur)
    _memo["ver"] = None
    return cur


def grade_ladder(db) -> Dict[int, str]:
    """Every grade rank in use with its name (from the employees), plus the usual ones."""
    lad = dict(KNOWN)
    for rk, g in db.query(models.Employee.grade_rank, models.Employee.grade).distinct():
        if rk is not None and rk > 0 and g and g not in ("FTC", "External", "-"):
            lad[int(rk)] = g
    return dict(sorted(lad.items()))


def permanent(e) -> bool:
    return e.emp_type == "FTE" and not e.external and not e.resigned and not e.exclude and (e.grade_rank or 0) > 0


_memo = {"ver": None, "data": None}
_lock = threading.Lock()


def compute(db: Session) -> dict:
    """{"people": {code: row}, "functions": {fid: row}, "ladder": {rank: name}} for every function, kept until the data changes."""
    from .cache import data_version
    ver = data_version()
    with _lock:
        if _memo["ver"] == ver and _memo["data"] is not None:
            return _memo["data"]
    data = _compute(db)
    with _lock:
        _memo["ver"], _memo["data"] = ver, data
    return data


def _compute(db: Session) -> dict:
    cfg = settings(db)
    ladder = grade_ladder(db)
    ranks = sorted(ladder)
    root = get_setting(db, "root_code")
    emps = {e.code: e for e in db.query(models.Employee).filter(models.Employee.resigned == False)}  # noqa: E712
    kids: Dict[str, List[str]] = {}
    for c, e in emps.items():
        if e.manager_code and e.manager_code in emps and c != root:
            kids.setdefault(e.manager_code, []).append(c)
    # depth from the Group Head (0 = the Group Head; shown as Layer 1)
    depth = {root: 0} if root in emps else {}
    order = list(depth)
    for x in order:
        for k in kids.get(x, []):
            if k not in depth:
                depth[k] = depth[x] + 1
                order.append(k)
    fns = {f.id: f for f in db.query(models.Function)}
    people: Dict[str, dict] = {}
    frows: Dict[int, dict] = {}
    for fid, fn in fns.items():
        mem = [c for c, e in emps.items() if e.function_id == fid and c != root]
        if not mem:
            continue
        mset = set(mem)
        perm = sum(1 for c in mem if permanent(emps[c]))
        auto_band = "large" if perm >= cfg["threshold"] else "small"
        band = fn.bm_band if fn.bm_band in ("small", "large") else auto_band   # the admin can set the band by hand
        maxes, mins = cfg[band], cfg[band + "_min"]
        typ = fn.org_type if fn.org_type in ORG_TYPES else None
        fkids = {c: [k for k in kids.get(c, []) if k in mset] for c in mem}
        size: Dict[str, int] = {}

        def sub(c, seen=None):
            if c in size:
                return size[c]
            stack, n, vis = [c], 0, set()
            while stack:
                x = stack.pop()
                if x in vis:
                    continue
                vis.add(x)
                n += 1
                stack.extend(fkids.get(x, []))
            size[c] = n
            return n

        tops = [c for c in mem if not (emps[c].manager_code in mset)]
        tops.sort(key=lambda c: (-sub(c), -(emps[c].grade_rank or 0), emps[c].name))
        head = tops[0] if tops else None
        frow = {"id": fid, "name": fn.name, "type": typ, "permanent": perm, "headcount": len(mem), "band": band, "band_set": fn.bm_band in ("small", "large"), "auto_band": auto_band,
                "head": head, "counts": {lv: 0 for lv in LEVELS + ["extra"]}, "above": 0, "at": 0, "room": 0,
                "assessed": 0, "beyond": 0, "extra": 0}
        frows[fid] = frow
        seq = LEVELS if typ == "division" else LEVELS[1:] if typ == "department" else LEVELS[2:]
        # walk each top's subtree: (code, slot = lowest level index still free, level of the manager, depth in function)
        hl = depth.get(head) if head else None
        todo = [(t, None, None, 0) for t in tops]
        done = set()
        while todo:
            c, below_set, parent_lv, rel = todo.pop()   # below_set: what the manager's admin setting makes their direct reports
            if c in done:
                continue
            done.add(c)
            e = emps[c]
            ks = kids.get(c, [])     # every direct report (also from other functions) decides the shape
            ov = e.bm_level if e.bm_level in LEVELS + ["extra"] else None
            if not typ:
                lv = None
            elif ov:
                lv = ov
            elif c == head:
                lv = seq[0]
            else:
                # by position: each layer below a manager is the next level after the manager's (so a level the
                # admin sets on a manager carries down to their team); the last layer (max layers, 5) and anything
                # deeper is Others; someone with no reports above it is the Team Leader / SM / Manager tier
                lay = depth.get(c)
                if parent_lv in seq:
                    nxt = seq[min(seq.index(parent_lv) + 1, len(seq) - 1)]
                else:
                    below = (lay - hl) if lay is not None and hl is not None else 1
                    nxt = seq[min(max(below, 1), len(seq) - 1)]
                if below_set in ("team", "others"):
                    nxt = below_set
                if parent_lv == "others":
                    lv = "others"   # below Teams: an extra layer (flagged below), still benchmarked as Teams
                elif nxt in ("team", "others"):
                    lv = nxt
                elif not ks:
                    lv = "team"
                else:
                    lv = nxt
            blv = lv if lv != "extra" else (parent_lv if parent_lv and parent_lv != "extra" else "unit")
            row = {"level": lv, "auto": ov is None, "below": e.bm_below if e.bm_below in ("team", "others") else None,
                   "layer": LAYER_OF.get(lv) if typ else None, "depth": depth[c] + 1 if c in depth else None, "fid": fid}
            if typ:
                frow["counts"][lv] += 1
                if lv == "others" and any(permanent(emps[k]) for k in ks):
                    row["gate"] = True      # Teams have no direct reports (FTC staff only): permanent reports are an extra layer
                    frow["extra"] += 1
                if lv == "others" and parent_lv == "others" and permanent(e):
                    row["beyond"] = True
                    frow["beyond"] += 1
                mx, mn = maxes.get(blv), mins.get(blv)
                if permanent(e) and mx:
                    g = e.grade_rank
                    tier = "above" if g > mx else "at" if g == mx else "room"
                    gap = sum(1 for r in ranks if mx < r <= g) if tier == "above" else 0
                    row.update(tier=tier, max=mx, max_name=ladder.get(mx, str(mx)), gap=gap, bench_level=blv,
                               min_name=ladder.get(mn, str(mn)) if mn else "", below_min=bool(mn and g < mn))
                    frow[tier] += 1
                    frow["assessed"] += 1
                else:
                    row["tier"] = None
                    row["why"] = "not permanent" if not permanent(e) else "no max"
            people[c] = row
            for k in fkids.get(c, []):
                todo.append((k, e.bm_below if e.bm_below in ("team", "others") else None, blv if typ else None, rel + 1))
    return {"people": people, "functions": frows, "ladder": ladder, "settings": cfg, "root": root}


def level_layers(db: Session) -> Dict[str, int]:
    """The layer of each employee in a tagged function, from their level (L2 Division ... L5 Team Lead, 6 Teams,
    7 an extra layer below Teams). Used everywhere layers are counted; untagged functions use the reporting depth."""
    d = compute(db)
    out = {}
    for c, p in d["people"].items():
        if p.get("level"):
            out[c] = 7 if p.get("beyond") else (LAYER_OF.get(p["level"]) or 6)
    return out


def check(db: Session) -> dict:
    """What still needs the admin: functions without a type, Extra-layer managers, and the levels set by hand."""
    d = compute(db)
    emps = {e.code: e for e in db.query(models.Employee).filter(models.Employee.resigned == False)}  # noqa: E712
    untagged = [f for f in d["functions"].values() if not f["type"]]
    extra, manual = [], []
    for c, p in d["people"].items():
        e = emps.get(c)
        if not e:
            continue
        item = {"code": c, "name": e.name, "position": e.position or "", "grade": e.grade or "", "function": d["functions"][p["fid"]]["name"],
                "fid": p["fid"], "level": p["level"], "layer": p["layer"], "reports": sum(1 for x in emps.values() if x.manager_code == c)}
        if p["level"] == "extra" and p["auto"]:
            extra.append(item)
        item["below"], item["auto"] = p.get("below"), p["auto"]
        if not p["auto"] or p.get("below"):
            manual.append(item)
    key = lambda x: (x["function"], x["layer"] or 9, x["name"])
    return {"untagged": sorted([{"id": f["id"], "name": f["name"], "headcount": f["headcount"], "permanent": f["permanent"]} for f in untagged], key=lambda x: x["name"]),
            "extra": sorted(extra, key=key), "manual": sorted(manual, key=key)}
