"""Vacant and to be hired positions: written by the admin for a function, shown in that function's organogram
under the manager they will report to. They are never counted as employees."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import audit, require_admin, require_dashboard, sees_everything, view_ids

router = APIRouter()


class VacancyIn(BaseModel):
    function_id: int
    manager_code: Optional[str] = None
    position: str
    grade: str = ""
    emp_type: str = "FTE"
    count: int = 1
    unit: str = ""
    note: str = ""


def _out(v: models.Vacancy, names, fnames):
    return {"id": v.id, "function_id": v.function_id, "function": fnames.get(v.function_id, ""), "manager_code": v.manager_code or "",
            "manager_name": names.get(v.manager_code, "") if v.manager_code else "", "position": v.position or "", "grade": v.grade or "",
            "emp_type": v.emp_type or "FTE", "count": v.count or 1, "unit": v.unit or "", "note": v.note or ""}


def _clean(db, b: VacancyIn) -> dict:
    if not db.get(models.Function, b.function_id):
        raise HTTPException(400, "Unknown function.")
    pos = " ".join((b.position or "").split())[:250]
    if len(pos) < 2:
        raise HTTPException(400, "Write the position, for example Officer Clearing.")
    m = (b.manager_code or "").strip() or None
    if m:
        e = db.get(models.Employee, m)
        if not e:
            raise HTTPException(400, f"No employee has the code {m}.")
    if b.emp_type not in ("FTE", "FTC"):
        raise HTTPException(400, "Choose FTE or FTC.")
    if not 1 <= int(b.count or 1) <= 500:
        raise HTTPException(400, "The number of positions must be 1 to 500.")
    return {"function_id": b.function_id, "manager_code": m, "position": pos, "grade": " ".join((b.grade or "").split())[:60],
            "emp_type": b.emp_type, "count": int(b.count or 1), "unit": " ".join((b.unit or "").split())[:200], "note": (b.note or "").strip()[:2000]}


def _list(db, fids):
    names = {c: n for c, n in db.query(models.Employee.code, models.Employee.name)}
    fnames = {f.id: f.name for f in db.query(models.Function)}
    q = db.query(models.Vacancy)
    if fids is not None:
        q = q.filter(models.Vacancy.function_id.in_(list(fids) or [-1]))
    rows = sorted(q, key=lambda v: (fnames.get(v.function_id, ""), names.get(v.manager_code, ""), v.position or ""))
    return [_out(v, names, fnames) for v in rows]


@router.get("/api/vacancies")
def vacancies(functions: str = Query(""), user=Depends(require_dashboard), db: Session = Depends(get_db)):
    """The vacant positions of the functions on show (only those the login may see)."""
    allowed = None if sees_everything(user) else view_ids(user, db)
    want = {int(x) for x in functions.split(",") if x.strip().isdigit()}
    fids = (want & allowed if allowed is not None else want) if want else allowed
    return _list(db, fids)


@router.get("/api/admin/vacancies")
def admin_list(function_id: Optional[int] = Query(None), user=Depends(require_admin), db: Session = Depends(get_db)):
    return _list(db, {function_id} if function_id else None)


@router.post("/api/admin/vacancies")
def add(body: VacancyIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    v = models.Vacancy(**_clean(db, body), created_by=user.username)
    db.add(v)
    audit(db, user, "vacancy_add", f"{v.position} x{v.count}")
    db.commit()
    return {"id": v.id}


@router.patch("/api/admin/vacancies/{vid}")
def edit(vid: int, body: VacancyIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    v = db.get(models.Vacancy, vid)
    if not v:
        raise HTTPException(404, "Vacant position not found.")
    for k, val in _clean(db, body).items():
        setattr(v, k, val)
    audit(db, user, "vacancy_edit", f"{v.position} x{v.count}")
    db.commit()
    return {"ok": True}


@router.delete("/api/admin/vacancies/{vid}")
def delete(vid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    v = db.get(models.Vacancy, vid)
    if not v:
        raise HTTPException(404, "Vacant position not found.")
    audit(db, user, "vacancy_delete", v.position)
    db.delete(v)
    db.commit()
    return {"ok": True}
