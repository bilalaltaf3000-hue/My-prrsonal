import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import { fmt } from '../org.js'

// Admin: vacant and to be hired positions of a function. They show in the function's organogram under the manager
// they will report to (a dashed box) and are never counted as employees.
const blank = fid => ({ function_id: fid, manager_code: '', manager_name: '', position: '', grade: '', emp_type: 'FTE', count: 1, unit: '', note: '' })

export default function VacanciesTab({ notify }) {
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState('')
  const [rows, setRows] = useState(null)
  const [form, setForm] = useState(null)
  const [q, setQ] = useState('')
  const [hits, setHits] = useState([])
  const [busy, setBusy] = useState(false)
  useEffect(() => { api('/api/capture/functions').then(r => { const s = [...r].sort((a, b) => a.name.localeCompare(b.name)); setFns(s); if (s.length) setFid(String(s[0].id)) }).catch(e => notify(e.message, true)) }, [])
  const load = () => fid && api('/api/admin/vacancies?function_id=' + fid).then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { setRows(null); setForm(null); load() }, [fid])
  useEffect(() => {   // the manager the position will report to: search the function's employees
    if (!form || q.trim().length < 2) { setHits([]); return }
    const t = setTimeout(() => api(`/api/admin/employees?function_id=${fid}&q=${encodeURIComponent(q.trim())}`).then(r => setHits(r.filter(e => !e.resigned).slice(0, 12))).catch(() => setHits([])), 250)
    return () => clearTimeout(t)
  }, [q, fid, !!form])
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const save = async () => {
    setBusy(true)
    const body = { ...form, function_id: +fid, count: +form.count || 1 }
    try {
      if (form.id) await api(`/api/admin/vacancies/${form.id}`, { method: 'PATCH', body }); else await api('/api/admin/vacancies', { method: 'POST', body })
      notify(form.id ? 'Vacant position saved.' : 'Vacant position added.'); setForm(null); setQ(''); load()
    } catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const remove = async v => {
    if (!confirm(`Remove the vacant position "${v.position}"?`)) return
    try { await api(`/api/admin/vacancies/${v.id}`, { method: 'DELETE' }); notify('Removed.'); load() } catch (e) { notify(e.message, true) }
  }
  const tot = t => (rows || []).filter(v => !t || v.emp_type === t).reduce((a, v) => a + v.count, 0)
  return <div>
    <p className="sub">Positions that are vacant or to be hired. They show in the function's organogram on the Dashboard, under the manager they will report to, with a dashed border. They are not counted as employees anywhere.</p>
    <div className="kvline" style={{ marginBottom: 12 }}>
      <select value={fid} onChange={e => setFid(e.target.value)}>{fns.map(f => <option key={f.id} value={String(f.id)}>{f.name}</option>)}</select>
      {rows && <span className="formula">{fmt(tot('')) === '-' ? 'No vacant positions' : `${tot('')} positions · ${tot('FTE')} FTE · ${tot('FTC')} FTC`}</span>}
      <span style={{ flex: 1 }} />
      <button className="btn pri" disabled={!fid} onClick={() => { setForm(blank(+fid)); setQ('') }}>Add a Vacant Position</button>
    </div>
    {form && <div className="panel vac-form">
      <div className="dc-grid">
        <label>Position<input className="inp" value={form.position} onChange={e => set('position', e.target.value)} placeholder="For example Officer Clearing" autoFocus /></label>
        <label>Type<span className="seg sm" role="group">{['FTE', 'FTC'].map(t => <button key={t} type="button" aria-pressed={form.emp_type === t} onClick={() => set('emp_type', t)}>{t}</button>)}</span></label>
        <label>Number of Positions<input className="inp" type="number" min="1" max="500" value={form.count} onChange={e => set('count', e.target.value)} style={{ width: 110 }} /></label>
        <label>Grade (Optional)<input className="inp" value={form.grade} onChange={e => set('grade', e.target.value)} placeholder="For example OG II" /></label>
        <label>Unit (Optional)<input className="inp" value={form.unit} onChange={e => set('unit', e.target.value)} /></label>
      </div>
      <label>Reports To
        {form.manager_code ? <div className="chosen"><span><b>{form.manager_name || form.manager_code}</b><small>{form.manager_code}</small></span><button type="button" className="linkbtn" onClick={() => { set('manager_code', ''); set('manager_name', '') }}>Change</button></div>
          : <><input className="inp" value={q} onChange={e => setQ(e.target.value)} placeholder="Search the manager by name, code or position (blank: the function head)" />
            {hits.length > 0 && <div className="pick" style={{ maxHeight: 200 }}>{hits.map(e => <button key={e.code} type="button" onClick={() => { setForm(f => ({ ...f, manager_code: e.code, manager_name: e.name })); setQ('') }}>
              <span><b>{e.name}</b><small>{[e.position, e.grade, e.code, e.unit].filter(Boolean).join(' · ')}</small></span></button>)}</div>}</>}</label>
      <label>Note (Optional)<textarea rows={2} value={form.note} maxLength={2000} onChange={e => set('note', e.target.value)} placeholder="For example approved in the October review; hiring in Q1" /></label>
      <div className="row-actions"><button className="btn pri" disabled={busy || form.position.trim().length < 2} onClick={save}>{busy ? 'Saving…' : form.id ? 'Save' : 'Add Position'}</button><button className="btn" onClick={() => setForm(null)}>Cancel</button></div>
    </div>}
    {!rows ? <div className="loading">Loading…</div> : !rows.length ? <div className="empty">No vacant positions recorded for this function.</div>
      : <div className="panel" style={{ padding: 0 }}><div className="tw"><table>
        <thead><tr><th>Position</th><th>Reports To</th><th>Type</th><th>Grade</th><th>Unit</th><th className="num">Positions</th><th>Note</th><th></th></tr></thead>
        <tbody>{rows.map(v => <tr key={v.id}><td><b>{v.position}</b></td><td>{v.manager_name || 'Function head'}<div className="formula">{v.manager_code}</div></td><td>{v.emp_type}</td><td>{v.grade || '-'}</td><td>{v.unit || '-'}</td>
          <td className="num">{fmt(v.count)}</td><td className="formula" style={{ maxWidth: 260 }}>{v.note}</td>
          <td style={{ whiteSpace: 'nowrap' }}><button className="linkbtn" onClick={() => { setForm({ ...v }); setQ('') }}>Edit</button> <button className="linkbtn" onClick={() => remove(v)}>Remove</button></td></tr>)}</tbody></table></div></div>}
  </div>
}
