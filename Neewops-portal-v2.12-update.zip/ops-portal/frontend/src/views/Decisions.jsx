import React, { useEffect, useState } from 'react'
import { api, download } from '../api.js'
import { fmt } from '../org.js'
import { Modal } from '../ui.jsx'

// HR decisions for each function, seen and recorded only by the admin and the logins the admin allows
const PILL = { Decided: '', Implemented: 'p-ok', 'On hold': 'p-warn' }
const day = s => s ? new Date(s + 'T00:00:00').toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : ''
const today = () => new Date().toISOString().slice(0, 10)
const blank = fid => ({ function_id: fid || '', decided_on: today(), subject: '', details: '', status: 'Decided' })

export function DecisionsModal({ user, notify, onClose }) {
  const [fid, setFid] = useState('')          // the function filter ('' = all, 'general' = across functions)
  const [d, setD] = useState(null)
  const [form, setForm] = useState(null)      // the decision being recorded or edited
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState(false)
  const load = () => api('/api/decisions').then(setD).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  const save = async () => {
    setBusy(true)
    const body = { ...form, function_id: form.function_id ? +form.function_id : null }
    try {
      if (form.id) await api(`/api/decisions/${form.id}`, { method: 'PATCH', body }); else await api('/api/decisions', { method: 'POST', body })
      notify(form.id ? 'Decision updated.' : 'Decision recorded.'); setForm(null); load()
    } catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const remove = async x => {
    if (!confirm(`Delete the decision "${x.subject}"?`)) return
    try { await api(`/api/decisions/${x.id}`, { method: 'DELETE' }); notify('Decision deleted.'); load() } catch (e) { notify(e.message, true) }
  }
  const ql = q.trim().toLowerCase()
  const rows = !d ? [] : d.rows.filter(x => (!fid || (fid === 'general' ? !x.function_id : String(x.function_id) === fid))
    && (!ql || (x.subject + ' ' + x.details + ' ' + x.function + ' ' + x.recorded_by).toLowerCase().includes(ql)))
  const mayEdit = x => user.is_admin || x.recorded_user === user.username
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))
  return <Modal wide title="HR Decisions" sub="Decisions for each function, seen only by the admin and the logins given decisions access" onClose={onClose}>
    {!d ? <div className="loading">Loading…</div> : <>
      <div className="dc-bar">
        <select value={fid} onChange={e => setFid(e.target.value)}>
          <option value="">All functions ({fmt(d.total) === '-' ? 0 : fmt(d.total)})</option>
          {d.general > 0 && <option value="general">Across functions ({fmt(d.general)})</option>}
          {d.functions.map(f => <option key={f.id} value={String(f.id)}>{f.name}{f.decisions ? ` (${fmt(f.decisions)})` : ''}</option>)}</select>
        <input className="inp" type="search" placeholder="Search decisions" value={q} onChange={e => setQ(e.target.value)} />
        <span className="dc-sp" />
        {d.total > 0 && <button className="btn" onClick={() => download('/api/decisions/export' + (fid && fid !== 'general' ? `?function_id=${fid}` : ''), 'hr_decisions.xlsx').catch(e => notify(e.message, true))}>Download Excel</button>}
        <button className="btn pri" onClick={() => setForm(blank(fid && fid !== 'general' ? fid : ''))}>Record a Decision</button>
      </div>
      {form && <div className="dc-form panel">
        <div className="dc-grid">
          <label>Function<select value={form.function_id} onChange={e => set('function_id', e.target.value)}>
            <option value="">Across functions</option>{d.functions.map(f => <option key={f.id} value={String(f.id)}>{f.name}</option>)}</select></label>
          <label>Date of Decision<input className="inp" type="date" value={form.decided_on || ''} onChange={e => set('decided_on', e.target.value)} /></label>
          <label>Status<span className="seg sm" role="group">{d.statuses.map(s => <button key={s} type="button" aria-pressed={form.status === s} onClick={() => set('status', s)}>{s}</button>)}</span></label>
        </div>
        <label>Subject<input className="inp" value={form.subject} maxLength={250} onChange={e => set('subject', e.target.value)} placeholder="For example: Merge the two clearing units under one unit head" autoFocus /></label>
        <label>Decision<textarea rows={5} value={form.details} maxLength={10000} onChange={e => set('details', e.target.value)} placeholder="What was decided, by whom, and what happens next" /></label>
        <div className="row-actions"><button className="btn pri" disabled={busy || form.subject.trim().length < 3} onClick={save}>{busy ? 'Saving…' : form.id ? 'Save Changes' : 'Record Decision'}</button>
          <button className="btn" onClick={() => setForm(null)}>Cancel</button></div>
      </div>}
      {!rows.length ? <div className="empty" style={{ marginTop: 10 }}>{d.total ? 'No decisions match.' : 'No decisions recorded yet. Click Record a Decision to add the first one.'}</div>
        : <ul className="dc-list">{rows.map(x => <li key={x.id}>
          <div className="dc-meta"><b className="dc-date">{day(x.decided_on) || 'No date'}</b><span className="dc-fn">{x.function || 'Across functions'}</span>
            <span className={'pill ' + (PILL[x.status] || '')}>{x.status}</span>
            {mayEdit(x) && <span className="dc-act"><button className="linkbtn" onClick={() => setForm({ ...x, function_id: x.function_id ? String(x.function_id) : '' })}>Edit</button>
              <button className="linkbtn" onClick={() => remove(x)}>Delete</button></span>}</div>
          <h4>{x.subject}</h4>
          {x.details && <p>{x.details}</p>}
          <div className="formula">Recorded by {x.recorded_by}{x.updated_by ? ` · updated by ${x.updated_by}` : ''}</div>
        </li>)}</ul>}
    </>}
  </Modal>
}
