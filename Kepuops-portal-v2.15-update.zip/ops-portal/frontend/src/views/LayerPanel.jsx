import React, { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { api } from '../api.js'
import { fmt } from '../org.js'
import { PeopleModal, typeKey, types } from '../ui.jsx'

// The layer panel beside the organogram: the reporting line of the selected person, layer by layer from the
// Group Head ("–" where a layer is skipped), and the layers below them with how many people sit on each, so it is
// clear in advance how deep their part of the structure goes. Logins allowed to change the grade benchmark can set
// the person's level (and what their direct reports are) here, and the chart follows.
const NAME = { 1: 'Group Head', 2: 'Division', 3: 'Department', 4: 'Unit', 5: 'Team Lead / SM / Manager', 6: 'Teams · No Direct Reports', 7: 'FTCs only (if necessary)' }
const LEVELS = [['', 'From reporting line'], ['division', 'Division'], ['department', 'Department'], ['unit', 'Unit'], ['team', 'Team Lead / SM / Manager'], ['others', 'Teams']]

export default function LayerPanel({ org, p, user, notify, onChanged, onPick }) {
  const [b, setB] = useState(null)
  const [list, setList] = useState(null)   // {title, people}: the employees on one layer
  const mayEdit = !!user?.can_layer_edit
  const [editOn, setEditOn0] = useState(() => { try { return localStorage.getItem('lp.edit') === '1' } catch { return false } })
  const setEditOn = v => { setEditOn0(v); try { localStorage.setItem('lp.edit', v ? '1' : '0') } catch { /* no storage */ } }
  const edit = mayEdit && editOn
  const code = p && p.id
  useEffect(() => { setB(null); if (edit && code) api('/api/bm/level/' + encodeURIComponent(code)).then(r => setB({ l: r.level, a: r.auto, bw: r.below })).catch(() => setB(null)) }, [edit, code, org])
  if (!p) return <div className="lp"><div className="formula">Click anyone in the chart.</div></div>
  const tagged = !!(org.FT && org.FT[p.f])
  const chain = []; let x = p; while (x) { chain.unshift(x); x = x.m >= 0 ? org.P[x.m] : null }
  const at = {}; chain.forEach(c => { if (c.ly > 0 && !at[c.ly]) at[c.ly] = c })
  // everyone below the person, by layer
  const below = {}; const stack = [...p.kids]
  while (stack.length) { const k = stack.pop(); if (org.counted(k) && k.ly > 0) { const b = below[k.ly] || (below[k.ly] = { n: 0, fte: 0, ftc: 0, dc: 0, dw: 0, ps: [] }); b.n++; b.ps.push(k); b[typeKey(k)]++ } stack.push(...k.kids) }
  const deepest = Math.max(p.ly, ...Object.keys(below).map(Number))
  const last = Math.max(tagged ? 7 : 0, deepest)
  const rows = []; for (let l = 1; l <= last; l++) rows.push(l)
  const set = async body => {
    try { await api('/api/bm/level', { method: 'PUT', body: { code: p.id, ...body } }); notify && notify('Saved. The layers are updated.'); onChanged && onChanged() } catch (e) { notify && notify(e.message, true) }
  }
  const fid = org.fids && org.fids[p.f]
  const setType = async t => {
    try { await api('/api/bm/layer-function/' + fid, { method: 'PUT', body: { type: t || null } }); notify && notify(t ? `${org.F[p.f]} is now a ${{ division: 'Division', department: 'Department', unit: 'Unit' }[t]}. The layers are updated.` : `${org.F[p.f]} is no longer tagged.`); onChanged && onChanged() } catch (e) { notify && notify(e.message, true) }
  }
  return <div className="lp">
    <div className="lp-top"><h3>Layers of the reporting line</h3>
      {mayEdit && <label className="lp-sw" title="Edit mode: set levels from this panel"><input type="checkbox" checked={editOn} onChange={e => setEditOn(e.target.checked)} /><span>Edit</span></label>}</div>
    <div className="lp-sub">{org.F[p.f] || ''}{tagged ? ` · ${{ division: 'Division', department: 'Department', unit: 'Unit' }[org.FT[p.f]]}` : ''}</div>
    <div className="lp-depth"><b>L{p.ly}</b> {p.n.split(' ')[0]}'s layer{p.kids.length ? <> · their part goes down to <b>L{deepest}</b></> : ''}</div>
    <div className="lp-steps">{rows.map(l => {
      const c = at[l], mine = l === p.ly, under = l > p.ly, bl = below[l]
      const cls = 'lp-st' + (mine ? ' on' : '') + (under ? ' dim' : '') + (!c && !under ? ' none' : '') + (under && !bl ? ' none' : '') + (l === 7 && tagged ? ' l7' : '')
      return <div key={l} className={cls}>
        <i>L{l}</i>
        <div>{!under ? (c ? <button type="button" className="lp-n" onClick={() => onPick && c !== p && onPick(c)} title={c === p ? '' : 'Show this person'}>{c.n}</button> : <b>–</b>)
          : bl ? <button type="button" className="lp-n lp-cnt" onClick={() => setList({ title: `${p.n}'s team: Layer ${l}`, people: bl.ps })} title="Show these employees">{fmt(bl.n)} {bl.n === 1 ? 'person' : 'people'}</button> : <b>–</b>}
          <span>{tagged ? NAME[l] : `Layer ${l}`}{!under && c && c.g && c.g !== '-' ? ` · ${c.g}` : ''}{under && bl ? ` · ${types().map(t => bl[t.k] ? `${fmt(bl[t.k])} ${t.label}` : '').filter(Boolean).join(', ')}` : ''}{!under && !c && tagged ? ' · no one on this layer' : ''}</span></div>
      </div> })}</div>
    {edit && p !== org.ROOT && fid != null && <div className="lp-edit"><b>{org.F[p.f]}</b>
      <label>Function is a<select className="inp" value={org.FT[p.f] || ''} onChange={e => setType(e.target.value)}>
        <option value="">Not tagged</option><option value="division">Division</option><option value="department">Department</option><option value="unit">Unit</option></select></label>
      {!tagged && <p className="formula">Tag the function first. Then you can set each person's level here.</p>}</div>}
    {edit && tagged && p !== org.ROOT && <div className="lp-edit"><b>Set {p.n.split(' ')[0]}'s level</b>
      <label>Level<select className="inp" value={b && !b.a ? b.l : ''} onChange={e => set({ level: e.target.value || null })}>
        {LEVELS.map(([k, n]) => <option key={k} value={k}>{k === '' && b ? `${n}${b.a ? ': ' + (LEVELS.find(z => z[0] === b.l) || ['', b.l])[1] : ''}` : n}</option>)}</select></label>
      {p.kids.length > 0 && <label>Their direct reports<select className="inp" value={(b && b.bw) || ''} onChange={e => set({ below: e.target.value })}>
        <option value="">By position</option><option value="team">Team Lead / SM / Manager</option><option value="others">Teams</option></select></label>}
      <p className="formula">The levels below follow, and every chart and count updates.</p></div>}
    {list && createPortal(<PeopleModal title={list.title} people={list.people} F={org.F} heads={org.headIds} initial="people" onPerson={x => { setList(null); onPick && onPick(x) }} onClose={() => setList(null)} />, document.body)}
  </div>
}
