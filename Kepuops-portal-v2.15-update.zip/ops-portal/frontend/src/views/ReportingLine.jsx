import React, { useEffect, useState } from 'react'
import { fmt } from '../org.js'
import { Dot, Modal, typeName, types } from '../ui.jsx'
import { Classic } from './Organogram.jsx'
import LayerPanel from './LayerPanel.jsx'
import { canLayers } from '../rights.js'

// Who an employee reports to (the whole line up to the top) and who reports to them, as a chart.
export default function ReportingLine({ code, org, theme, lookups, onClose, go, user, notify, reloadOrg }) {
  const [pc, setPc] = useState(code)   // kept by code so the chart follows a reloaded organisation
  const p = org.byId.get(pc) || null
  const setP = x => setPc(x ? x.id : null)
  if (!p) return <Modal title="Reporting Line" onClose={onClose}><div className="empty">This employee is not in the organisation data you can see.</div></Modal>
  const mgr = p.m >= 0 ? org.P[p.m] : null
  const chain = []; let x = p; while (x.m >= 0) { x = org.P[x.m]; chain.unshift(x) }
  return <Modal wide onClose={onClose} title={`Reporting Line: ${p.n}`} sub={`${p.pos || '-'} · ${p.g} · ${p.id} · ${org.F[p.f] || ''}`}>
    <div className="facts">
      <div><span>Reports To</span>{mgr ? <><b><button onClick={() => setP(mgr)} title="Centre the chart on this manager">{mgr.n}</button></b><small>{mgr.pos || '-'}</small></> : <b>Top of the Organisation</b>}</div>
      <div><span>Direct Reports</span><b>{fmt(p.nk)}</b><small>{types().map(t => { const n = p.kids.filter(k => org.counted(k) && t.test(k)).length; return n || t.k === 'fte' || t.k === 'ftc' ? <span key={t.k}><Dot fte={t.k === 'fte'} dc={t.k === 'dc'} dw={t.k === 'dw'} />{fmt(n)} {t.label} &nbsp;</span> : null })}</small></div>
      <div><span>Total Team</span><b>{fmt(p.team)}</b><small>{p.depthBelow} Layer{p.depthBelow === 1 ? '' : 's'} Below</small></div>
      <div><span>Layer</span><b>{p.ly > 0 ? p.ly : '-'}</b><small>{chain.length} Manager{chain.length === 1 ? '' : 's'} Above</small></div>
      <div><span>Type and Region</span><b>{typeName(p)}{p.st ? ` · ${p.st}` : ''}</b><small>{p.rg || 'Region Not Set'}</small></div>
    </div>
    {(() => { const panel = canLayers(user) ? <LayerPanel org={org} p={p} user={user} notify={notify} onChanged={reloadOrg} onPick={setP} /> : null
      return <div className={panel ? 'lp-wrap' : ''}>{panel}
        <Classic root={p} focus={p} onFocus={setP} org={org} theme={theme} largeTeam={lookups?.large_team || 40} compact
          onReroot={setP} onOpenList={setP} side={panel} /></div> })()}
  </Modal>
}
