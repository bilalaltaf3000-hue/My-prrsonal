"""Admin tools: edit any employee's details (including function and reporting line), and move data
between installations (export each function's units, regions and activities to Excel, import them back)."""
import io
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import StreamingResponse
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..config import OUTSOURCED_GRADE_TEXT
from ..db import get_db
from ..importer import code_text, grade_label, grade_rank, is_outsourced, strip_prefix
from ..logic import FREQUENCIES, HANDLING, NATURE_LEGACY, reassign_resigned_teams, SERVICE_TYPES, Calc, freq_names, frequency_list, function_heads, nature_headings, nature_label, nature_value, vol_labels, vol_type_value, VOL_FILE
from ..security import audit, get_setting, require_admin, set_setting

SETTING_KEYS = [("productive_hours", "Productive hours per day"), ("working_days_week", "Working days per week"),
                ("working_days_month", "Working days per month"), ("root_code", "Top of the organogram (employee code)"),
                ("senior_rank", "Senior grade threshold"), ("large_team", "Group team members above this team size"),
                ("group_label", "Name of the whole group"), ("show_time", "Show time-based figures (man-hours, FTE, utilisation)")]

router = APIRouter(prefix="/api/admin")


# ===================================================================== employee editor
def _emp_out(db, e, fnames, names):
    return {"code": e.code, "name": e.name, "grade": e.grade, "grade_raw": e.grade_raw or "", "position": e.position or "",
            "function_id": e.function_id, "function": fnames.get(e.function_id, ""), "manager_code": e.manager_code or "",
            "manager_name": names.get(e.manager_code, ""), "emp_type": e.emp_type, "gender": e.gender or "",
            "region": e.region or "", "unit": e.unit_name or "", "external": bool(e.external), "exclude": bool(e.exclude),
            "source": e.source, "verified": bool(e.verified), "overrides": sorted(e.overrides or []),
            "service_role": e.service_role or "", "resigned": bool(e.resigned), "resigned_on": e.resigned_on or "",
            "dc": bool(e.is_dc), "dw": bool(e.is_dw), "direct_reports": 0}


@router.get("/employees")
def list_employees(q: str = "", function_id: Optional[int] = None, show: str = "", user=Depends(require_admin), db: Session = Depends(get_db)):
    fnames = {f.id: f.name for f in db.query(models.Function)}
    names = {c: n for c, n in db.query(models.Employee.code, models.Employee.name)}
    qry = db.query(models.Employee)
    if function_id:
        qry = qry.filter(models.Employee.function_id == function_id)
    if show == "resigned":
        qry = qry.filter(models.Employee.resigned == True)  # noqa
    elif show == "dc":
        qry = qry.filter(models.Employee.is_dc == True)  # noqa: E712
    elif show == "dw":
        qry = qry.filter(models.Employee.is_dw == True)  # noqa: E712
    elif show == "excluded":
        qry = qry.filter(models.Employee.exclude == True)  # noqa
    elif show == "edited":
        qry = qry.filter(models.Employee.overrides.isnot(None))
    for w in q.split():
        qry = qry.filter((models.Employee.name.ilike(f"%{w}%")) | (models.Employee.code.ilike(f"%{w}%")) | (models.Employee.position.ilike(f"%{w}%")))
    rows = qry.order_by(models.Employee.grade_rank.desc(), models.Employee.name).limit(300).all()
    kids = {}
    for code, mc in db.query(models.Employee.code, models.Employee.manager_code):
        if mc:
            kids[mc] = kids.get(mc, 0) + 1
    out = []
    for e in rows:
        r = _emp_out(db, e, fnames, names)
        r["direct_reports"] = kids.get(e.code, 0)
        out.append(r)
    return out


@router.get("/grades")
def grades(user=Depends(require_admin), db: Session = Depends(get_db)):
    seen = {}
    for raw, g, rk in db.query(models.Employee.grade_raw, models.Employee.grade, models.Employee.grade_rank):
        if raw and raw not in seen:
            seen[raw] = {"raw": raw, "grade": g, "rank": rk if rk is not None else -1}
    return sorted(seen.values(), key=lambda x: (-x["rank"], x["raw"]))


class EmpEdit(BaseModel):
    name: Optional[str] = None
    grade_raw: Optional[str] = None
    position: Optional[str] = None
    function_id: Optional[int] = None
    manager_code: Optional[str] = None
    emp_type: Optional[str] = None
    gender: Optional[str] = None
    region: Optional[str] = None
    unit: Optional[str] = None
    external: Optional[bool] = None
    exclude: Optional[bool] = None
    service_role: Optional[str] = None
    resigned: Optional[bool] = None
    resigned_on: Optional[str] = None
    dc: Optional[bool] = None
    dw: Optional[bool] = None
    move_team: bool = False   # with a function change: move everyone below them in the old function too


def _would_loop(db, code, new_mgr):
    by = {c: m for c, m in db.query(models.Employee.code, models.Employee.manager_code)}
    x, n = new_mgr, 0
    while x and n < 200:
        if x == code:
            return True
        x, n = by.get(x), n + 1
    return False


@router.patch("/employees/{code}")
def edit_employee(code: str, body: EmpEdit, user=Depends(require_admin), db: Session = Depends(get_db)):
    e = db.get(models.Employee, code)
    if not e:
        raise HTTPException(404, "Employee not found.")
    ov = set(e.overrides or [])
    changes = []
    d = body.model_dump(exclude_unset=True)
    if d.get("name") is not None and d["name"].strip() and d["name"].strip() != e.name:
        e.name = " ".join(d["name"].split())[:200]
        ov.add("name"); changes.append("name")
    if d.get("position") is not None and d["position"].strip() != (e.position or ""):
        e.position = d["position"].strip()[:250]
        ov.add("position"); changes.append("position")
    if d.get("grade_raw") is not None and d["grade_raw"].strip() and d["grade_raw"].strip() != (e.grade_raw or ""):
        raw = d["grade_raw"].strip()[:80]
        e.grade_raw = raw
        e.grade = grade_label(raw)
        e.grade_rank = grade_rank(raw)
        ov.add("grade"); changes.append("grade")
    if d.get("emp_type") in ("FTE", "FTC") and d["emp_type"] != e.emp_type:
        e.emp_type = d["emp_type"]
        ov.add("emp_type"); changes.append("type")
    if d.get("gender") is not None and d["gender"] in ("m", "f", "") and d["gender"] != (e.gender or ""):
        e.gender = d["gender"]
        ov.add("gender"); changes.append("gender")
    if "manager_code" in d and d["manager_code"] is not None:
        m = code_text(d["manager_code"]) or None
        if m != e.manager_code:
            root = get_setting(db, "root_code")
            if code == root and m:
                raise HTTPException(400, "This employee is the top of the organogram and reports to no one. Change the top in Settings first.")
            if m == code:
                raise HTTPException(400, "An employee cannot report to themselves.")
            if m and not db.get(models.Employee, m):
                raise HTTPException(400, "No employee has that manager code.")
            if m and _would_loop(db, code, m):
                raise HTTPException(400, "That would create a circular reporting line: the new manager reports, directly or indirectly, to this employee.")
            if not m and code != root:
                raise HTTPException(400, "Choose who this employee reports to.")
            e.manager_code = m
            ov.add("manager"); changes.append("reporting line")
    moved_team = 0
    if d.get("function_id") and d["function_id"] != e.function_id:
        fn = db.get(models.Function, d["function_id"])
        if not fn:
            raise HTTPException(400, "Unknown function.")
        old = e.function_id
        if body.move_team:
            kids = {}
            for x in db.query(models.Employee).filter(models.Employee.function_id == old):
                if x.manager_code:
                    kids.setdefault(x.manager_code, []).append(x)
            stack = list(kids.get(e.code, []))
            while stack:
                x = stack.pop()
                x.function_id = fn.id
                x.overrides = sorted(set(x.overrides or []) | {"function"})
                moved_team += 1
                stack.extend(kids.get(x.code, []))
        e.function_id = fn.id
        ov.add("function"); changes.append("function")
    if d.get("region") is not None and d["region"] != (e.region or ""):
        if d["region"] and not db.query(models.Region).filter(models.Region.name == d["region"]).first():
            raise HTTPException(400, "Unknown region.")
        e.region, e.region_source = d["region"] or None, ("manual" if d["region"] else None)
        ov.add("region"); changes.append("region")
    if d.get("unit") is not None and " ".join(d["unit"].split()) != (e.unit_name or ""):
        u = " ".join(d["unit"].split())[:200] or None
        e.unit_name, e.unit_name_source = u, ("manual" if u else None)
        changes.append("unit")
    if d.get("service_role") is not None and d["service_role"] in ("Service", "Support", "") and d["service_role"] != (e.service_role or ""):
        e.service_role, e.service_role_source = d["service_role"] or None, ("manual" if d["service_role"] else None)
        changes.append("service / support")
    if d.get("dc") is not None and d["dc"] != bool(e.is_dc):
        e.is_dc = d["dc"]
        if d["dc"]:
            e.is_dw = False
        changes.append("marked Contract (DC)" if d["dc"] else "no longer Contract (DC)")
    if d.get("dw") is not None and d["dw"] != bool(e.is_dw):
        e.is_dw = d["dw"]
        if d["dw"]:
            e.is_dc = False
        changes.append("marked Daily Wager" if d["dw"] else "no longer Daily Wager")
    if d.get("resigned") is not None and d["resigned"] != bool(e.resigned):
        e.resigned = d["resigned"]
        e.resigned_on = (d.get("resigned_on") or datetime.now().strftime("%Y-%m-%d"))[:10] if d["resigned"] else None
        changes.append("resigned" if d["resigned"] else "no longer resigned")
        if d["resigned"]:   # their team now reports to their line manager
            db.flush()
            n = reassign_resigned_teams(db, {e.code})
            if n:
                changes.append(f"{n} direct reports moved to their line manager")
    elif d.get("resigned_on") and e.resigned:
        e.resigned_on = d["resigned_on"][:10]
    if d.get("external") is not None and d["external"] != bool(e.external):
        e.external = d["external"]; changes.append("external")
    if d.get("exclude") is not None and d["exclude"] != bool(e.exclude):
        e.exclude = d["exclude"]; changes.append("exclude")
    e.overrides = sorted(ov) or None
    if changes:
        audit(db, user, "employee_edit", f"{code}: {', '.join(changes)}" + (f"; {moved_team} team members moved" if moved_team else ""))
    db.commit()
    fnames = {f.id: f.name for f in db.query(models.Function)}
    names = {c: n for c, n in db.query(models.Employee.code, models.Employee.name)}
    out = _emp_out(db, e, fnames, names)
    out["changed"] = changes
    out["moved_team"] = moved_team
    return out


class EmpNew(BaseModel):
    code: str
    name: str
    position: str = ""
    grade: str = ""
    emp_type: str = "FTE"
    function_id: int
    manager_code: str
    region: str = ""
    unit: str = ""
    service_role: str = ""
    gender: str = ""


@router.post("/employees")
def add_employee(body: EmpNew, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Add an employee who is not in the master sheet. They are kept when the master sheet is imported again."""
    code = code_text(body.code)
    name = " ".join((body.name or "").split())[:200]
    if not code or not name:
        raise HTTPException(400, "Employee code and name are both required.")
    if db.get(models.Employee, code):
        raise HTTPException(409, "An employee with this code already exists.")
    fn = db.get(models.Function, body.function_id)
    if not fn:
        raise HTTPException(400, "Choose the function.")
    m = code_text(body.manager_code)
    if not m or not db.get(models.Employee, m):
        raise HTTPException(400, "Choose who this employee reports to.")
    if body.region and not db.query(models.Region).filter(models.Region.name == body.region).first():
        raise HTTPException(400, "Unknown region.")
    raw = (body.grade or "").strip()[:80]
    e = models.Employee(code=code, name=name, grade=grade_label(raw) if raw else "Not verified", grade_raw=raw,
                        grade_rank=grade_rank(raw) if raw else -2, position=(body.position or "").strip()[:250],
                        function_id=fn.id, manager_code=m, emp_type="FTC" if (body.emp_type == "FTC" or is_outsourced(raw)) else "FTE",
                        gender=body.gender if body.gender in ("m", "f") else "", source="added", verified=True,
                        region=body.region or None, region_source="manual" if body.region else None,
                        unit_name=" ".join((body.unit or "").split())[:200] or None, unit_name_source="manual" if (body.unit or "").strip() else None,
                        service_role=body.service_role if body.service_role in ("Service", "Support") else None,
                        service_role_source="manual" if body.service_role in ("Service", "Support") else None,
                        added_by=user.username, added_at=datetime.utcnow())
    db.add(e)
    removed = dict(get_setting(db, "removed_employees") or {})   # a copy, so the change is saved
    if code in removed:   # added back: no longer skipped on import
        removed.pop(code)
        set_setting(db, "removed_employees", removed)
    audit(db, user, "employee_add", f"{code} {name} ({fn.name})")
    db.commit()
    fnames = {f.id: f.name for f in db.query(models.Function)}
    names = {c: n for c, n in db.query(models.Employee.code, models.Employee.name)}
    return _emp_out(db, e, fnames, names)


@router.delete("/employees/{code}")
def remove_employee(code: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Remove an employee and their activities. Their direct reports move to their manager. The employee stays
    removed when the master sheet is imported again (until the admin allows them back)."""
    e = db.get(models.Employee, code)
    if not e:
        raise HTTPException(404, "Employee not found.")
    if code == get_setting(db, "root_code"):
        raise HTTPException(400, "This employee is the top of the organogram. Choose another top in Settings first.")
    kids = db.query(models.Employee).filter(models.Employee.manager_code == code).all()
    for k in kids:
        k.manager_code = e.manager_code
        k.overrides = sorted(set(k.overrides or []) | {"manager"})
    acts = db.query(models.WorkItem).filter(models.WorkItem.employee_code == code).delete()
    db.query(models.ActivityPerformer).filter(models.ActivityPerformer.code == code).delete()
    for u in db.query(models.Unit).filter(models.Unit.lead_code == code):
        u.lead_code = None
    removed = dict(get_setting(db, "removed_employees") or {})   # a copy, so the change is saved
    removed[code] = {"name": e.name, "position": e.position or "", "manager": e.manager_code or "",
                     "function": (db.get(models.Function, e.function_id).name if e.function_id else ""),
                     "at": datetime.now().strftime("%Y-%m-%d %H:%M"), "by": user.username, "source": e.source}
    set_setting(db, "removed_employees", removed)
    mgr = db.get(models.Employee, e.manager_code) if e.manager_code else None
    db.delete(e)
    audit(db, user, "employee_remove", f"{code} {e.name}: {acts} activities removed, {len(kids)} direct reports moved to {mgr.name if mgr else '-'}")
    db.commit()
    return {"ok": True, "activities": acts, "moved": len(kids), "to": mgr.name if mgr else ""}


@router.get("/removed-employees")
def removed_employees(user=Depends(require_admin), db: Session = Depends(get_db)):
    r = get_setting(db, "removed_employees") or {}
    return sorted([{"code": c, **v} for c, v in r.items()], key=lambda x: x.get("at", ""), reverse=True)


@router.delete("/removed-employees/{code}")
def allow_back(code: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Forget a removal: if the employee is still in the master sheet, the next import brings them back."""
    r = dict(get_setting(db, "removed_employees") or {})
    if code not in r:
        raise HTTPException(404, "Not in the removed list.")
    name = r.pop(code).get("name", "")
    set_setting(db, "removed_employees", r)
    audit(db, user, "employee_allow_back", f"{code} {name}")
    db.commit()
    return {"ok": True}


@router.post("/employees/{code}/revert")
def revert_employee(code: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Stop keeping the admin's changes: the next master sheet import sets this employee from the sheet again."""
    e = db.get(models.Employee, code)
    if not e:
        raise HTTPException(404, "Employee not found.")
    e.overrides = None
    audit(db, user, "employee_revert", code)
    db.commit()
    return {"ok": True}


# ===================================================================== data transfer and templates
STAFF_HEAD = ["Employee code", "Employee name", "Function", "Manager code", "Grade", "Type", "Position", "Unit", "Region", "Added by function", "Service / support", "Resigned", "DC", "Daily Wager"]
ACT_HEAD = ["Employee code", "Employee name", "Function", "Unit", "Product", "Process name", "Channel", "Activity description",
            "Activity category", "Frequency", "Avg volume", "Volume type", "Peak volume start of month (avg per day)",
            "Peak volume end of month (avg per day)", "Activity handling", "Employee processing time (min)",
            "Total employee processing time (min)", "Daily man-hours", "Automation opportunity", "Link"]
# activity column -> capture field (for hiding columns the function does not use)
COL_FIELD = {"Product": "product", "Process name": "process", "Channel": "channel", "Activity description": "description",
             "Activity category": "category", "Frequency": "frequency", "Avg volume": "volume", "Volume type": "volume",
             "Peak volume start of month (avg per day)": "peak", "Peak volume end of month (avg per day)": "peak",
             "Activity handling": "handling", "Employee processing time (min)": "minutes", "Automation opportunity": "automation"}


def _fill(ws, head, widths):
    ws.append(head)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="00796B")
        c.alignment = Alignment(wrap_text=True, vertical="top")
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = w
    ws.freeze_panes = "A2"


def build_workbook(db: Session, fns: dict, user, template: bool = False, fields: dict = None) -> bytes:
    """One format for everything: the admin's data transfer and the POC's Excel template (with drop-down
    lists, a name look-up for new rows, and the function's hidden fields hidden)."""
    from openpyxl.worksheet.datavalidation import DataValidation
    c = Calc(db)
    emps = [e for e in db.query(models.Employee) if e.function_id in fns and not (template and e.resigned)]
    emps.sort(key=lambda e: (fns[e.function_id].name.lower(), -(e.grade_rank or 0), e.name))
    codes = {e.code for e in emps}
    heads = set()
    for f in fns:
        heads |= function_heads(db, f)
    work = {}
    for w in db.query(models.WorkItem).order_by(models.WorkItem.employee_code, models.WorkItem.sort, models.WorkItem.id):
        if w.employee_code in codes:
            work.setdefault(w.employee_code, []).append(w)
    wb = Workbook()
    ws = wb.active
    ws.title = "Read me"
    title = "data capture template" if template else "data transfer"
    ws["A1"] = f"HBL Operations Services Employee Portal: {title}"
    ws["A1"].font = Font(bold=True, size=14, color="00403A")
    names = ", ".join(sorted(f.name for f in fns.values())) if len(fns) <= 3 else f"{len(fns)} functions"
    if template:
        lines = [f"{names} · downloaded {datetime.now():%d %b %Y %H:%M} by {user.username}.",
                 "Employees sheet: every employee of the function. Fill in or correct the Unit, Region and Service / support columns (the function head covers all units).",
                 "Activities sheet: one row per employee per activity. Activities already recorded are included, so you can correct them here.",
                 "To add an activity, add a row: type the employee code (the name fills in), then the details. Use the drop-down lists where offered.",
                 "Products: for an activity that covers several products, separate them with a semicolon, for example LC; Guarantee.",
                 "Upload the file in Data capture, Activities, Upload the filled template. Check the file first; nothing changes until you import.",
                 "On upload, the activities of every employee with rows in this file replace that employee's current activities. Employees without rows are left as they are.",
                 "Grey columns are calculated by the portal and can be left as they are. Keep the column headings unchanged."]
    else:
        lines = [f"Exported {datetime.now():%d %b %Y %H:%M} by {user.username}: {len(fns)} function(s), {len(emps)} employees, {sum(len(v) for v in work.values())} activities.",
                 "Import this file in Admin, Data transfer, on the other installation (import the same employee master sheet there first).",
                 "Employees sheet: each employee's unit and region (and, optionally, function and reporting line).",
                 "Activities sheet: one row per employee per activity. On import, the activities of every employee listed here replace that employee's current activities.",
                 "Rows can be corrected in Excel before importing. Keep the column headings unchanged. Total time and daily man-hours are recalculated on import.",
                 "Link: rows with the same link are the same activity copied to colleagues; they stay linked after import."]
    for i, t in enumerate(lines, 3):
        ws.cell(i, 1, t)
    ws.column_dimensions["A"].width = 150
    s = wb.create_sheet("Employees")
    _fill(s, STAFF_HEAD, [14, 30, 34, 14, 14, 7, 34, 28, 14, 10, 14, 10, 7, 11])
    for e in emps:
        s.append([e.code, e.name, fns[e.function_id].name, e.manager_code or "", e.grade_raw or e.grade, e.emp_type, e.position or "",
                  "All units" if e.code in heads else (e.unit_name or ""), e.region or "", "Yes" if e.source == "added" else "", e.service_role or "", "Yes" if e.resigned else "", "Yes" if e.is_dc else "", "Yes" if e.is_dw else ""])
    a = wb.create_sheet("Activities")
    _fill(a, [nature_label() if h == "Activity handling" else h for h in ACT_HEAD], [14, 26, 30, 24, 22, 28, 18, 60, 34, 12, 11, 18, 16, 16, 18, 14, 15, 11, 12, 34])
    n = 1
    for e in emps:
        for w in work.get(e.code, []):
            a.append([e.code, e.name, fns[e.function_id].name, e.unit_name or "", w.product or "", w.process or "", w.channel or "",
                      w.description or "", w.category or "", w.frequency or "Daily", w.volume, vol_labels()[0] if w.volume_type == VOL_FILE else (vol_labels()[1] if w.volume is not None else ""), w.peak_som, w.peak_eom,
                      w.handling or "", w.minutes, round(c.total_minutes(w), 2), round(c.daily_hours(w), 3), w.automation or "", w.link_id or ""])
            n += 1
    L = {h: get_column_letter(i) for i, h in enumerate(ACT_HEAD, 1)}   # column letters by heading
    last = n
    if template:
        grey = PatternFill("solid", fgColor="EEF3F2")
        blank = 400
        tot_col = ACT_HEAD.index("Total employee processing time (min)") + 1
        vol, mins = L["Avg volume"], L["Employee processing time (min)"]
        for r in range(n + 1, n + blank + 1):
            a.cell(r, 2, f'=IFERROR(VLOOKUP(A{r},Employees!$A:$B,2,FALSE),"")')
            a.cell(r, 3, f'=IFERROR(VLOOKUP(A{r},Employees!$A:$C,3,FALSE),"")')
            a.cell(r, 4, f'=IFERROR(VLOOKUP(A{r},Employees!$A:$H,8,FALSE),"")')
            a.cell(r, tot_col, f'=IF(AND(ISNUMBER({vol}{r}),ISNUMBER({mins}{r})),{vol}{r}*{mins}{r},"")')
        last = n + blank
        for col in (2, 3, 4, tot_col, tot_col + 1, len(ACT_HEAD)):
            for r in range(2, last + 1):
                a.cell(r, col).fill = grey
        lists = [(L["Frequency"], '"' + ",".join(freq_names())[:250] + '"'), (L["Activity handling"], '"' + ",".join(HANDLING)[:250] + '"'),
                 (L["Automation opportunity"], '"Yes,No"'), (L["Volume type"], '"' + ",".join(vol_labels()) + '"')]
        for col, formula in lists:
            dv = DataValidation(type="list", formula1=formula, allow_blank=True, showErrorMessage=True,
                                errorTitle="Choose from the list", error="Please choose one of the values in the list.")
            a.add_data_validation(dv)
            dv.add(f"{col}2:{col}{last}")
        dv = DataValidation(type="list", formula1=f"Employees!$A$2:$A${len(emps) + 1}", allow_blank=True, showErrorMessage=True,
                            errorTitle="Unknown employee code", error="Use an employee code from the Employees sheet.")
        a.add_data_validation(dv)
        dv.add(f"A2:A{last}")
        num = DataValidation(type="decimal", operator="greaterThanOrEqual", formula1="0", allow_blank=True, showErrorMessage=True,
                             errorTitle="Number needed", error="Enter a number of 0 or more.")
        a.add_data_validation(num)
        for col in (L["Avg volume"], L["Peak volume start of month (avg per day)"], L["Peak volume end of month (avg per day)"], L["Employee processing time (min)"]):
            num.add(f"{col}2:{col}{last}")
        sv = DataValidation(type="list", formula1='"Service,Support"', allow_blank=True)
        s.add_data_validation(sv)
        sv.add(f"K2:K{len(emps) + 1}")
        regs = [r.name for r in db.query(models.Region).order_by(models.Region.sort, models.Region.name)]
        if regs:
            ls = wb.create_sheet("Lists")
            for i, r in enumerate(regs, 1):
                ls.cell(i, 1, r)
            ls.sheet_state = "hidden"
            rv = DataValidation(type="list", formula1=f"Lists!$A$1:$A${len(regs)}", allow_blank=True)
            s.add_data_validation(rv)
            rv.add(f"I2:I{len(emps) + 1}")
        for col in (3, 4, 5, 6, 10):   # columns the POC does not change on the Staff sheet
            for r in range(2, len(emps) + 2):
                s.cell(r, col).fill = grey
        if fields:
            for i, h in enumerate(ACT_HEAD, 1):
                if fields.get(COL_FIELD.get(h)) == "hidden":
                    a.column_dimensions[get_column_letter(i)].hidden = True
            a.column_dimensions[L["Link"]].hidden = True
            for i, h in enumerate(ACT_HEAD, 1):
                if fields.get(COL_FIELD.get(h)) == "required":
                    a.cell(1, i).value = (nature_label() if h == "Activity handling" else h) + " *"
    for row in a.iter_rows(min_row=2, max_row=last, min_col=8, max_col=8):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    if not template:
        fq = wb.create_sheet("Frequencies")
        _fill(fq, ["Frequency", "Working days in one period"], [20, 26])
        for nm, dd in frequency_list(db):
            fq.append([nm, dd])
        st = wb.create_sheet("Settings")
        _fill(st, ["Setting", "Value", "Key"], [44, 20, 22])
        for k, label in SETTING_KEYS:
            st.append([label, get_setting(db, k), k])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def xlsx_response(data: bytes, name: str):
    return StreamingResponse(io.BytesIO(data), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename={name}"})


def safe(s):
    return "".join(ch if ch.isalnum() else "_" for ch in s)[:30]


@router.get("/transfer/export")
def transfer_export(functions: str = Query(""), user=Depends(require_admin), db: Session = Depends(get_db)):
    """Units, regions and activities of the chosen functions (all if none), in a workbook that Import reads back."""
    want = {int(x) for x in functions.split(",") if x.strip().isdigit()}
    fns = {f.id: f for f in db.query(models.Function) if not want or f.id in want}
    data = build_workbook(db, fns, user)
    audit(db, user, "transfer_export", f"{len(fns)} functions")
    db.commit()
    tag = "all_functions" if not want else (safe(next(iter(fns.values())).name) if len(fns) == 1 else f"{len(fns)}_functions")
    return xlsx_response(data, f"portal_data_{tag}_{datetime.now():%Y%m%d_%H%M}.xlsx")


def _num(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    try:
        f = float(str(v).replace(",", "").strip())
        return f if f >= 0 else None
    except ValueError:
        return "bad"


def _pick(v, options):
    s = str(v or "").strip()
    for o in options:
        if s.lower() == o.lower():
            return o
    return "" if not s else None


def _act_key(x) -> tuple:
    """An activity's identity across a re-import: products, process, channel, description and category."""
    if isinstance(x, dict):
        vals = (clean_products(x.get("product")), x.get("process name"), x.get("channel"), x.get("activity description"), x.get("activity category"))
    else:
        vals = (x.product, x.process, x.channel, x.description, x.category)
    return tuple(" ".join(str(v or "").split()).lower() for v in vals)


def clean_products(v) -> str:
    parts = [" ".join(p.split()) for p in str(v or "").replace(",", ";").split(";")]
    return "; ".join(dict.fromkeys(p for p in parts if p))[:200]


def read_workbook(content: bytes):
    try:
        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    except Exception:
        raise HTTPException(400, "The file could not be read as an Excel workbook.")
    if not {"Employees", "Staff"} & set(wb.sheetnames) and "Activities" not in wb.sheetnames:
        raise HTTPException(400, "This file does not have the portal's Employees and Activities sheets. Download the template from the portal and fill that in.")
    return wb


def import_data(db: Session, wb, user, apply_structure=False, dry_run=False, only_fid=None, apply_settings=True) -> dict:
    """Units and regions from the Employees sheet are applied; the activities of each employee in the Activities sheet
    replace their current activities. only_fid limits everything to one function (a POC's upload)."""
    rep = {"staff_rows": 0, "staff_updated": 0, "created": 0, "moved": 0, "positions": 0, "activities": 0, "employees_replaced": 0,
           "not_found": [], "other_function": [], "problems": [], "dry_run": dry_run, "settings": []}
    fn_by_name = {f.name.strip().lower(): f for f in db.query(models.Function)}
    for f in db.query(models.Function):   # the HR sheet's name of a renamed function is understood too
        fn_by_name.setdefault((f.hr_name or f.name).strip().lower(), f)
    regions = {r.name.lower(): r.name for r in db.query(models.Region)}
    heads = function_heads(db, only_fid) if only_fid else set()

    def rows(name):
        if name == "Employees" and name not in wb.sheetnames:
            name = "Staff"   # templates downloaded before the sheet was renamed
        if name not in wb.sheetnames:
            return []
        it = wb[name].iter_rows(values_only=True)
        head = [str(h or "").strip().rstrip("*").strip().lower().replace("staff processing time", "employee processing time") for h in next(it, [])]
        nh = nature_headings()
        head = ["nature of work" if h in nh else h for h in head]   # the current heading of the column, or an earlier one
        out = []
        for n, r in enumerate(it, 2):
            d = {head[i]: r[i] for i in range(min(len(head), len(r))) if head[i]}
            if not code_text(d.get("employee code")):
                if any(v not in (None, "") for k, v in d.items() if k not in ("employee name", "function", "unit", "total employee processing time (min)", "daily man-hours")):
                    rep["problems"].append(f"{name} row {n}: no employee code; row skipped.")
                continue
            out.append((n, d))
        return out

    def allowed(e, code):
        if not e:
            if code not in rep["not_found"]:
                rep["not_found"].append(code)
            return False
        if only_fid and e.function_id != only_fid:
            if code not in rep["other_function"]:
                rep["other_function"].append(code)
            return False
        return True

    if apply_settings and not only_fid:
        keys = dict(SETTING_KEYS)
        if "Settings" in wb.sheetnames:
            it = wb["Settings"].iter_rows(values_only=True)
            hd = [str(h or "").strip().lower() for h in next(it, [])]
            for r in it:
                d = {hd[i]: r[i] for i in range(min(len(hd), len(r))) if hd[i]}
                k, v = str(d.get("key") or "").strip(), d.get("value")
                if k not in keys or v in (None, ""):
                    continue
                if k in ("productive_hours", "working_days_week", "working_days_month", "senior_rank", "large_team"):
                    try:
                        v = float(v) if k in ("productive_hours", "working_days_week", "working_days_month") else int(float(v))
                    except ValueError:
                        continue
                if k == "root_code":
                    v = code_text(v)
                    if not db.get(models.Employee, v):
                        continue
                if get_setting(db, k) != v:
                    set_setting(db, k, v)
                    rep["settings"].append(f"{keys[k]}: {v}")

    if apply_settings and not only_fid and "Frequencies" in wb.sheetnames:
        it = wb["Frequencies"].iter_rows(values_only=True)
        next(it, None)
        have = {f.name.lower(): f for f in db.query(models.Frequency)}
        for r in it:
            if not r or not r[0]:
                continue
            nm = str(r[0]).strip()[:40]
            try:
                dd = float(r[1]) if len(r) > 1 and r[1] not in (None, "") else 1.0
            except (TypeError, ValueError):
                dd = 1.0
            f = have.get(nm.lower())
            if not f:
                db.add(models.Frequency(name=nm, days=dd, sort=99))
                rep["settings"].append(f"Frequency added: {nm} ({dd:g} days)")
            elif float(f.days or 0) != dd:
                f.days = dd
                rep["settings"].append(f"Frequency {nm}: {dd:g} days")
        db.flush()
        from ..logic import load_required
        load_required(db)

    for n, r in rows("Employees"):
        rep["staff_rows"] += 1
        code = code_text(r.get("employee code"))
        e = db.get(models.Employee, code)
        fname = str(r.get("function") or "").strip().lower()
        if not e and apply_structure and not only_fid and str(r.get("added by function") or "").strip().lower() == "yes" and fname in fn_by_name and r.get("employee name"):
            raw_g = str(r.get("grade") or "").strip()[:80]   # labelled as at import: outsourced staff show as FTC
            e = models.Employee(code=code, name=str(r["employee name"]).strip()[:200], grade=grade_label(raw_g) if raw_g else "Not verified",
                                grade_raw=raw_g, grade_rank=grade_rank(raw_g) if raw_g else -2, position=str(r.get("position") or "")[:250],
                                function_id=fn_by_name[fname].id, emp_type="FTC" if (str(r.get("type") or "").upper() == "FTC" or is_outsourced(raw_g)) else "FTE",
                                manager_code=code_text(r.get("manager code")) or None, source="added", verified=False,
                                added_by=user.username, added_at=datetime.utcnow())
            db.add(e)
            db.flush()
            rep["created"] += 1
        if not allowed(e, code):
            continue
        changed = False
        unit = " ".join(str(r.get("unit") or "").split())[:200] or None
        if unit and unit.lower() == "all units":
            unit = None
        if e.code not in heads and unit != (e.unit_name or None) and (unit or not only_fid):
            e.unit_name, e.unit_name_source = unit, ("manual" if unit else None)
            changed = True
        reg = str(r.get("region") or "").strip()
        if reg:
            if reg.lower() not in regions:
                if only_fid:
                    rep["problems"].append(f"Employees row {n}: region '{reg}' is not in the region list; not applied. Ask the admin to add it.")
                    reg = ""
                else:
                    db.add(models.Region(name=reg, sort=99))
                    regions[reg.lower()] = reg
            if reg and regions[reg.lower()] != e.region:
                e.region, e.region_source = regions[reg.lower()], "manual"
                changed = True
        role = _pick(r.get("service / support"), ["Service", "Support"])
        full = apply_structure and not only_fid   # a full transfer mirrors the source, blanks included
        if (role or full) and (role or "") != (e.service_role or ""):
            e.service_role, e.service_role_source = (role or None), ("manual" if role else None)
            changed = True
        if "dc" in r:   # DC: "Yes" marks; a blank clears only in a full transfer
            dc = str(r.get("dc") or "").strip().lower() == "yes"
            if dc != bool(e.is_dc) and (dc or full):
                e.is_dc = dc
                if dc:
                    e.is_dw = False
                changed = True
        if "daily wager" in r:   # Daily Wager: same rule
            dw = str(r.get("daily wager") or "").strip().lower() == "yes"
            if dw != bool(e.is_dw) and (dw or full):
                e.is_dw = dw
                if dw:
                    e.is_dc = False
                changed = True
        if apply_structure and not only_fid:
            rs = str(r.get("resigned") or "").strip().lower() == "yes"
            if rs != bool(e.resigned):
                e.resigned, e.resigned_on = rs, (datetime.now().strftime("%Y-%m-%d") if rs else None)
                if rs:
                    db.flush()
                    reassign_resigned_teams(db, {e.code})
                changed = True
            if fname and fname in fn_by_name and fn_by_name[fname].id != e.function_id:
                e.function_id = fn_by_name[fname].id
                e.overrides = sorted(set(e.overrides or []) | {"function"})
                rep["moved"] += 1
                changed = True
            elif fname and fname not in fn_by_name:
                rep["problems"].append(f"Employees row {n}: function '{r.get('function')}' does not exist here; function not changed.")
            pos = " ".join(str(r.get("position") or "").split())[:250]
            if pos and pos != (e.position or ""):   # a blank position leaves it as it is
                e.position = pos
                e.overrides = sorted(set(e.overrides or []) | {"position"})
                rep["positions"] = rep.get("positions", 0) + 1
                changed = True
            m = code_text(r.get("manager code")) or None
            if m and m != e.manager_code:
                if m == e.code or not db.get(models.Employee, m) or _would_loop(db, e.code, m):
                    rep["problems"].append(f"Employees row {n}: manager {m} for {e.code} not applied (not found or circular).")
                else:
                    e.manager_code = m
                    e.overrides = sorted(set(e.overrides or []) | {"manager"})
                    changed = True
        rep["staff_updated"] += changed

    acts = {}
    for n, r in rows("Activities"):
        acts.setdefault(code_text(r.get("employee code")), []).append((n, r))
    touched = set()
    for code, items in acts.items():
        e = db.get(models.Employee, code)
        if not allowed(e, code):
            continue
        new = []
        old_vt = {_act_key(w): w.volume_type for w in db.query(models.WorkItem).filter(models.WorkItem.employee_code == code) if w.volume_type}
        for n, r in items:
            st = ""   # service / support is now set per employee (Employees sheet)
            fq = _pick(r.get("frequency"), freq_names()) or freq_names()[0]
            if "nature of work" in r:
                hd = _pick(nature_value(r.get("nature of work")), HANDLING)
            else:   # a template from before version 2.11: the column was "Activity handling" with the old names
                old = str(r.get("activity handling") or "").strip()
                hd = _pick(NATURE_LEGACY.get(old.lower(), old), HANDLING)
            au = _pick(r.get("automation opportunity"), ["Yes", "No"])
            if "volume type" in r:
                vt = vol_type_value(r.get("volume type"))
            else:   # a file from before version 2.12: the volume type stays as it was for the same activity
                vt = old_vt.get(_act_key(r), "")
            nums = {k: _num(r.get(h)) for k, h in (("volume", "avg volume"), ("peak_som", "peak volume start of month (avg per day)"),
                                                   ("peak_eom", "peak volume end of month (avg per day)"), ("minutes", "employee processing time (min)"))}
            bad = [k for k, v in nums.items() if v == "bad"] + [lab for lab, v in (("frequency", fq), ("handling", hd), ("automation", au), ("volume type", vt)) if v is None]
            if bad:
                rep["problems"].append(f"Activities row {n} ({code}): could not read {', '.join(bad)}; left empty.")
            nums = {k: (None if v == "bad" else v) for k, v in nums.items()}
            new.append(models.WorkItem(employee_code=code, product=clean_products(r.get("product")), process=str(r.get("process name") or "").strip()[:250],
                                       channel=str(r.get("channel") or "").strip()[:200], description=str(r.get("activity description") or "").strip()[:4000],
                                       category=" ".join(str(r.get("activity category") or "").split())[:200], service_type=st or "", frequency=fq,
                                       handling=hd or "", automation=au or "", volume_type=vt or "", link_id=(str(r.get("link") or "").strip()[:32] or None),
                                       sort=len(new) + 1, created_by=user.username, **nums))
        db.query(models.WorkItem).filter(models.WorkItem.employee_code == code).delete()
        for w in new:
            db.add(w)
        rep["activities"] += len(new)
        rep["employees_replaced"] += 1
        touched.add(e.function_id)
        if not e.unit_name and e.code not in heads and items and items[0][1].get("unit") and str(items[0][1]["unit"]).lower() != "all units":
            e.unit_name, e.unit_name_source = " ".join(str(items[0][1]["unit"]).split())[:200], "manual"
    for f in touched:
        fn = db.get(models.Function, f)
        if fn and fn.status == "Not started":
            fn.status, fn.status_at = "In progress", datetime.utcnow()
    for k in ("not_found", "other_function", "problems"):
        rep[k] = rep[k][:200]
    if dry_run:
        db.rollback()
    return rep


@router.post("/transfer/import")
async def transfer_import(file: UploadFile = File(...), apply_structure: bool = Form(False), dry_run: bool = Form(False),
                          user=Depends(require_admin), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload the data transfer workbook (.xlsx) exported from the portal.")
    rep = import_data(db, read_workbook(await file.read()), user, apply_structure, dry_run)
    if not dry_run:
        audit(db, user, "transfer_import", f"{file.filename}: {rep['staff_updated']} staff, {rep['activities']} activities for {rep['employees_replaced']} employees")
        db.commit()
    return rep
