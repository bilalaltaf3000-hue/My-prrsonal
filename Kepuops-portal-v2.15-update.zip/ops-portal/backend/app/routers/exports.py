"""Exports: executive PDF, PowerPoint deck, standalone HTML report and a full Excel workbook.
All respect the user's access rights and use the same calculations as the dashboard."""
import html
import io
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..logic import HANDLING, Calc, employee_work, function_heads, hide_resigned, nature_label, vol_labels, VOL_FILE
from ..metrics import build_report
from ..security import audit, get_setting, in_units, merge_units, read_ids, require_export, sees_everything, unit_scope

router = APIRouter(prefix="/api/export")

TEAL_DEEP, TEAL, MID, SOFT, FTC_C = "00403A", "00796B", "1A9A8C", "D5EDE9", "8FCCC3"
AMBER, CORAL, INK, INK2, INK3, LINE, BG = "C98A00", "BF4E3A", "0F2E2A", "4A6561", "7D9490", "D8E3E1", "EEF3F2"
PAL = ["00796B", "2E6F8E", "C9A227", "4DB6AC", "8E7DBE", "D17A5A", "0E5C56", "7FB069", "5C9EAD", "3B8B5F", "A06A9A", "1F4E79", "6A8D92", "B5895B", "26A69A"]
MIME = {"summary": "application/pdf", "pdf": "application/pdf", "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "html": "text/html; charset=utf-8", "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}


def _scope(user, db, function_ids):
    allowed = read_ids(user, db)
    if not allowed:
        raise HTTPException(403, "You do not have access to any function.")
    if function_ids:
        if not function_ids <= allowed:
            raise HTTPException(403, "You do not have access to one of those functions.")
        return (None if sees_everything(user) else allowed), function_ids
    return (None if sees_everything(user) else allowed), None


def fmt(n):
    try:
        return f"{int(round(n)):,}"
    except Exception:
        return str(n)


@router.get("/{kind}")
def export(kind: str, function_id: Optional[int] = Query(None), functions: str = Query(""), include_flagged: bool = Query(True),
           units: List[str] = Query([]), user=Depends(require_export), db: Session = Depends(get_db)):
    if kind not in MIME:
        raise HTTPException(404, "Unknown export format.")
    want = {int(x) for x in functions.split(",") if x.strip().isdigit()}
    if function_id:
        want.add(function_id)
    allowed, fids = _scope(user, db, want or None)
    uscope = merge_units(unit_scope(user), units, fids or allowed or {f.id for f in db.query(models.Function.id)})
    rep = build_report(db, allowed, fids, include_flagged, user.full_name or user.username, uscope)
    rep["_uscope"] = uscope
    if uscope:
        picked = sorted({u for us in uscope.values() for u in us})
        if picked:
            rep["title"] = f"{rep['title']}: {', '.join(picked[:3])}{' and more' if len(picked) > 3 else ''}"
    scope = fids if fids else allowed
    data = {"summary": make_summary, "pdf": make_pdf, "pptx": make_pptx, "html": make_html, "xlsx": make_xlsx}[kind](rep, db, scope, rep["function_id"])
    audit(db, user, f"export_{kind}", rep["title"])
    db.commit()
    safe = "".join(c if c.isalnum() else "_" for c in rep["title"])[:40].strip("_") or "report"
    name = f"{safe}_summary_{datetime.now():%Y%m%d_%H%M}.pdf" if kind == "summary" else f"{safe}_{datetime.now():%Y%m%d_%H%M}.{kind}"
    return StreamingResponse(io.BytesIO(data), media_type=MIME[kind], headers={"Content-Disposition": f"attachment; filename={name}"})


def vshort(n):
    """Volumes in short form: 950, 1.5K, 150K, 1.2M."""
    v = float(n or 0)
    if not v:
        return "-"
    for d, u in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(v) >= d:
            x = v / d
            return (f"{round(x):,}" if abs(x) >= 100 else f"{round(x, 1):g}") + u
    return f"{round(v):,}"


def make_summary(rep, db, allowed, fid):
    """One page for the executive review: the headline figures, the activity themes and the functions (or regions)."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.pdfgen import canvas as rl_canvas
    from reportlab.platypus import Paragraph, Table, TableStyle
    c = lambda h: colors.HexColor("#" + h)
    W, H = landscape(A4)
    M = 28
    buf = io.BytesIO()
    cv = rl_canvas.Canvas(buf, pagesize=landscape(A4))
    cv.setTitle(f"{rep['title']}: executive summary")
    labels = get_setting(db, "labels") or {}
    lab = lambda k, d: labels.get(k) or d
    k, w = rep["kpi"], rep["work"]
    vf, vt = lab("vol.file", "File Based"), lab("vol.txn", "Activity Based")
    svc = sum(r["Service"] for r in rep["regions"]); sup = sum(r["Support"] for r in rep["regions"])
    # header band
    cv.setFillColor(c("00403A")); cv.rect(0, H - 64, W, 64, stroke=0, fill=1)
    cv.setFillColor(colors.white); cv.setFont("Helvetica-Bold", 20); cv.drawString(M, H - 34, rep["title"][:70])
    cv.setFillColor(c("9FD0C8")); cv.setFont("Helvetica", 10); cv.drawString(M, H - 51, "Executive summary  ·  " + datetime.now().strftime("%d %B %Y"))

    def tile(x, y, wd, ht, label, value, sub=None, dark=True, pair=None):
        cv.setFillColor(c("00564E") if dark else c("F2F6F5")); cv.roundRect(x, y, wd, ht, 7, stroke=0, fill=1)
        cv.setFillColor(c("B8DDD7") if dark else c(INK3)); cv.setFont("Helvetica-Bold", 7.5); cv.drawString(x + 10, y + ht - 15, label.upper())
        if pair:
            half = (wd - 20) / 2
            for i, (pl, pv, col) in enumerate(pair):
                px = x + 10 + i * half
                cv.setFillColor(c(col)); cv.circle(px + 3, y + ht - 29, 2.6, stroke=0, fill=1)
                cv.setFillColor(c("DDF1EE")); cv.setFont("Helvetica", 7.5); cv.drawString(px + 9, y + ht - 31.5, pl)
                cv.setFillColor(colors.white); cv.setFont("Helvetica-Bold", 17); cv.drawString(px, y + 10, pv)
            return
        cv.setFillColor(colors.white if dark else c(INK)); cv.setFont("Helvetica-Bold", 20); cv.drawString(x + 10, y + 13 if not sub else y + 19, value)
        if sub:
            cv.setFillColor(c("A9D4CD") if dark else c(INK3)); cv.setFont("Helvetica", 7.5); cv.drawString(x + 10, y + 8, sub)

    # row 1: the structure
    y1, th, gap = H - 64 - 14 - 56, 56, 8
    tw = (W - 2 * M - 5 * gap) / 6
    pct = lambda a, b: f"{round(a / b * 100)}%" if b else "-"
    row1 = [(lab("dash.total", "Total Employees"), fmt(k["total"]), f"{k['functions']} functions" if k["functions"] > 1 else None),
            (lab("dash.fte", "FTE"), fmt(k["fte"]), pct(k["fte"], k["total"]) + " of employees"),
            (lab("dash.ftc", "FTC"), fmt(k["ftc"]), pct(k["ftc"], k["total"]) + " of employees"),
            (lab("dash.layers", "Layers"), fmt(k["layers"]), None),
            (lab("dash.managers", "Managers"), fmt(k["managers"]), f"Average span {k['avg_span']}"),
            (lab("dash.svc", "Service or Support"), f"{fmt(svc)} / {fmt(sup)}", f"Service {pct(svc, svc + sup)} · Support {pct(sup, svc + sup)}")]
    for i, (l, v, sb) in enumerate(row1):
        tile(M + i * (tw + gap), y1, tw, th, l, v, sb)
    # row 2: the activities
    y2 = y1 - gap - th
    vol = (w.get("volume") or {})
    has_vol = (vol.get("per_day") or 0) > 0
    show_th = bool(get_setting(db, "show_themes")) and any(t["name"] != "No Theme" for t in w.get("themes", []))
    row2 = [(lab("ins.employees", "Employees") + " with activities", fmt(w["staff_with_work"]), None),
            (lab("ins.activities", "Activities"), fmt(w["activities"]), None),
            ((lab("ins.themes", "Activity Themes"), fmt(sum(1 for t in w["themes"] if t["name"] != "No Theme")), None) if show_th
             else (lab("ins.categories", "Activity Categories"), fmt(sum(1 for x in w["categories"] if x["name"] != "Not categorised")), None)),
            (lab("ins.auto", "Automation Candidates"), fmt(w["automation"]["activities"]), pct(w["automation"]["activities"], w["activities"]) + " of activities")]
    n2 = len(row2) + (2 if has_vol else 0)
    tw2 = (W - 2 * M - (n2 - 1) * gap) / n2
    for i, (l, v, sb) in enumerate(row2):
        tile(M + i * (tw2 + gap), y2, tw2, th, l, v, sb, dark=False)
    if has_vol:
        fpd = vol.get("file_per_day") or 0
        tile(M + len(row2) * (tw2 + gap), y2, 2 * tw2 + gap, th, lab("ins.volume", "Avg Daily Volume"), "",
             pair=[(vt, vshort(vol["per_day"] - fpd), "7FD3C6"), (vf, vshort(fpd), "D9BE8A")])
    # tables
    cell = ParagraphStyle("c", fontName="Helvetica", fontSize=8, leading=9.5, textColor=c(INK))
    hcell = ParagraphStyle("h", fontName="Helvetica-Bold", fontSize=7, leading=8, textColor=colors.white)
    hnum = ParagraphStyle("hn", parent=hcell, alignment=2)
    opps = [o for o in rep.get("opps", []) if o["n"]][:6]
    strip_top = 112 if opps else 30            # the structure findings along the bottom
    def table(rows, widths, num_from, avail):
        rows = [[Paragraph(html.escape(str(h)), hcell if i < num_from else hnum) for i, h in enumerate(rows[0])]] + rows[1:]
        rh = max(15, min(22, (avail - 22) / max(1, len(rows) - 1)))
        t = Table(rows, colWidths=widths, rowHeights=[22] + [rh] * (len(rows) - 1))
        st = [("FONT", (0, 0), (-1, -1), "Helvetica", 8), ("TEXTCOLOR", (0, 0), (-1, -1), c(INK)),
              ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("BACKGROUND", (0, 0), (-1, 0), c(TEAL_DEEP)),
              ("LINEBELOW", (0, 1), (-1, -1), 0.35, c(LINE)), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("ALIGN", (num_from, 0), (-1, -1), "RIGHT"),
              ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2), ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
        for r in range(2, len(rows), 2):
            st.append(("BACKGROUND", (0, r), (-1, r), c("F6F9F8")))
        t.setStyle(TableStyle(st))
        return t
    top_y = y2 - 22
    left_w = (W - 2 * M) * 0.6
    right_w = W - 2 * M - left_w - 16
    def heading(x, y, text):
        cv.setFillColor(c(INK)); cv.setFont("Helvetica-Bold", 10.5); cv.drawString(x, y, text)
    if show_th:
        items = [t for t in w["themes"] if t["name"] != "No Theme"][:10]
        heading(M, top_y, f"Top {len(items)} {lab('ins.themepanel', 'Activity Themes')}")
        multi = len(rep["fstats"]) > 1   # the functions column only when several functions are on the page
        head = ["#", "Activity Theme"] + (["Functions"] if multi else []) + ["Employees", "FTE / FTC", "Activities"] + ([vt, vf] if has_vol else [])
        rows = [head] + [[i + 1, Paragraph(html.escape(t["name"]), cell)] + ([t.get("functions", "")] if multi else []) + [fmt(t["staff"]), f"{t.get('fte_staff', 0)} / {t.get('ftc_staff', 0)}",
                          fmt(t["activities"])] + ([vshort((t.get("per_day") or 0) - (t.get("file_per_day") or 0)), vshort(t.get("file_per_day"))] if has_vol else [])
                         for i, t in enumerate(items)]
        fixed = [16, None] + ([46] if multi else []) + [50, 52, 50] + ([62, 48] if has_vol else [])
    else:
        items = [x for x in w["categories"] if x["name"] != "Not categorised"][:10]
        heading(M, top_y, f"Top {len(items)} {lab('ins.categories', 'Activity Categories')}")
        head = ["#", "Activity Category", "Employees", "Activities"]
        rows = [head] + [[i + 1, Paragraph(html.escape(x["name"]), cell), fmt(x["staff"]), fmt(x["activities"])] for i, x in enumerate(items)]
        fixed = [16, None, 60, 60]
    fixed[1] = left_w - sum(v for v in fixed if v)
    if items:
        t = table(rows, fixed, 2, top_y - 8 - strip_top)
        _, ht = t.wrapOn(cv, left_w, 400); t.drawOn(cv, M, top_y - 8 - ht)
    # right: the functions (or, for one function, the regions)
    rx = M + left_w + 16
    if len(rep["fstats"]) > 1:
        fs = rep["fstats"]
        heading(rx, top_y, "Employees by Function")
        shown = fs[:10]
        rows = [["Function", "Employees", "FTE", "FTC", "Avg Span"]] + [[Paragraph(html.escape(s["name"]), cell), fmt(s["hc"]), fmt(s["fte"]), fmt(s["ftc"]), f"{s['span']:.0f}" if s["span"] else "-"] for s in shown]
        if len(fs) > 10:
            rest = fs[10:]
            rows.append([f"Other {len(rest)} functions", fmt(sum(s["hc"] for s in rest)), fmt(sum(s["fte"] for s in rest)), fmt(sum(s["ftc"] for s in rest)), ""])
        ws = [None, 50, 40, 40, 44]
    else:
        regs = [r for r in rep["regions"]][:10]
        heading(rx, top_y, "Employees by Region")
        rows = [["Region", "Employees", "FTE", "FTC", "Service", "Support"]] + [[r["region"], fmt(r["total"]), fmt(r["fte"]), fmt(r["ftc"]), fmt(r["Service"]), fmt(r["Support"])] for r in regs]
        ws = [None, 46, 34, 34, 40, 40]
    ws[0] = right_w - sum(v for v in ws if v)
    t = table(rows, ws, 1, top_y - 8 - strip_top)
    _, ht = t.wrapOn(cv, right_w, 400); t.drawOn(cv, rx, top_y - 8 - ht)
    if opps:   # structure findings: the count and what it is
        heading(M, strip_top - 16, "Structure Findings")
        bw = (W - 2 * M - (len(opps) - 1) * gap) / len(opps)
        for i, o in enumerate(opps):
            x = M + i * (bw + gap)
            cv.setFillColor(c("F2F6F5")); cv.roundRect(x, 30, bw, 58, 6, stroke=0, fill=1)
            cv.setFillColor(c(TEAL)); cv.rect(x, 30, 3, 58, stroke=0, fill=1)
            cv.setFillColor(c(INK)); cv.setFont("Helvetica-Bold", 17); cv.drawString(x + 11, 64, fmt(o["n"]))
            cv.setFillColor(c(INK3)); cv.setFont("Helvetica", 7); cv.drawString(x + 11 + cv.stringWidth(fmt(o["n"]), "Helvetica-Bold", 17) + 5, 65, o["u"])
            p = Paragraph(html.escape(o["t"]), ParagraphStyle("o", fontName="Helvetica", fontSize=7.6, leading=9, textColor=c(INK2)))
            _, ph = p.wrapOn(cv, bw - 18, 30); p.drawOn(cv, x + 11, 56 - ph)
    # footer
    cv.setFillColor(c(INK3)); cv.setFont("Helvetica", 7.5); cv.drawCentredString(W / 2, 14, "Powered by Operations Services")
    cv.showPage(); cv.save()
    return buf.getvalue()


def headline(rep):
    k = rep["kpi"]
    return (f"{fmt(k['total'])} employees across {k['functions']} function{'s' if k['functions'] != 1 else ''}, led through "
            f"{fmt(k['managers'])} managers and up to {k['layers']} layers. "
            f"{round(k['ftc'] / max(k['total'], 1) * 100)}% of employees are FTC.")


def h1(v):
    return f"{v:,.1f}"


def work_lines(rep):
    """Key figures from the recorded activities, as (label, value) pairs."""
    w = rep["work"]
    t = w["types"]
    if not rep.get("show_time"):
        return [("Employees with activities recorded", fmt(w['staff_with_work'])),
                ("Activities", fmt(w["activities"])),
                ("Service / support employees", f"{fmt(t['Service']['staff_classified'])} / {fmt(t['Support']['staff_classified'])}"),
                ("Employees not yet marked service or support", fmt(w.get("unclassified", 0))),
                ("Activity categories", fmt(len([x for x in w["categories"] if x["name"] != "Not categorised"]))),
] + ([("Activities marked for automation", f"{fmt(w['automation']['activities'])} ({fmt(w['automation']['staff'])} employees)")] if "automation" in w.get("fields", ["automation"]) else [])
    return [("Employees with activities recorded", fmt(w['staff_with_work'])),
            ("Activities", fmt(w["activities"])),
            ("Daily man-hours (FTE equivalent)", f"{h1(w['hours'])} ({w['fte']:.1f} FTE)"),
            ("Service work, daily man-hours", f"{h1(t['Service']['hours'])} ({t['Service']['fte']:.1f} FTE)"),
            ("Support work, daily man-hours", f"{h1(t['Support']['hours'])} ({t['Support']['fte']:.1f} FTE)"),
            ("Service / support employees", f"{fmt(t['Service']['staff_classified'])} / {fmt(t['Support']['staff_classified'])}"),
            ("Automation opportunity, daily man-hours", f"{h1(w['automation']['hours'])} ({w['automation']['fte']:.1f} FTE, {fmt(w['automation']['activities'])} activities)"),
            ("Peak day, start / end of month (FTE)", f"{w['peak_som_fte']:.1f} / {w['peak_eom_fte']:.1f}")]


def region_rows(rep):
    return [[r["region"], fmt(r["total"]), fmt(r["fte"]), fmt(r["ftc"]), fmt(r["Service"]), fmt(r["Support"]), fmt(r["none"])]
            for r in rep["regions"]]


def hand_table(rep):
    T = rep.get("show_time")
    head = [nature_label(), "Activities", "Daily man-hours", "FTE"] if T else [nature_label(), "Activities", "Employees", "Share"]
    tot = max(1, rep["work"]["activities"])
    rows = [[x["name"], fmt(x["activities"]), h1(x["hours"]), f"{x['fte']:.1f}"] if T else [x["name"], fmt(x["activities"]), fmt(x["staff"]), f"{round(x['activities'] / tot * 100)}%"]
            for x in rep["work"]["handling"]]
    return head, rows


def cat_table(rep, n):
    """Activity categories by the employees who perform them (no activity counts)."""
    T = rep.get("show_time")
    tot = max(1, rep["work"]["staff_with_work"])
    cats = sorted(rep["work"]["categories"], key=lambda x: -(x["hours"] if T else x["staff"]))[:n]
    head = ["Category", "Employees", "Daily man-hours", "FTE"] if T else ["Category", "Employees", "Share of employees"]
    rows = [[x["name"], fmt(x["staff"])] + ([h1(x["hours"]), f"{x['fte']:.1f}"] if T else [f"{round(x['staff'] / tot * 100)}%"]) for x in cats]
    return head, rows


def cap_head(rep):
    return CAP_HEAD if rep.get("show_time") else CAP_HEAD[:5] + ["", ""]


def emp_head(rep):
    return EMP_HEAD if rep.get("show_time") else EMP_HEAD[:5] + ["", ""]


REGION_HEAD = ["Region", "Total", "FTE", "FTC", "Service", "Support", "Not yet marked"]
CAP_HEAD = ["Function", "Status", "Employees", "Employees with activities", "Activities", "Daily man-hours", "FTE equivalent"]


def cap_rows(rep):
    if not rep.get("show_time"):
        return [[c["name"], c["status"], fmt(c["hc"]), fmt(c["with_work"]), fmt(c["activities"]) if c["activities"] else "-", "", ""] for c in rep["capture"]]
    return [[c["name"], c["status"], fmt(c["hc"]), fmt(c["with_work"]), fmt(c["activities"]) if c["activities"] else "-",
             h1(c["hours"]) if c["hours"] else "-", f"{c['fte']:.1f}" if c["fte"] else "-"] for c in rep["capture"]]


EMP_HEAD = ["Name", "Grade", "Unit / region", "Service / support", "Activities", "Daily man-hours", "Utilisation"]


def emp_rows(rep, n=None):
    if not rep.get("show_time"):
        emps = sorted([x for x in rep["detail"]["employees"] if x["items"]], key=lambda x: -len(x["items"]))
        return [[x["name"], x["grade"], " / ".join(v for v in ("All units" if x["is_head"] else x["unit"], x["region"]) if v),
                 x["service_role"] or "", len(x["items"]), "", ""] for x in emps[:n]]
    emps = sorted([x for x in rep["detail"]["employees"] if x["items"]], key=lambda x: -x["daily_hours"])
    return [[x["name"], x["grade"], " / ".join(v for v in ("All units" if x["is_head"] else x["unit"], x["region"]) if v), x["service_role"] or "", len(x["items"]), f"{x['daily_hours']:.2f}",
             f"{round(x['utilisation'])}%"] for x in emps[:n]]


def signals(rep):
    k = rep["kpi"]
    return [(fmt(k["narrow"]), "managers lead two employees or fewer", AMBER),
            (fmt(k["biggest_n"]), f"direct reports under one manager ({k['biggest_name']})", CORAL),
            (fmt(k["cross"]), "reporting lines cross into another function", AMBER),
            (str(k["avg_span"]), "average direct reports per manager", TEAL)]


# =====================================================================  HTML
def _svg_bars(bins):
    mx = max([v for _, v in bins] + [1])
    w, h, bw = 520, 220, 52
    out = [f'<svg viewBox="0 0 {w} {h + 40}" width="100%" role="img" aria-label="Span of control">']
    for i, (lab, v) in enumerate(bins):
        x = 20 + i * (bw + 18)
        bh = v / mx * h
        col = f"#{AMBER}" if i < 2 else f"#{CORAL}" if i > 4 else f"#{TEAL}"
        out.append(f'<rect x="{x}" y="{h - bh + 10}" width="{bw}" height="{bh}" rx="5" fill="{col}"/>'
                   f'<text x="{x + bw / 2}" y="{h - bh + 4}" text-anchor="middle" class="sv">{v}</text>'
                   f'<text x="{x + bw / 2}" y="{h + 28}" text-anchor="middle" class="sl">{lab}</text>')
    out.append("</svg>")
    return "".join(out)


def make_html(rep, db, allowed, fid):
    e = html.escape
    k = rep["kpi"]
    fs = rep["fstats"]
    mx = max([s["hc"] for s in fs] + [1])
    frows = "".join(
        f'<tr><td><span class="dot" style="background:#{PAL[i % len(PAL)]}"></span>{e(s["name"])}</td>'
        f'<td><div class="hb"><b>{fmt(s["hc"])}</b><div class="bar" style="width:{max(6, s["hc"] / mx * 220):.0f}px"><i style="width:{s["fte"] / s["hc"] * 100:.1f}%;background:#{TEAL}"></i><i style="width:{s["ftc"] / s["hc"] * 100:.1f}%;background:#{FTC_C}"></i></div></div></td>'
        f'<td class="n">{fmt(s["fte"])}</td><td class="n">{fmt(s["ftc"])}</td><td class="n">{s["mg"]}</td><td class="n">{round(s["span"])}</td><td class="n">{s["layers"]}</td><td class="n">{s["narrow"]}</td></tr>'
        for i, s in enumerate(fs))
    sig = "".join(f'<div class="sig"><b>{e(v)}</b><span><i style="background:#{c}"></i>{e(t)}</span></div>' for v, t, c in signals(rep))
    lay_head = "".join(f"<th class='n'>L{i + 1}</th>" for i in range(1, rep["max_layer"] + 1))   # the Group Head is Layer 1
    lay_rows = "".join(f"<tr><td>{e(r['name'])}</td>" + "".join(f"<td class='n'>{v or ''}</td>" for v in r["values"]) + "</tr>" for r in rep["layers"])
    mix = "".join(f'<div class="mixrow"><span>{e(s["name"])}</span><div class="bar big"><i style="width:{s["fte"] / s["hc"] * 100:.1f}%;background:#{TEAL}"></i><i style="width:{s["ftc"] / s["hc"] * 100:.1f}%;background:#{FTC_C}"></i></div><b>{round(s["ftc"] / s["hc"] * 100)}% FTC</b></div>' for s in fs)
    opps = "".join(
        f'<div class="opp"><span class="pill">{e(o["k"])}</span><h3>{e(o["t"])}</h3><p>{e(o["d"])}</p><p><b>Next step:</b> {e(o["a"])}</p>'
        f'<div class="big">{fmt(o["n"])} <small>{o["u"]}</small></div>'
        f'<details><summary>Employees involved (first {len(o["rows"])})</summary><table><tr>{"".join(f"<th>{e(c)}</th>" for c in o["cols"])}</tr>'
        + "".join("<tr>" + "".join(f"<td>{e(str(v))}</td>" for v in r) + "</tr>" for r in o["rows"]) + "</table></details></div>"
        for o in rep["opps"])
    st = rep["structure"]
    org = ""
    if st:
        kids = "".join(f'<div class="ob"><b>{e(c["name"])}</b><span>{e(c["pos"] or "")}</span><small>{e(c["grade"])} · {"team of " + fmt(c["team"]) if c["nk"] else "no team"}</small></div>' for c in st["kids"])
        more = f'<div class="ob more"><b>+{st["more"]} more</b></div>' if st["more"] else ""
        org = f'<div class="orgtop"><div class="ob root"><b>{e(st["name"])}</b><span>{e(st["pos"] or "")}</span><small>{fmt(st["nk"])} direct · {fmt(st["team"])} total</small></div></div><div class="orgkids">{kids}{more}</div>'
    tr = lambda cells, num_from=1: "<tr>" + "".join(f'<td class="{"n" if i >= num_from else ""}">{e(str(v))}</td>' for i, v in enumerate(cells)) + "</tr>"
    th = lambda heads, num_from=1: "<tr>" + "".join(f'<th class="{"n" if i >= num_from else ""}">{e(h)}</th>' for i, h in enumerate(heads)) + "</tr>"
    cap = "".join(tr(r, 2) for r in cap_rows(rep))
    wk = rep["work"]
    wl = "".join(f"<tr><td>{e(l)}</td><td class='n'><b>{e(v)}</b></td></tr>" for l, v in work_lines(rep))
    hh, hr = hand_table(rep)
    ch, crs = cat_table(rep, 25)
    hand = "".join(tr(r) for r in hr)
    cats = "".join(tr(r, 1) for r in crs)
    note = (f"From activities recorded by function POCs. Daily man-hours convert weekly, fortnightly and monthly volumes to a working day; FTE equivalent uses {rep['productive_hours']} productive hours per day."
            if rep.get("show_time") else "From activities recorded by function POCs.")
    work_sec = (f'<section><h2>Service and support</h2><p class="sm">{note}</p>'
                f'<div class="grid2"><table>{wl}</table><table>{th(hh)}{hand}</table></div>'
                f'<h3 style="margin:18px 0 6px">Activity categories</h3><table>{th(ch, 1)}{cats or "<tr><td colspan=4 class=sm>No activities recorded yet.</td></tr>"}</table></section>')
    reg_sec = f'<section><h2>Geographical spread</h2><table>{th(REGION_HEAD)}{"".join(tr(r) for r in region_rows(rep))}</table><p class="sm">Service or support is marked for each employee in data capture.</p></section>'
    det = ""
    if rep["detail"]:
        er = "".join(tr(r, 4) for r in emp_rows(rep))
        det = (f'<section><h2>Employee activities</h2><p class="sm">{"Utilisation against " + str(rep["productive_hours"]) + " productive hours per day." if rep.get("show_time") else "Employees with the most activities first."}</p>'
               f'<table>{th(emp_head(rep), 4)}{er or "<tr><td colspan=7 class=sm>No activities recorded yet.</td></tr>"}</table></section>')
    css = f"""
:root{{--t:#{TEAL};--td:#{TEAL_DEEP};--ink:#{INK};--i2:#{INK2};--i3:#{INK3};--line:#{LINE};--bg:#{BG}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font-family:"Segoe UI",Manrope,system-ui,sans-serif;font-size:14px;line-height:1.5}}
header{{background:var(--td);color:#fff;padding:32px 40px}}header h1{{margin:0;font-size:28px}}header p{{margin:6px 0 0;color:#9fd0c8}}
main{{max-width:1200px;margin:0 auto;padding:28px 24px 60px}}section{{background:#fff;border:1px solid var(--line);border-radius:14px;padding:22px;margin-bottom:18px;break-inside:avoid}}
h2{{margin:0 0 12px;font-size:18px}}.hero{{font-size:24px;font-weight:500;max-width:34ch;margin:0}}.hero b{{font-weight:800}}
.sigs{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:18px}}.sig{{border:1px solid var(--line);border-radius:12px;padding:14px}}.sig b{{font-size:26px;display:block}}.sig span{{color:var(--i2);font-size:13px}}.sig i{{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}}
table{{width:100%;border-collapse:collapse;font-size:13px}}th{{text-align:left;color:var(--i3);font-weight:600;font-size:12px;border-bottom:1px solid var(--line);padding:7px 8px}}td{{border-bottom:1px solid var(--line);padding:7px 8px;vertical-align:top}}.n{{text-align:right}}
.dot{{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:7px}}.hb{{display:flex;gap:10px;align-items:center}}.hb b{{min-width:44px}}
.bar{{display:flex;height:10px;border-radius:5px;overflow:hidden;background:#F6F9F8}}.bar i{{display:block;height:100%}}.bar.big{{height:16px;flex:1}}
.mixrow{{display:grid;grid-template-columns:260px 1fr 80px;gap:12px;align-items:center;margin:6px 0}}.mixrow b{{text-align:right;font-size:12px}}
.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}.sv{{font-size:12px;font-weight:700;fill:var(--ink)}}.sl{{font-size:12px;fill:var(--i2)}}
.opps{{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px}}.opp{{border:1px solid var(--line);border-radius:12px;padding:16px}}.opp h3{{margin:8px 0 4px;font-size:15px}}.opp p{{margin:4px 0;color:var(--i2);font-size:13px}}.opp .big{{font-size:26px;font-weight:800;margin-top:8px}}.opp small{{font-size:12px;color:var(--i3);font-weight:600}}
.pill{{background:#{SOFT};color:var(--t);font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px}}details{{margin-top:8px;font-size:12px}}
.orgtop{{display:flex;justify-content:center;margin-bottom:18px}}.orgkids{{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;border-top:2px solid var(--line);padding-top:16px}}
.ob{{border:1px solid var(--line);border-top:3px solid var(--t);border-radius:10px;padding:10px 12px;display:flex;flex-direction:column}}.ob.root{{min-width:280px;border:2px solid var(--t)}}.ob span{{color:var(--i2);font-size:12px}}.ob small{{color:var(--i3);font-size:11.5px;margin-top:4px}}.ob.more{{border-style:dashed;justify-content:center}}
.sm{{color:var(--i3);font-size:12px}}footer{{text-align:center;color:var(--i3);font-size:12px;padding:20px}}
@media (max-width:800px){{.sigs{{grid-template-columns:1fr 1fr}}.grid2{{grid-template-columns:1fr}}.mixrow{{grid-template-columns:1fr}}}}
@media print{{body{{background:#fff}}header{{-webkit-print-color-adjust:exact;print-color-adjust:exact}}section{{border:0;padding:8px 0}}details{{display:none}}}}
"""
    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(rep["title"])}: employee report</title><style>{css}</style></head><body>
<header><h1>{e(rep["title"])}</h1><p>Employee and organisation report · {e(rep["generated"])} · prepared by {e(rep["by"])}</p></header><main>
<section><p class="hero">{e(headline(rep))}</p><div class="sigs">{sig}</div></section>
<section><h2>Structure at the top</h2>{org}</section>
<section><h2>Functions at a glance</h2><table><tr><th>Function</th><th>Headcount (FTE / FTC)</th><th class="n">FTE</th><th class="n">FTC</th><th class="n">Managers</th><th class="n">Avg span</th><th class="n">Layers</th><th class="n">Narrow spans</th></tr>{frows}</table></section>
<div class="grid2"><section><h2>Span of control</h2><p class="sm">Managers by number of direct reports</p>{_svg_bars(rep["span_bins"])}</section>
<section><h2>Employees by layer</h2><div style="overflow-x:auto"><table><tr><th>Function</th>{lay_head}</tr>{lay_rows}</table></div></section></div>
<section><h2>Employee mix</h2><p class="sm">FTE (dark) and FTC (light) share of each function</p>{mix}</section>
<section><h2>Structure opportunities</h2><div class="opps">{opps or "<p class=sm>No findings.</p>"}</div></section>
{work_sec}{reg_sec}
<section><h2>Data capture progress</h2><table>{th(cap_head(rep), 2)}{cap}</table></section>
{det}</main><footer>HBL Operations Services Employee Portal · {e(rep["generated"])}.{"" if rep["include_flagged"] else " Employees marked 'exclude' are not counted."}</footer></body></html>"""
    return doc.encode("utf-8")


# =====================================================================  PDF
def make_pdf(rep, db, allowed, fid):
    from reportlab.graphics.charts.barcharts import HorizontalBarChart, VerticalBarChart
    from reportlab.graphics.shapes import Drawing, String
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table,
                                    TableStyle)

    c = lambda h: colors.HexColor("#" + h)
    buf = io.BytesIO()
    W, H = landscape(A4)
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=16 * mm, rightMargin=16 * mm, topMargin=20 * mm, bottomMargin=14 * mm,
                            title=f"{rep['title']} employee report", author=rep["by"])
    S = {
        "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=26, leading=31, textColor=colors.white),
        "sub": ParagraphStyle("sub", fontName="Helvetica", fontSize=12, leading=16, textColor=c("9FD0C8")),
        "hero": ParagraphStyle("hero", fontName="Helvetica", fontSize=19, leading=25, textColor=c(INK)),
        "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=15, leading=19, textColor=c(INK), spaceAfter=6),
        "p": ParagraphStyle("p", fontName="Helvetica", fontSize=9.5, leading=13, textColor=c(INK2)),
        "cell": ParagraphStyle("cell", fontName="Helvetica", fontSize=8.5, leading=10.5, textColor=c(INK)),
        "big": ParagraphStyle("big", fontName="Helvetica-Bold", fontSize=22, leading=25, textColor=c(INK)),
        "small": ParagraphStyle("sm", fontName="Helvetica", fontSize=8.5, leading=11, textColor=c(INK3)),
    }
    e = lambda s: html.escape(str(s))

    def page(canvas, d):
        canvas.saveState()
        canvas.setFillColor(c(TEAL))
        canvas.rect(0, H - 6 * mm, W, 6 * mm, stroke=0, fill=1)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(c(INK3))
        canvas.drawString(16 * mm, 8 * mm, f"{rep['title']}  ·  employee report  ·  {rep['generated']}")
        canvas.drawRightString(W - 16 * mm, 8 * mm, f"Page {d.page}")
        canvas.restoreState()

    def cover(canvas, d):
        canvas.saveState()
        canvas.setFillColor(c(TEAL_DEEP))
        canvas.rect(0, 0, W, H, stroke=0, fill=1)
        canvas.setFillColor(c("0B5A52"))
        canvas.circle(W - 40 * mm, H - 30 * mm, 70 * mm, stroke=0, fill=1)
        canvas.restoreState()

    def tbl(rows, widths, head=True, num_from=None, zebra=True):
        t = Table(rows, colWidths=widths, repeatRows=1 if head else 0)
        st = [("FONT", (0, 0), (-1, -1), "Helvetica", 8.5), ("TEXTCOLOR", (0, 0), (-1, -1), c(INK)),
              ("LINEBELOW", (0, 0), (-1, -1), 0.4, c(LINE)), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
              ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
        if head:
            st += [("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 8), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("BACKGROUND", (0, 0), (-1, 0), c(TEAL))]
        if num_from is not None:
            st.append(("ALIGN", (num_from, 0), (-1, -1), "RIGHT"))
        if zebra:
            for r in range(1, len(rows)):
                if r % 2 == 0:
                    st.append(("BACKGROUND", (0, r), (-1, r), c("F6F9F8")))
        t.setStyle(TableStyle(st))
        return t

    k = rep["kpi"]
    story = [Spacer(1, 55 * mm), Paragraph(e(rep["title"]), S["h1"]), Spacer(1, 4 * mm),
             Paragraph(f"Employee and organisation report<br/>{e(rep['generated'])} · prepared by {e(rep['by'])}", S["sub"]), PageBreak()]
    # summary
    story += [Paragraph(e(headline(rep)), S["hero"]), Spacer(1, 8 * mm)]
    sig = [[Paragraph(f"<font color='#{col}'>■</font> <b>{e(v)}</b>", S["big"]) for v, t, col in signals(rep)],
           [Paragraph(e(t), S["p"]) for v, t, col in signals(rep)]]
    st = Table(sig, colWidths=[(W - 32 * mm) / 4] * 4)
    st.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.6, c(LINE)), ("INNERGRID", (0, 0), (-1, -1), 0.6, c(LINE)),
                            ("LINEBELOW", (0, 0), (-1, 0), 0, colors.white), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("TOPPADDING", (0, 0), (-1, -1), 8), ("LEFTPADDING", (0, 0), (-1, -1), 10)]))
    story += [st, Spacer(1, 8 * mm)]
    kp = [["Employees", "FTE", "FTC", "Managers", "Layers", "Avg span", "Wide spans", "Senior, no team"],
          [fmt(k["total"]), fmt(k["fte"]), fmt(k["ftc"]), fmt(k["managers"]), k["layers"], k["avg_span"], k["wide"], k["senior_no_team"]]]
    story += [tbl(kp, [(W - 32 * mm) / 8] * 8, num_from=0, zebra=False), PageBreak()]
    # structure
    stc = rep["structure"]
    if stc:
        story.append(Paragraph("Structure at the top", S["h2"]))
        story.append(Paragraph(f"<b>{e(stc['name'])}</b>, {e(stc['pos'] or '')} · {fmt(stc['nk'])} direct reports, {fmt(stc['team'])} in total", S["p"]))
        story.append(Spacer(1, 4 * mm))
        cells = [Paragraph(f"<b>{e(x['name'])}</b><br/><font color='#{INK2}'>{e(x['pos'] or '')}</font><br/><font color='#{INK3}' size='7.5'>{e(x['grade'])} · {'team of ' + fmt(x['team']) if x['nk'] else 'no team'}</font>", S["cell"]) for x in stc["kids"]]
        if stc["more"]:
            cells.append(Paragraph(f"<b>+{stc['more']} more</b>", S["cell"]))
        cols = 5
        grid = [cells[i:i + cols] + [""] * (cols - len(cells[i:i + cols])) for i in range(0, len(cells), cols)]
        if grid:
            g = Table(grid, colWidths=[(W - 32 * mm) / cols] * cols)
            g.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0, colors.white), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                                   ("LINEABOVE", (0, 0), (-1, -1), 2, c(TEAL)), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 10)]))
            story.append(g)
        story.append(PageBreak())
    # functions table
    fs = rep["fstats"]
    rows = [["Function", "Head", "Employees", "FTE", "FTC", "Managers", "Avg span", "Layers", "Narrow"]]
    rows += [[Paragraph(e(s["name"]), S["cell"]), Paragraph(e(s["head"]), S["cell"]), fmt(s["hc"]), fmt(s["fte"]), fmt(s["ftc"]), s["mg"], round(s["span"]), s["layers"], s["narrow"]] for s in fs]
    story += [Paragraph("Functions at a glance", S["h2"]), tbl(rows, [70 * mm, 55 * mm] + [(W - 32 * mm - 125 * mm) / 7] * 7, num_from=2), PageBreak()]
    # charts
    CH = 110 * mm
    d = Drawing(W / 2 - 24 * mm, CH + 16 * mm)
    ch = VerticalBarChart()
    ch.x, ch.y, ch.width, ch.height = 12 * mm, 12 * mm, W / 2 - 44 * mm, CH
    ch.data = [[v for _, v in rep["span_bins"]]]
    ch.categoryAxis.categoryNames = [l for l, _ in rep["span_bins"]]
    ch.bars.strokeColor = None
    ch.bars.strokeWidth = 0
    for i in range(len(rep["span_bins"])):
        ch.bars[(0, i)].fillColor = c(AMBER) if i < 2 else c(CORAL) if i > 4 else c(TEAL)
    ch.valueAxis.valueMin = 0
    ch.barLabelFormat = "%d"
    ch.barLabels.fontName, ch.barLabels.fontSize, ch.barLabels.nudge = "Helvetica-Bold", 8, 7
    for ax in (ch.categoryAxis, ch.valueAxis):
        ax.labels.fontName, ax.labels.fontSize = "Helvetica", 8
        ax.strokeColor = c(LINE)
    ch.valueAxis.visibleGrid, ch.valueAxis.gridStrokeColor = 1, c(LINE)
    ch.groupSpacing = 8
    d.add(ch)
    d.add(String(12 * mm, 3 * mm, "Direct reports per manager (amber: 1-2, red: over 15)", fontName="Helvetica", fontSize=8, fillColor=c(INK3)))
    topn = fs[:15]
    rowh = min(7.2 * mm, CH / max(1, len(topn)))
    d2 = Drawing(W / 2 - 24 * mm, len(topn) * rowh + 22 * mm)
    hb = HorizontalBarChart()
    hb.x, hb.y, hb.width, hb.height = 62 * mm, 12 * mm, W / 2 - 92 * mm, len(topn) * rowh
    hb.data = [[round(s["fte"] / s["hc"] * 100, 1) for s in reversed(topn)], [round(s["ftc"] / s["hc"] * 100, 1) for s in reversed(topn)]]
    hb.categoryAxis.categoryNames = [(s["name"][:34] + ("…" if len(s["name"]) > 34 else "")) for s in reversed(topn)]
    hb.categoryAxis.style = "stacked"
    hb.bars.strokeColor = None
    hb.bars[0].fillColor, hb.bars[1].fillColor = c(TEAL), c(FTC_C)
    hb.valueAxis.valueMin, hb.valueAxis.valueMax, hb.valueAxis.valueStep = 0, 100, 25
    hb.valueAxis.labelTextFormat = "%d%%"
    for ax in (hb.categoryAxis, hb.valueAxis):
        ax.labels.fontName, ax.labels.fontSize = "Helvetica", 7.5
        ax.strokeColor = c(LINE)
    hb.categoryAxis.labels.boxAnchor = "e"
    hb.groupSpacing = 3
    d2.add(hb)
    d2.add(String(62 * mm, 3 * mm, "Dark: FTE   Light: FTC", fontName="Helvetica", fontSize=8, fillColor=c(INK3)))
    pair = Table([[Paragraph("Span of control", S["h2"]), Paragraph("Employee mix by function", S["h2"])], [d, d2]],
                 colWidths=[(W - 32 * mm) / 2] * 2)
    pair.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [pair, PageBreak()]
    lay_rows = [["Function"] + [f"L{i + 1}" for i in range(1, rep["max_layer"] + 1)]]
    lay_rows += [[Paragraph(e(r["name"]), S["cell"])] + [v or "" for v in r["values"]] for r in rep["layers"]]
    story += [KeepTogether([Paragraph("Employees by layer", S["h2"]), tbl(lay_rows, [80 * mm] + [(W - 32 * mm - 80 * mm) / max(1, rep["max_layer"])] * rep["max_layer"], num_from=1)]), PageBreak()]
    # opportunities
    story.append(Paragraph("Structure opportunities", S["h2"]))
    for o in rep["opps"]:
        block = [Paragraph(f"<font color='#{TEAL}'><b>{e(o['k'].upper())}</b></font>  <b>{e(o['t'])}</b>: {fmt(o['n'])} {o['u']}", ParagraphStyle("o", parent=S["p"], fontSize=11, leading=15, textColor=c(INK))),
                 Paragraph(f"{e(o['d'])} <b>Next step:</b> {e(o['a'])}", S["p"]), Spacer(1, 2 * mm)]
        if o["rows"]:
            rr = [o["cols"]] + [[Paragraph(e(str(v)), S["cell"]) for v in r] for r in o["rows"][:8]]
            block.append(tbl(rr, [(W - 32 * mm) / len(o["cols"])] * len(o["cols"])))
        block.append(Spacer(1, 6 * mm))
        story.append(KeepTogether(block))
    story.append(PageBreak())
    # recorded work
    wk = rep["work"]
    wl = [[Paragraph(e(l), S["cell"]), Paragraph(f"<b>{e(v)}</b>", S["cell"])] for l, v in work_lines(rep)]
    hh, hr = hand_table(rep)
    hand = [hh] + hr
    pair = Table([[tbl([["Figure", "Value"]] + wl, [80 * mm, 45 * mm]), tbl(hand, [45 * mm, 25 * mm, 30 * mm, 20 * mm], num_from=1)]],
                 colWidths=[(W - 32 * mm) * 0.52, (W - 32 * mm) * 0.48])
    pair.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    story += [Paragraph("Service and support", S["h2"]),
              Paragraph(f"From activities recorded by function POCs. Weekly, fortnightly and monthly volumes are converted to a working day; FTE equivalent uses {rep['productive_hours']} productive hours per day." if rep.get("show_time") else "From activities recorded by function POCs.", S["p"]),
              Spacer(1, 3 * mm), pair]
    if wk["categories"]:
        ch, crs = cat_table(rep, 20)
        cr = [ch] + [[Paragraph(e(r[0]), S["cell"])] + r[1:] for r in crs]
        story += [Spacer(1, 6 * mm), Paragraph("Activity categories", S["h2"]), tbl(cr, [150 * mm] + [((W - 32 * mm) - 150 * mm) / (len(ch) - 1)] * (len(ch) - 1), num_from=1)]
    story.append(PageBreak())
    story += [Paragraph("Geographical spread", S["h2"]), tbl([REGION_HEAD] + region_rows(rep), [70 * mm] + [(W - 32 * mm - 70 * mm) / 6] * 6, num_from=1),
              Spacer(1, 8 * mm), Paragraph("Data capture progress", S["h2"]),
              tbl([cap_head(rep)] + [[Paragraph(e(r[0]), S["cell"])] + r[1:] for r in cap_rows(rep)], [80 * mm, 30 * mm] + [(W - 32 * mm - 110 * mm) / 5] * 5, num_from=2)]
    if rep["detail"]:
        er = emp_rows(rep)
        if er:
            story += [PageBreak(), Paragraph("Employee activities", S["h2"]),
                      tbl([emp_head(rep)] + [[Paragraph(e(r[0]), S["cell"])] + r[1:] for r in er], [70 * mm, 30 * mm, 40 * mm, 35 * mm] + [(W - 32 * mm - 175 * mm) / 3] * 3, num_from=4)]
    doc.build(story, onFirstPage=cover, onLaterPages=page)
    return buf.getvalue()


# =====================================================================  PPTX
def make_pptx(rep, db, allowed, fid):
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.dml.color import RGBColor
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
    from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
    from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
    from pptx.util import Emu, Inches, Pt

    rgb = lambda h: RGBColor.from_string(h)
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    blank = prs.slide_layouts[6]
    FONT = "Segoe UI"

    def text(sl, x, y, w, h, s, size=14, bold=False, color=INK, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP):
        tb = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.vertical_anchor = anchor
        tf.margin_left = tf.margin_right = Inches(0.05)
        lines = s if isinstance(s, list) else [s]
        for i, ln in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = align
            r = p.add_run()
            r.text = str(ln)
            r.font.size, r.font.bold, r.font.name = Pt(size), bold, FONT
            r.font.color.rgb = rgb(color)
        return tb

    def rect(sl, x, y, w, h, fill, line=None, shape=MSO_SHAPE.RECTANGLE):
        s = sl.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
        s.fill.solid()
        s.fill.fore_color.rgb = rgb(fill)
        if line:
            s.line.color.rgb = rgb(line)
            s.line.width = Pt(0.75)
        else:
            s.line.fill.background()
        s.shadow.inherit = False
        return s

    def slide(title, sub=None):
        sl = prs.slides.add_slide(blank)
        rect(sl, 0, 0, 13.333, 0.12, TEAL)
        text(sl, 0.6, 0.35, 12, 0.6, title, 26, True)
        if sub:
            text(sl, 0.6, 0.95, 12, 0.4, sub, 13, color=INK2)
        text(sl, 0.6, 7.05, 9, 0.3, f"{rep['title']} · {rep['generated']}", 9, color=INK3)
        return sl

    def table(sl, rows, x, y, w, col_w=None, font=10, num_from=None, row_h=0.3):
        nr, nc = len(rows), len(rows[0])
        gt = sl.shapes.add_table(nr, nc, Inches(x), Inches(y), Inches(w), Inches(row_h * nr)).table
        if col_w:
            for i, cw in enumerate(col_w):
                gt.columns[i].width = Inches(cw)
        for r in range(nr):
            gt.rows[r].height = Inches(row_h)
            for ci in range(nc):
                cell = gt.cell(r, ci)
                cell.text = str(rows[r][ci])
                cell.margin_left = cell.margin_right = Inches(0.06)
                cell.margin_top = cell.margin_bottom = Inches(0.02)
                cell.vertical_anchor = MSO_ANCHOR.MIDDLE
                para = cell.text_frame.paragraphs[0]
                para.alignment = PP_ALIGN.RIGHT if (num_from is not None and ci >= num_from and r > 0) else PP_ALIGN.LEFT
                for run in para.runs:
                    run.font.size, run.font.name = Pt(font), FONT
                    run.font.bold = r == 0
                    run.font.color.rgb = rgb("FFFFFF" if r == 0 else INK)
                cell.fill.solid()
                cell.fill.fore_color.rgb = rgb(TEAL if r == 0 else ("F6F9F8" if r % 2 == 0 else "FFFFFF"))
        return gt

    k = rep["kpi"]
    # 1 cover
    sl = prs.slides.add_slide(blank)
    rect(sl, 0, 0, 13.333, 7.5, TEAL_DEEP)
    rect(sl, 9.2, -1.6, 6, 6, "0B5A52", shape=MSO_SHAPE.OVAL)
    text(sl, 0.8, 1.9, 9.5, 2.2, rep["title"], 38 if len(rep["title"]) < 30 else 32, True, "FFFFFF", anchor=MSO_ANCHOR.BOTTOM)
    text(sl, 0.8, 4.25, 9, 0.8, ["Employee and organisation review", f"{rep['generated']} · prepared by {rep['by']}"], 16, color="9FD0C8")
    # 2 headline
    sl = slide("The organisation in one view")
    text(sl, 0.6, 1.3, 8.6, 1.8, headline(rep), 22, color=INK)
    sig = signals(rep)
    for i, (v, t, col) in enumerate(sig):
        x = 0.6 + i * 3.1
        rect(sl, x, 3.6, 2.9, 1.9, "FFFFFF", LINE)
        rect(sl, x, 3.6, 0.08, 1.9, col)
        text(sl, x + 0.25, 3.75, 2.5, 0.8, v, 32, True)
        text(sl, x + 0.25, 4.6, 2.5, 0.8, t, 12, color=INK2)
    tiles = [("Employees", fmt(k["total"])), ("FTE", fmt(k["fte"])), ("FTC", fmt(k["ftc"])), ("Managers", fmt(k["managers"])), ("Layers", str(k["layers"])), ("Functions", str(k["functions"]))]
    for i, (lab, v) in enumerate(tiles):
        x = 0.6 + i * 2.05
        text(sl, x, 5.9, 1.9, 0.5, v, 20, True, TEAL)
        text(sl, x, 6.4, 1.9, 0.4, lab, 11, color=INK3)
    # 3 structure
    stc = rep["structure"]
    if stc:
        sl = slide("Structure at the top", f"{stc['name']}, {fmt(stc['nk'])} direct reports and {fmt(stc['team'])} employees in total")
        rb = rect(sl, 4.9, 1.45, 3.5, 0.85, "FFFFFF", TEAL, MSO_SHAPE.ROUNDED_RECTANGLE)
        rb.line.width = Pt(2)
        text(sl, 5.0, 1.5, 3.3, 0.8, [stc["name"], (stc["pos"] or "")[:48]], 11, True, anchor=MSO_ANCHOR.MIDDLE, align=PP_ALIGN.CENTER)
        kids = stc["kids"][:18]
        cols = min(6, max(1, len(kids)))
        bw, bh, gx, gy = 1.95, 0.95, 0.12, 0.2
        total_w = cols * bw + (cols - 1) * gx
        x0 = (13.333 - total_w) / 2
        y0 = 2.85
        bus = y0 - 0.25
        ln = sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(6.65), Inches(2.3), Inches(6.65), Inches(bus))
        ln.line.color.rgb = rgb(LINE)
        ln2 = sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x0 + bw / 2), Inches(bus), Inches(x0 + total_w - bw / 2), Inches(bus))
        ln2.line.color.rgb = rgb(LINE)
        for i, c in enumerate(kids):
            r, ci = divmod(i, cols)
            x, y = x0 + ci * (bw + gx), y0 + r * (bh + gy)
            if r == 0:
                cn = sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x + bw / 2), Inches(bus), Inches(x + bw / 2), Inches(y))
                cn.line.color.rgb = rgb(LINE)
            rect(sl, x, y, bw, bh, "FFFFFF", LINE, MSO_SHAPE.ROUNDED_RECTANGLE)
            rect(sl, x + 0.06, y + 0.12, 0.05, bh - 0.24, PAL[i % len(PAL)])
            text(sl, x + 0.14, y + 0.04, bw - 0.18, bh - 0.08,
                 [c["name"][:26], (c["pos"] or "")[:30], f"{c['grade']} · {'team ' + fmt(c['team']) if c['nk'] else 'no team'}"], 8.5)
        more = stc["more"] + max(0, len(stc["kids"]) - 18)
        if more:
            text(sl, 0.6, 6.6, 12, 0.3, f"+{more} more direct reports not shown", 10, color=INK3)
    # 4 functions table
    fs = rep["fstats"]
    single = len(fs) <= 1
    if not single:
      sl = slide("Functions at a glance", "Employees, spans and layers by function")
      rows = [["Function", "Employees", "FTE", "FTC", "Managers", "Avg span", "Layers", "Narrow spans"]]
      rows += [[s["name"][:44], fmt(s["hc"]), fmt(s["fte"]), fmt(s["ftc"]), s["mg"], round(s["span"]), s["layers"], s["narrow"]] for s in fs[:16]]
      table(sl, rows, 0.6, 1.45, 12.1, [4.6, 1.1, 1.0, 1.0, 1.1, 1.1, 1.0, 1.2], 10, 1, 0.3)
    # 5 span + mix charts
    sl = slide("Span of control and employee mix")
    cd = CategoryChartData()
    cd.categories = [l for l, _ in rep["span_bins"]]
    cd.add_series("Managers", [v for _, v in rep["span_bins"]])
    gf = sl.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(0.6), Inches(1.4), Inches(5.8), Inches(5.3), cd)
    ch = gf.chart
    ch.has_legend = False
    ch.has_title = True
    ch.chart_title.text_frame.text = "Managers by number of direct reports"
    ch.chart_title.text_frame.paragraphs[0].runs[0].font.size = Pt(12)
    plot = ch.plots[0]
    plot.gap_width = 60
    plot.has_data_labels = True
    plot.data_labels.font.size = Pt(10)
    plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
    for i, pt in enumerate(plot.series[0].points):
        pt.format.fill.solid()
        pt.format.fill.fore_color.rgb = rgb(AMBER if i < 2 else CORAL if i > 4 else TEAL)
    ch.category_axis.tick_labels.font.size = Pt(10)
    ch.value_axis.tick_labels.font.size = Pt(9)
    ch.value_axis.major_gridlines.format.line.color.rgb = rgb(LINE)
    top = list(reversed(fs[:12]))
    cd2 = CategoryChartData()
    cd2.categories = [s["name"][:30] for s in top]
    cd2.add_series("FTE", [round(s["fte"] / s["hc"], 3) for s in top])
    cd2.add_series("FTC", [round(s["ftc"] / s["hc"], 3) for s in top])
    gf2 = sl.shapes.add_chart(XL_CHART_TYPE.BAR_STACKED_100, Inches(6.8), Inches(1.4), Inches(6.0), Inches(5.3), cd2)
    ch2 = gf2.chart
    ch2.has_title = True
    ch2.chart_title.text_frame.text = "FTE and FTC share"
    ch2.chart_title.text_frame.paragraphs[0].runs[0].font.size = Pt(12)
    ch2.has_legend = True
    ch2.legend.position = XL_LEGEND_POSITION.BOTTOM
    ch2.legend.include_in_layout = False
    ch2.legend.font.size = Pt(10)
    ch2.plots[0].gap_width = 40
    for s, col in zip(ch2.plots[0].series, [TEAL, FTC_C]):
        s.format.fill.solid()
        s.format.fill.fore_color.rgb = rgb(col)
    ch2.category_axis.tick_labels.font.size = Pt(9)
    ch2.value_axis.tick_labels.font.size = Pt(9)
    ch2.value_axis.major_gridlines.format.line.color.rgb = rgb(LINE)
    # 6 layers
    if rep["layers"]:
        sl = slide("Employees by layer", "Where employees sit below the top of the organisation")
        cd3 = CategoryChartData()
        lay = list(reversed(rep["layers"][:12]))
        cd3.categories = [r["name"][:30] for r in lay]
        shades = ["0B4F48", "00796B", "1A9A8C", "4DB6AC", "8FCCC3", "C9A227", "BF4E3A", "8E7DBE"]
        for li in range(rep["max_layer"]):
            cd3.add_series(f"Layer {li + 2}", [r["values"][li] for r in lay])
        gf3 = sl.shapes.add_chart(XL_CHART_TYPE.BAR_STACKED, Inches(0.6), Inches(1.4), Inches(12.1), Inches(5.4), cd3)
        ch3 = gf3.chart
        ch3.has_legend = True
        ch3.legend.position = XL_LEGEND_POSITION.BOTTOM
        ch3.legend.include_in_layout = False
        ch3.legend.font.size = Pt(10)
        ch3.plots[0].gap_width = 40
        for i, s in enumerate(ch3.plots[0].series):
            s.format.fill.solid()
            s.format.fill.fore_color.rgb = rgb(shades[i % len(shades)])
        ch3.category_axis.tick_labels.font.size = Pt(9)
        ch3.value_axis.tick_labels.font.size = Pt(9)
        ch3.value_axis.major_gridlines.format.line.color.rgb = rgb(LINE)
    # 7 opportunities (cards)
    opps = rep["opps"]
    for page_i in range(0, len(opps), 6):
        sl = slide("Structure opportunities", "Findings from the reporting lines, each with a next step")
        for j, o in enumerate(opps[page_i:page_i + 6]):
            r, ci = divmod(j, 3)
            x, y = 0.6 + ci * 4.1, 1.45 + r * 2.8
            rect(sl, x, y, 3.9, 2.6, "FFFFFF", LINE, MSO_SHAPE.ROUNDED_RECTANGLE)
            text(sl, x + 0.2, y + 0.12, 3.5, 0.3, o["k"].upper(), 9, True, TEAL)
            text(sl, x + 0.2, y + 0.4, 3.5, 0.6, o["t"], 13, True)
            text(sl, x + 0.2, y + 1.0, 3.5, 0.9, [o["d"][:210], "Next step: " + o["a"][:150]], 9, color=INK2)
            text(sl, x + 0.2, y + 1.95, 3.5, 0.55, f"{fmt(o['n'])} {o['u']}", 20, True)
    # 8 service and support
    wk = rep["work"]
    if wk["activities"]:
        sl = slide("Service and support", f"{fmt(wk['staff_with_work'])} employees with activities recorded")
        t = wk["types"]
        tiles = [("Service", t["Service"], TEAL), ("Support", t["Support"], "C9A227"), ("Not yet marked", {"staff_classified": wk.get("unclassified", 0), "fte": 0}, "C6D3D1")]
        for i, (lab, v, col) in enumerate(tiles):
            x = 0.6 + i * 2.05
            rect(sl, x, 1.5, 1.9, 1.7, "FFFFFF", LINE)
            rect(sl, x, 1.5, 0.08, 1.7, col)
            text(sl, x + 0.22, 1.6, 1.6, 0.4, lab, 12, True, INK2)
            text(sl, x + 0.22, 2.0, 1.6, 0.6, fmt(v["staff_classified"]), 26, True)
            text(sl, x + 0.22, 2.65, 1.6, 0.4, f"{v['fte']:.1f} FTE of work" if rep.get("show_time") else "employees", 10, color=INK3)
        rows = [["Figure", "Value"]] + [[l, v] for l, v in work_lines(rep)]
        table(sl, rows, 6.9, 1.5, 5.8, [3.3, 2.5], 10, None, 0.34)
        cd5 = CategoryChartData()
        cd5.categories = [x["name"] for x in wk["handling"]]
        cd5.add_series("Daily man-hours" if rep.get("show_time") else "Activities", [x["hours"] if rep.get("show_time") else x["activities"] for x in wk["handling"]])
        gf5 = sl.shapes.add_chart(XL_CHART_TYPE.BAR_CLUSTERED, Inches(0.6), Inches(3.5), Inches(6.0), Inches(3.3), cd5)
        ch5 = gf5.chart
        ch5.has_legend = False
        ch5.has_title = True
        ch5.chart_title.text_frame.text = f"Daily man-hours by {nature_label().lower()}" if rep.get("show_time") else f"Activities by {nature_label().lower()}"
        ch5.chart_title.text_frame.paragraphs[0].runs[0].font.size = Pt(12)
        ch5.plots[0].has_data_labels = True
        ch5.plots[0].data_labels.font.size = Pt(10)
        ch5.plots[0].data_labels.number_format = "0.0" if rep.get("show_time") else "0"
        ch5.plots[0].data_labels.number_format_is_linked = False
        ch5.plots[0].series[0].format.fill.solid()
        ch5.plots[0].series[0].format.fill.fore_color.rgb = rgb(TEAL)
        ch5.category_axis.tick_labels.font.size = Pt(10)
        ch5.value_axis.tick_labels.font.size = Pt(9)
        ch5.value_axis.major_gridlines.format.line.color.rgb = rgb(LINE)
        if wk["categories"]:
            sl = slide("Activity categories", "Where the recorded daily man-hours go" if rep.get("show_time") else "Categories performed by the most employees")
            ch, crs = cat_table(rep, 16)
            rows = [ch] + [[r[0][:60]] + r[1:] for r in crs]
            table(sl, rows, 0.6, 1.45, 12.1, [7.1] + [5.0 / (len(ch) - 1)] * (len(ch) - 1), 10, 1, 0.3)
    # 9 geographical spread
    sl = slide("Geographical spread", "Employees by region, FTE and FTC, and by type of work")
    rows = [REGION_HEAD] + region_rows(rep)[:17]
    table(sl, rows, 0.6, 1.45, 12.1, [3.6, 1.3, 1.3, 1.3, 1.4, 1.4, 1.8], 10, 1, 0.3)
    # 10 capture progress
    if not single:
        sl = slide("Data capture progress", "What each function has recorded so far")
        table(sl, [cap_head(rep)] + [[r[0][:44]] + r[1:] for r in cap_rows(rep)][:16], 0.6, 1.45, 12.1, [4.3, 1.5, 1.2, 1.6, 1.1, 1.3, 1.1], 10, 2, 0.3)
    # 11 function detail
    if rep["detail"]:
        er = emp_rows(rep, 16)
        if er:
            sl = slide("Employee activities", f"Daily man-hours and utilisation against {rep['productive_hours']} productive hours per day" if rep.get("show_time") else "Employees with the most activities")
            table(sl, [emp_head(rep)] + [[r[0][:32]] + r[1:] for r in er], 0.6, 1.45, 12.1, [3.4, 1.2, 1.9, 1.7, 1.2, 1.5, 1.2], 10, 4, 0.3)
    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()


# =====================================================================  XLSX
def make_xlsx(rep, db, allowed, fid):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    def sheet(wb, title, header, rows, widths=None):
        ws = wb.create_sheet(title[:31])
        ws.append(header)
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor=TEAL)
        for r in rows:
            ws.append(r)
        for i, h in enumerate(header, 1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = (widths[i - 1] if widths else max(12, min(45, len(str(h)) + 6)))
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        return ws

    fids = allowed
    c = Calc(db)
    q = db.query(models.Function)
    fns = {f.id: f for f in q if fids is None or f.id in fids}
    uscope = rep.get("_uscope")
    hide = hide_resigned()
    # employees of the functions in scope; a unit limit (login or filter) and the resigned setting apply here too
    emps = [e for e in db.query(models.Employee) if e.function_id in fns and in_units(e, uscope) and not (hide and e.resigned)]
    names = {e.code: e.name for e in db.query(models.Employee.code, models.Employee.name)}
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = rep["title"]
    ws["A1"].font = Font(bold=True, size=18, color=TEAL_DEEP)
    ws["A2"] = f"HBL Operations Services employee report · {rep['generated']} · {rep['by']}"
    ws["A2"].font = Font(color=INK3)
    ws["A4"] = headline(rep)
    ws["A4"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.merge_cells("A4:H6")
    k = rep["kpi"]
    for i, (lab, v) in enumerate([("Employees", k["total"]), ("FTE", k["fte"]), ("FTC", k["ftc"]), ("Managers", k["managers"]),
                                  ("Layers", k["layers"]), ("Average span", k["avg_span"]), ("Narrow spans", k["narrow"]), ("Wide spans", k["wide"])]):
        ws.cell(8, 1 + i, lab).font = Font(color=INK3)
        cc = ws.cell(9, 1 + i, v)
        cc.font = Font(bold=True, size=14, color=TEAL)
    for i, (lab, v) in enumerate(work_lines(rep)):
        ws.cell(11 + i, 1, lab).font = Font(color=INK3)
        ws.cell(11 + i, 4, v).font = Font(bold=True)
    ws.column_dimensions["A"].width = 16
    for col in "BCDEFGH":
        ws.column_dimensions[col].width = 14
    sheet(wb, "Functions", ["Function", "Head", "Employees", "FTE", "FTC", "Managers", "Average span", "Layers", "Narrow spans"],
          [[s["name"], s["head"], s["hc"], s["fte"], s["ftc"], s["mg"], round(s["span"]), s["layers"], s["narrow"]] for s in rep["fstats"]],
          [42, 28, 12, 10, 10, 12, 14, 10, 14])
    orow = []
    for o in rep["opps"]:
        orow.append([o["k"], o["t"], o["n"], o["u"], o["d"], o["a"]])
    sheet(wb, "Opportunities", ["Type", "Finding", "Count", "Unit", "Why it matters", "Next step"], orow, [14, 40, 10, 12, 70, 60])
    kids = {}
    for e in db.query(models.Employee):
        if e.manager_code:
            kids.setdefault(e.manager_code, []).append(e.code)
    root = get_setting(db, "root_code")
    layer = {root: 0}
    order = [root]
    for x in order:
        for kk in kids.get(x, []):
            layer[kk] = layer[x] + 1
            order.append(kk)
    heads_all = set()
    for f in fns.values():
        heads_all |= function_heads(db, f.id)
    work = {}
    for w in db.query(models.WorkItem).order_by(models.WorkItem.id):   # in the order they were entered (the activity review relies on it)
        work.setdefault(w.employee_code, []).append(w)
    from ..logic import classify, summarise, type_label
    sheet(wb, "Employees", ["Employee code", "Name", "Grade", "Type", "Position", "Function", "Unit", "Region", "Service / support", "Manager code",
                        "Manager name", "Layer", "Direct reports", "Activities", "Daily man-hours", "Utilisation %", "External", "Excluded", "Resigned", "Source", "Verified"],
          [[e.code, e.name, e.grade, type_label(e), e.position, fns[e.function_id].name, "All units" if e.code in heads_all else (e.unit_name or ""), e.region or "",
            e.service_role or "", e.manager_code or "", names.get(e.manager_code, ""),
            layer.get(e.code, ""), len(kids.get(e.code, [])), len(work.get(e.code, [])),
            round(sum(c.daily_hours(w) for w in work.get(e.code, [])), 2),
            round(sum(c.daily_hours(w) for w in work.get(e.code, [])) / c.ph * 100, 1) if c.ph else "",
            "Yes" if e.external else "", "Yes" if e.exclude else "", "Yes" if e.resigned else "", e.source, "Yes" if e.verified else "No"]
           for e in sorted(emps, key=lambda x: (fns[x.function_id].name, -(x.grade_rank or 0)))],
          [14, 30, 10, 7, 38, 32, 26, 14, 14, 14, 30, 7, 13, 11, 14, 12, 9, 9, 9, 9, 9])
    sheet(wb, "Regions", REGION_HEAD, [[r["region"], r["total"], r["fte"], r["ftc"], r["Service"], r["Support"], r["none"]] for r in rep["regions"]],
          [26, 10, 10, 10, 10, 10, 16])
    # the data capture template, filled in: one row per employee per activity
    from .catreview import NO_THEME, theme_map, theme_of
    tm = theme_map(db)
    show_th = bool(get_setting(db, "show_themes"))   # activity themes are shown once the admin turns them on

    def no_theme(header, rows, widths, col):
        """Leave the theme column out while themes are off."""
        if show_th:
            return header, rows, widths
        return header[:col] + header[col + 1:], [r[:col] + r[col + 1:] for r in rows], widths[:col] + widths[col + 1:]
    erows = []
    for e in sorted(emps, key=lambda x: (fns[x.function_id].name, -(x.grade_rank or 0), x.name)):
        for w in work.get(e.code, []):
            erows.append([fns[e.function_id].name, e.code, e.name, e.grade, type_label(e), e.region or "", e.unit_name or w.unit or ("All units" if e.code in heads_all else ""), w.product or "",
                          w.process or "", w.channel or "", w.description or "", w.category or "",
                          (theme_of(w.category, tm) or NO_THEME) if (w.category or "").strip() else "", e.service_role or "", w.frequency or "",
                          (round(w.volume, 2) if w.volume is not None else None), vol_labels()[0] if w.volume_type == VOL_FILE else (vol_labels()[1] if w.volume is not None else ""), (round(w.peak_som, 2) if w.peak_som is not None else None), (round(w.peak_eom, 2) if w.peak_eom is not None else None), w.handling or "", w.minutes, round(c.total_minutes(w), 2),
                          round(c.daily_hours(w), 3), w.automation or "", w.id])
    ws2 = sheet(wb, "Employee activities", *no_theme(["Function", "Employee code", "Name", "Grade", "Type", "Region", "Unit", "Product", "Process name",
                                            "Channel", "Activity description", "Activity category", "Activity theme", "Employee: service / support", "Frequency",
                                            "Avg volume (per frequency)", "Volume type", "Peak volume start of month (avg per day)", "Peak volume end of month (avg per day)",
                                            nature_label(), "Employee processing time (min)", "Total employee processing time (min)",
                                            "Daily man-hours", "Automation opportunity", "Activity ID"], erows,
                [28, 13, 26, 9, 7, 12, 22, 22, 28, 16, 60, 34, 26, 12, 12, 14, 18, 18, 18, 14, 14, 16, 12, 12, 11], 12))
    for row in ws2.iter_rows(min_row=2, min_col=11, max_col=11):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    cats = [[x["name"], x.get("theme") or (NO_THEME if x["name"] != "Not categorised" else ""), x["staff"], x["activities"], x["hours"], x["fte"], x["automation"], x["manual"]] for x in rep["work"]["categories"]]
    sheet(wb, "Activity categories", *no_theme(["Category", "Activity theme", "Employees", "Activities", "Daily man-hours", "FTE equivalent",
                                      "Automation opportunities", f"{HANDLING[0] if HANDLING else 'Core Physical'} activities"], cats, [50, 30, 11, 11, 14, 14, 16, 14], 1))
    if show_th:
        sheet(wb, "Activity themes", ["Activity theme", "Employees", "Activities", "Categories"],
              [[t["name"], t["staff"], t["activities"], len(t["categories"])] for t in rep["work"].get("themes", [])], [40, 11, 11, 11])
    sheet(wb, "Function status", ["Function", "Status", "Last change"],
          [[f.name, f.status, f.status_at.isoformat(timespec="minutes") if f.status_at else ""] for f in fns.values()], [40, 16, 20])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
