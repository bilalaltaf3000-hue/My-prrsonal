"""Operations Services employee portal: FastAPI application."""
import logging
import secrets
import uuid

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import models
from .config import DATA_DIR, STATIC_DIR
from .db import Base, SessionLocal, engine
from .routers import actreview, admin, auth_org, capture, catreview, dashboard, decisions, exports, feedback, staffadmin, vacancies
from .security import hash_password

# Version 1 seeded these role-type categories. Activity categories are now one-line summaries written by
# POCs, so on upgrade the untouched old list is removed (anything the admin added is kept).
OLD_CATEGORIES = ["Processor", "Supervisor", "Governance & Oversight", "Relationship Management", "MIS & Analytics",
                  "Project Management", "External Reporting", "Monitoring", "Communication", "Coordination",
                  "Settlement & Reconciliation", "Training", "Mail Management", "General"]
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("ops-portal")
REGIONS = ["Karachi", "Lahore", "Islamabad", "Faisalabad", "Multan", "Peshawar", "Quetta", "Hyderabad"]


def migrate():
    """Add columns introduced after the first release and convert old roles (poc/viewer)."""
    from sqlalchemy import inspect, text
    insp = inspect(engine)
    if "users" not in insp.get_table_names():
        return
    have = {c["name"] for c in insp.get_columns("users")}
    add = {"input_functions": "JSON", "view_mode": "VARCHAR(10) DEFAULT 'none'", "view_functions": "JSON",
           "can_export": "BOOLEAN DEFAULT FALSE", "view_units": "JSON", "can_decisions": "BOOLEAN DEFAULT 0"}
    extra = {"activities": {"split_mode": "VARCHAR(10) DEFAULT 'equal'"}, "activity_performers": {"volume": "FLOAT DEFAULT 0"},
             "employees": {"unit_source": "VARCHAR(10)", "region_source": "VARCHAR(10)", "unit_name": "VARCHAR(200)", "unit_name_source": "VARCHAR(10)", "overrides": "JSON", "service_role": "VARCHAR(10)",
                           "service_role_source": "VARCHAR(10)", "resigned": "BOOLEAN DEFAULT 0", "resigned_on": "VARCHAR(10)"},
             "retag_requests": {"kind": "VARCHAR(10) DEFAULT 'function'", "from_manager": "VARCHAR(50)", "to_manager": "VARCHAR(50)"},
             "feedback": {"change": "JSON", "function_id": "INTEGER"},
             "work_items": {"volume_type": "VARCHAR(10) DEFAULT ''"},
             "vacancies": {"parent_id": "INTEGER", "filled": "INTEGER DEFAULT 0", "filled_log": "JSON", "jd": "TEXT"}}
    with engine.begin() as con:
        for col, typ in add.items():
            if col not in have:
                con.execute(text(f"ALTER TABLE users ADD COLUMN {col} {typ}"))
        for tbl, cols in extra.items():
            if tbl in insp.get_table_names():
                hv = {c["name"] for c in insp.get_columns(tbl)}
                for col, typ in cols.items():
                    if col not in hv:
                        con.execute(text(f"ALTER TABLE {tbl} ADD COLUMN {col} {typ}"))
    db = SessionLocal()
    try:
        for u in db.query(models.User).filter(models.User.role.in_(["poc", "viewer"])):
            if u.role == "poc":
                u.input_functions = [u.function_id] if u.function_id else []
                u.view_mode = "none"
            else:
                u.input_functions = []
                u.view_mode = "all"
                u.can_export = True
            u.role = "user"
        for u in db.query(models.User):
            if u.input_functions is None:
                u.input_functions = []
            if u.view_functions is None:
                u.view_functions = []
            if u.view_mode is None:
                u.view_mode = "none"
        db.commit()
    finally:
        db.close()


def upgrade_v2(first_v2: bool):
    """First start after upgrading from version 1: convert activities recorded per unit and process into
    one row per employee (the new template), so nothing entered earlier is lost. Fields that version 1 did
    not have (service or support, handling, automation, category) are left for the POC to complete."""
    if not first_v2:
        return
    db = SessionLocal()
    try:
        names = {c.name for c in db.query(models.Category)}
        if names and names <= set(OLD_CATEGORIES):
            db.query(models.Category).delete()
        moved = 0
        for u in db.query(models.Unit):
            staff = [e.code for e in db.query(models.Employee).filter(models.Employee.unit_id == u.id)]
            for p in u.processes:
                for a in p.activities:
                    if a.split_mode == "volume" and a.performers:
                        vol = float(sum(max(0.0, x.volume or 0) for x in a.performers))
                    elif a.basis == "fixed":
                        vol = float(a.quantity or 0)
                    else:
                        vol = float(p.daily_volume or 0) * float(a.quantity if a.quantity is not None else 1)
                    if a.performers:
                        n = len(a.performers)
                        if a.split_mode == "share":
                            split = [(x.code, max(0.0, x.share or 0) / 100.0) for x in a.performers]
                        elif a.split_mode == "volume":
                            tot = sum(max(0.0, x.volume or 0) for x in a.performers) or 1
                            split = [(x.code, max(0.0, x.volume or 0) / tot) for x in a.performers]
                        else:
                            split = [(x.code, 1.0 / n) for x in a.performers]
                    else:
                        split = [(c, 1.0 / len(staff)) for c in staff] if staff else []
                    link = uuid.uuid4().hex if len(split) > 1 else None
                    for code, frac in split:
                        db.add(models.WorkItem(employee_code=code, unit=u.name, process=p.name or "", description=a.description or "",
                                               frequency="Daily", volume=round(vol * frac, 2) if vol else None,
                                               minutes=a.minutes or None, link_id=link, created_by="upgrade"))
                        moved += 1
        if moved:
            log.info("Upgrade: %s activities from version 1 converted to per-employee rows", moved)
            db.add(models.AuditLog(username="system", action="upgrade_v2", detail=f"{moved} activity rows converted"))
        db.commit()
    finally:
        db.close()


def upgrade_units():
    """Once: give each employee a unit name, from their version 1 unit or the unit on their activities."""
    from .security import get_setting, set_setting
    db = SessionLocal()
    try:
        if get_setting(db, "unit_names_done"):
            return
        units = {u.id: u.name for u in db.query(models.Unit)}
        common = {}
        for code, unit in db.query(models.WorkItem.employee_code, models.WorkItem.unit):
            if unit:
                common.setdefault(code, {}).setdefault(unit, 0)
                common[code][unit] += 1
        for e in db.query(models.Employee):
            if e.unit_name:
                continue
            name = units.get(e.unit_id) or (max(common[e.code].items(), key=lambda x: x[1])[0] if e.code in common else None)
            if name:
                e.unit_name, e.unit_name_source = name, "manual"
        set_setting(db, "unit_names_done", True)
        db.commit()
    finally:
        db.close()


def tidy_grades():
    """Every start: grade labels and types (see importer.tidy_grades)."""
    from .importer import tidy_grades as tidy
    db = SessionLocal()
    try:
        n = tidy(db)
        if n:
            db.commit()
            log.info("Grades tidied for %s employees", n)
    finally:
        db.close()


def tidy_text():
    """Every start: names, positions and recorded activity text in consistent capitals (see textnorm)."""
    from .textnorm import name_case, products_case, text_case, title_case
    db = SessionLocal()
    try:
        n = 0
        for e in db.query(models.Employee):
            for f, fn in (("name", name_case), ("position", title_case), ("unit_name", title_case)):
                v = getattr(e, f)
                if v and fn(v) != v:
                    setattr(e, f, fn(v)); n += 1
        for w in db.query(models.WorkItem):
            for f in ("category", "description", "process", "channel", "unit"):
                v = getattr(w, f)
                if v and text_case(v) != v:
                    setattr(w, f, text_case(v)); n += 1
            if w.product and products_case(w.product) != w.product:
                w.product = products_case(w.product); n += 1
        if n:
            db.commit()
            log.info("Capitalisation tidied in %s fields", n)
    finally:
        db.close()


def upgrade_service_roles():
    """Once: Service / Support moved from each activity to the employee. Each employee gets the type of
    the activities they had recorded (most of them). From 2.9 there is no 'Both': anyone marked Both is set
    to the kind most of their old activities had, or left for the POC to mark."""
    from .security import get_setting, set_setting
    from .logic import service_types
    db = SessionLocal()
    try:
        if get_setting(db, "service_roles_done") and get_setting(db, "service_roles_no_both"):
            return
        st = service_types(db)
        for e in db.query(models.Employee):
            if e.service_role == "Both":
                e.service_role = st.get(e.code)
                e.service_role_source = "manual" if e.service_role else None
            elif not e.service_role and st.get(e.code) and not get_setting(db, "service_roles_done"):
                e.service_role, e.service_role_source = st[e.code], "manual"
        set_setting(db, "service_roles_done", True)
        set_setting(db, "service_roles_no_both", True)
        db.commit()
    finally:
        db.close()


def seed_frequencies():
    """First start: the four standard frequencies, with the working days from Settings."""
    from .security import get_setting
    db = SessionLocal()
    try:
        if not db.query(models.Frequency).count():
            wk = float(get_setting(db, "working_days_week") or 5)
            mo = float(get_setting(db, "working_days_month") or 22)
            for i, (n, d) in enumerate([("Daily", 1), ("Weekly", wk), ("Fortnightly", wk * 2), ("Monthly", mo)]):
                db.add(models.Frequency(name=n, days=d, sort=i))
            db.commit()
    finally:
        db.close()


def upgrade_nature():
    """Version 2.11: "processing mode" became "nature of work". Existing activities are renamed once:
    Manual -> Core Physical, File Based -> System Based, System Based -> Straight Through Processing (STP)."""
    from sqlalchemy import text
    from .security import get_setting, set_setting
    db = SessionLocal()
    try:
        if get_setting(db, "nature_migrated"):
            return
        db.execute(text("UPDATE work_items SET handling = CASE handling WHEN 'Manual' THEN 'Core Physical' "
                        "WHEN 'File Based' THEN 'System Based' WHEN 'System Based' THEN 'Straight Through Processing (STP)' "
                        "ELSE handling END WHERE handling IN ('Manual', 'File Based', 'System Based')"))
        if not get_setting(db, "nature_options"):
            set_setting(db, "nature_options", ["Core Physical", "System Based", "Straight Through Processing (STP)"])
        set_setting(db, "nature_migrated", True)
        db.commit()
        log.info("Nature of work: existing activities renamed to the new options")
    finally:
        db.close()


def upgrade_resigned_teams():
    """Teams of employees already marked resigned move to the resigned person's line manager (every start, so
    people a master sheet import puts under a resigned manager are moved too)."""
    from .logic import reassign_resigned_teams
    db = SessionLocal()
    try:
        n = reassign_resigned_teams(db)
        if n:
            db.commit()
            log.info("Resigned employees: %s direct reports moved to the line manager", n)
    finally:
        db.close()


def bootstrap():
    from sqlalchemy import inspect
    tables = inspect(engine).get_table_names()
    first_v2 = "users" in tables and "work_items" not in tables
    Base.metadata.create_all(engine)
    migrate()
    upgrade_v2(first_v2)
    upgrade_units()
    seed_frequencies()
    upgrade_service_roles()
    tidy_grades()
    tidy_text()
    upgrade_nature()
    upgrade_resigned_teams()
    from .logic import load_required
    _db = SessionLocal()
    try:
        load_required(_db)
    finally:
        _db.close()
    db = SessionLocal()
    try:
        if not db.query(models.Region).count():
            for i, r in enumerate(REGIONS):
                db.add(models.Region(name=r, sort=i))
        if not db.query(models.User).filter(models.User.role == "admin").count():
            pw = secrets.token_urlsafe(9)
            db.add(models.User(username="admin", full_name="Administrator", role="admin", view_mode="all", can_export=True,
                               input_functions=[], view_functions=[], password_hash=hash_password(pw)))
            (DATA_DIR / "FIRST_ADMIN_PASSWORD.txt").write_text(
                f"username: admin\npassword: {pw}\n\nChange it after signing in, then delete this file.\n")
            print("\n" + "=" * 60 + f"\n First admin login  ->  admin / {pw}\n Saved in {DATA_DIR / 'FIRST_ADMIN_PASSWORD.txt'}\n" + "=" * 60 + "\n")
        db.commit()
    finally:
        db.close()


bootstrap()
app = FastAPI(title="HBL Operations Services Employee Portal", docs_url="/api/docs", redoc_url=None)
app.include_router(auth_org.router)
app.include_router(capture.router)
app.include_router(admin.router)
app.include_router(exports.router)
app.include_router(dashboard.router)
app.include_router(staffadmin.router)
app.include_router(feedback.router)
app.include_router(catreview.router)
app.include_router(actreview.router)
app.include_router(decisions.router)
app.include_router(vacancies.router)


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    log.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse({"detail": "Something went wrong on the server. Please try again or contact the admin."}, status_code=500)


if (STATIC_DIR / "assets").exists():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR / "assets"), name="assets")


@app.get("/{path:path}", include_in_schema=False)
def spa(path: str):
    if path.startswith("api/"):
        return JSONResponse({"detail": "Not found"}, status_code=404)
    f = STATIC_DIR / path
    if path and f.is_file():
        return FileResponse(f)
    index = STATIC_DIR / "index.html"
    if index.exists():
        return FileResponse(index)
    return JSONResponse({"detail": "Frontend not built. See README."}, status_code=404)
