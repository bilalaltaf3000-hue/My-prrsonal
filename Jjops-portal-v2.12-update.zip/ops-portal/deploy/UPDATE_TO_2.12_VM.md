# Updating the VM to version 2.12 (keeps all captured data)

This update replaces **the code only**. The database (`portal.db`), `secret.key`, the SSL certificate and the Python environment (`venv`) stay as they are. Nobody needs a new password, and no `pip install` is needed.

On first start, version 2.12 adds two empty columns, `work_items.volume_type` and `users.can_decisions`, and two new empty tables, `decisions` and `vacancies`. Every existing activity starts as **Activity Based**. No existing value is changed.

What is new:

- **Short volume figures** on the dashboard pages: 950, 1.5K, 150K, 1.2M, 16.9M. Hover over a figure to see the exact number.
- **Volume type:** each activity's volume is **File Based** (for example, the rows of an uploaded file) or **Activity Based**.
  - Set it in Data Capture, in the template, or in the Review in Excel file.
  - Avg Daily Volume shows the two side by side, never added together. This shows on the Dashboard Activities box, the Activity Insights card and the volume charts.
  - To rename either type, use Admin → Labels ("File Based", "Activity Based").
- **Dashboard, Activities section:**
  - an **FTE / FTC** filter;
  - **View All Themes** to see every theme, not only the top 10;
  - each theme shows how many **functions** it covers and its employees split into **FTE / FTC**;
  - volumes show as two figures, transaction based and file based, never as a total.
- **Filter bar when a theme or category is opened** (Dashboard and Activity Insights):
  - **Function** (only the functions that have activities in the theme opened); once a function is picked, **Unit** appears. With one function on show, only Unit is offered.
  - **All Activities / Volume Based / Non Volume Based**; once Volume Based is picked, **Activity Based / File Based** appears.
  - The bar starts from what was clicked.
- **HR Decisions:** a button above Share Feedback.
  - Record decisions for each function: date, subject, decision and status (Decided, Implemented or On hold).
  - Search and filter by function, and download to Excel.
  - Only the admin and logins given **HR decisions** access can see them (Admin → Users → Edit access; the HR / executive preset ticks it).
  - Others can edit or delete only the decisions they recorded; the admin can change all of them.
- **Vacant positions:** Admin → **Vacant Positions**.
  - Add vacant or to be hired positions for a function: position, FTE or FTC, number of positions, grade, unit, a note, and who the position reports to. That can be an employee or **another vacant position** (for example a vacant team under a vacant unit head).
  - **Job Description / Activities:** type the JD of the position. Clicking the vacant box in the organogram (or its row in View List) opens it in a popup.
  - **Fill** marks one position as filled, optionally naming the employee who took it. A filled position leaves the chart; positions reporting to it then show under that employee. **Reopen** undoes the last fill.
  - They show in the Dashboard organogram when one function is selected (not for the whole of COSO), as dashed boxes under their manager.
  - A collapsed manager shows "+N vacant"; a line above the chart gives the totals and a list.
  - They are never counted as employees.
- **Activity Insights:** in a theme's activity list, click an employee's name to open the same popup as Employee Activities (activities, filters, Previous / Next, Export PDF). The employee PDF and popup now show the **Grade**.
- **Dashboard organogram, one function selected:** the classic chart is back. Click anyone to open or close their team without hiding the others, use Expand One More Level and Collapse, and double-click to centre on a person. The whole-COSO view keeps the simple chart.
- **Share Feedback:** only **Suggestion** and **Employee Change**. Feedback sent earlier keeps its topic.
- **Dashboard, Activities section:** livelier colours, Title Case column headings, no heading above the theme list. Volume Based / Non Volume Based use the same colours as FTE / FTC.
- **One-page summary PDF:** built but hidden for now; it can be switched on in a later update.
- **Colours:** one muted palette based on the HBL green (sage, bronze and slate), replacing the yellow, blue and purple.
- **Geographical Spread:** Regions at a Glance shows the top 10 regions: 5 to a line on wide screens, 4 on laptop screens.
- **Employee Activities:** the white figures bar shows Service and Support employees with their share (of the employees marked), on the right. The unit filter no longer shows "Unit not set" just because the function head has no unit.
- **Review in Excel:**
  - **Download Activities** asks which function, or all functions.
  - The file can change the unit, service / support, product, process, channel, description, category, theme, frequency, volume, volume type, peaks, nature of work, processing time and automation.
  - It can **delete** activities: write Yes in the red *Delete activity* column.
  - It can **add** activities: a row with an employee code and no Activity ID.
  - You get a preview first, and Undo Last Upload reverses everything.

VM folder: `/data/opt/ops-portal`. Service: `ops-portal`. Run the steps one by one; each block can be pasted as a whole.

---

## Step 1: Copy the zip to the VM

```
scp ops-portal-v2.12-update.zip YOUR_VM_USER@hblassist.domestic.hbl.com:/tmp/
```

## Step 2: Back up first (do not skip)

```
sudo systemctl stop ops-portal
STAMP=$(date +%Y%m%d_%H%M)
sudo mkdir -p /data/opt/ops-portal/backups
sudo python3 -c "import sqlite3,sys; s=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); d=sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close(); print('database backed up')" /data/opt/ops-portal/backups/portal_before_2.12_$STAMP.db
sudo tar -czf /data/opt/ops-portal/backups/code_before_2.12_$STAMP.tgz -C /data/opt/ops-portal --exclude backend/venv --exclude backend/data --exclude backups .
sudo python3 -c "import sqlite3,glob; f=sorted(glob.glob('/data/opt/ops-portal/backups/portal_before_2.12_*.db'))[-1]; c=sqlite3.connect(f); print(f); print(c.execute('pragma integrity_check').fetchone()[0], c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities')"
```

The last command should print `ok`, then your employee and activity counts. **Write the two numbers down.**

## Step 3: Install the new code

```
rm -rf /tmp/ops-update && python3 -m zipfile -e /tmp/ops-portal-v2.12-update.zip /tmp/ops-update
ls /tmp/ops-update/ops-portal/backend/app/main.py && echo "zip OK"
sudo rsync -a --exclude 'backend/data' --exclude 'backend/venv' --exclude 'backups' --exclude 'wheels' /tmp/ops-update/ops-portal/ /data/opt/ops-portal/
```

If `rsync` is not installed, use this instead:

```
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo cp -r /tmp/ops-update/ops-portal/backend/app /tmp/ops-update/ops-portal/backend/static /data/opt/ops-portal/backend/
sudo cp -r /tmp/ops-update/ops-portal/deploy /data/opt/ops-portal/
```

## Step 4: Set the owner and permissions

```
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 700 /data/opt/ops-portal/backend/data
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/secret.key
sudo chmod -R a+rX /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo chmod 755 /data/opt/ops-portal/backend/venv/bin/*
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
```

## Step 5: Start the portal and check it

```
sudo systemctl start ops-portal
sleep 8
sudo systemctl status ops-portal --no-pager | head -5
sudo journalctl -u ops-portal -n 30 --no-pager
sudo -u opsportal python3 -c "import sqlite3; c=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); print(c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities'); print('volume types:', c.execute('select volume_type, count(*) from work_items group by 1').fetchall()); print('new tables:', [r[0] for r in c.execute(\"select name from sqlite_master where name in ('decisions','vacancies')\")])"
```

Check three things:

- The status shows **active (running)**.
- The log has no `Traceback`.
- The counts match step 2, and the volume types line shows only `('', N)`, meaning everything is still Activity Based.

## Step 6: In the browser

Press **Ctrl+F5**. Then look at:

- the Dashboard, Activities section;
- Activity Insights;
- Admin, Activity Categories, Download Activities.

```
rm -rf /tmp/ops-update /tmp/ops-portal-v2.12-update.zip
```

---

## Marking file based volumes

Choose whichever way suits the number of activities:

- **A few activities:** go to Data Capture, step 2. Each activity has a **Volume type** switch next to the volume.
- **Many at once:** use **Admin, Activity Categories, Review in Excel, Download Activities**. In the *Volume type* column, choose **File Based** and correct the *Avg volume* if needed, then upload.
- **POCs:** the data capture template has a **Volume type** column with a drop-down. A template downloaded before 2.12, without that column, keeps each activity's volume type as it was.

## Review by functional heads (one Excel per function)

1. **Admin, Activity Categories, Review in Excel, Download Activities.** Choose the function and click **Download**. Repeat for each function. Each file has only that function's employees and activities.
2. The functional head edits the **green** columns. Blank cells leave the portal's value as it is.
   - **Unit** and **Service / support** belong to the employee. Use the same value on all of the employee's rows; if the rows differ, the value used most is applied and the preview lists the conflict.
   - **Activity theme** belongs to the category: every activity of a category gets the same theme.
   - **Delete an activity:** write **Yes** in the red *Delete activity* column.
   - **Add an activity:** add a row with the **Employee code** and the details, and leave the *Activity ID* empty.
   - Sorting and filtering the rows is fine. Do not change the Activity ID.
3. **Take a backup:** `sudo /data/opt/ops-portal/deploy/backup_db.sh`.
4. **Upload Changes.** The preview shows what the file changes:
   - activities added and deleted;
   - each field changed;
   - employees whose unit or service / support changes;
   - rows left out;
   - values not accepted.

   Nothing changes until you click **Apply Changes**.
5. **Undo Last Upload** reverses the whole of the last upload:
   - changed fields go back;
   - added activities are taken out;
   - deleted activities come back;
   - employee units and service / support are restored.

   Only the last upload can be undone, so check each one before uploading the next.

Employees and functions that are not in the file are never changed. Uploading one function's file therefore leaves every other function as it is.

The boss's earlier files (the Excel export, or files with **Revised ...** columns and no Activity ID) still work as before. From those files the portal reads only descriptions, categories, themes, volumes and the Revised columns, and the preview says so.

---

## Roll back to 2.11 (about 2 minutes)

```
sudo systemctl stop ops-portal
DB=$(ls -t /data/opt/ops-portal/backups/portal_before_2.12_*.db | head -1); CODE=$(ls -t /data/opt/ops-portal/backups/code_before_2.12_*.tgz | head -1); echo "$DB"; echo "$CODE"
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo tar -xzf "$CODE" -C /data/opt/ops-portal
sudo cp "$DB" /data/opt/ops-portal/backend/data/portal.db
sudo rm -f /data/opt/ops-portal/backend/data/portal.db-wal /data/opt/ops-portal/backend/data/portal.db-shm
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
sudo systemctl start ops-portal
```

Rolling back the database also removes anything entered after the update. Only do it if 2.12 does not work.
