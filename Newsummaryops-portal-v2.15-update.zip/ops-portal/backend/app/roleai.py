"""Role overlap: the on-premise AI compares a supervisor's activities with their direct reports', and colleagues'
activities with each other (same manager, or same unit under different managers).

The AI server is the bank's own vLLM (OpenAI-compatible API) on the VM; nothing leaves the network. The admin sets
its address and model in Admin, AI Server. A run works in a background thread of the portal: it reads the data once,
sends the AI one request per supervisor (and batches of candidate colleague pairs), keeps only answers that refer to
the activities it was given, and saves the result per function. Nothing in the portal's data is changed.
"""
import json
import logging
import re
import threading
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, List, Optional

from . import models
from .db import SessionLocal
from .security import get_setting, set_setting

log = logging.getLogger("ops.roleai")

DEFAULTS = {"url": "http://127.0.0.1:8000", "model": "qwen", "api_key": "", "concurrency": 4, "max_tokens": 1800,
            "timeout": 240, "json_mode": True, "threshold": 50}
MAX_ACTS_PER_PROMPT = 110      # supervisor + reports' activities in one request; larger teams are split
MAX_PROMPT_CHARS = 16000       # about 4,500 tokens of prompt
MIN_ACTS = 3                   # fewer supervisor activities than this: no percentage-based flags
PAIR_BATCH = 20                # colleague pairs judged per request
MAX_PAIRS_PER_FUNCTION = 4000


def settings(db) -> dict:
    s = dict(DEFAULTS)
    s.update({k: v for k, v in (get_setting(db, "ai_server") or {}).items() if k in DEFAULTS})
    return s


def save_settings(db, new: dict):
    s = settings(db)
    for k in DEFAULTS:
        if k in new and new[k] is not None:
            s[k] = new[k]
    s["url"] = str(s["url"]).strip().rstrip("/")
    s["concurrency"] = max(1, min(16, int(s["concurrency"])))
    s["max_tokens"] = max(300, min(8000, int(s["max_tokens"])))
    s["timeout"] = max(20, min(1800, int(s["timeout"])))
    s["threshold"] = max(10, min(100, int(s["threshold"])))
    set_setting(db, "ai_server", s)
    return s


# ---------------------------------------------------------------- the AI server
class AiError(Exception):
    pass


def _post(cfg, path, body, timeout):
    req = urllib.request.Request(cfg["url"] + path, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", **({"Authorization": "Bearer " + cfg["api_key"]} if cfg.get("api_key") else {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        raise AiError(f"The AI server answered {e.code}: {e.read().decode(errors='replace')[:300]}")
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
        raise AiError(f"The AI server at {cfg['url']} could not be reached ({getattr(e, 'reason', e)}).")


def models_list(cfg) -> List[str]:
    req = urllib.request.Request(cfg["url"] + "/v1/models", headers={"Authorization": "Bearer " + cfg["api_key"]} if cfg.get("api_key") else {})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return [m.get("id") for m in json.loads(r.read().decode()).get("data", [])]
    except urllib.error.HTTPError as e:
        raise AiError(f"The AI server answered {e.code}.")
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
        raise AiError(f"The AI server at {cfg['url']} could not be reached ({getattr(e, 'reason', e)}).")


SYSTEM = ("You are an operations analyst in a bank. You compare job activities written by different employees and "
          "decide whether they are the same work, even when they use different words. You are careful: two activities "
          "are the same work only when the same task is done on the same thing. Reviewing, checking, approving or "
          "authorizing what someone else prepared is NOT the same work as preparing it (maker and checker are "
          "different work). Answer with JSON only, no other text.")


def chat_json(cfg, prompt: str, system: str = None) -> dict:
    body = {"model": cfg["model"], "temperature": 0, "max_tokens": cfg["max_tokens"],
            "messages": [{"role": "system", "content": system or SYSTEM}, {"role": "user", "content": prompt}]}
    if cfg.get("json_mode"):
        body["response_format"] = {"type": "json_object"}
    last = None
    for attempt in range(2):
        try:
            out = _post(cfg, "/v1/chat/completions", body, cfg["timeout"])
        except AiError as e:
            if "400" in str(e) and "response_format" in body:   # an older vLLM without JSON mode
                body.pop("response_format")
                continue
            last = e
            time.sleep(2)
            continue
        text = ((out.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        data = parse_json(text)
        if data is not None:
            return data
        last = AiError("The AI answer was not valid JSON.")
    raise last or AiError("No answer from the AI.")


def parse_json(text: str) -> Optional[dict]:
    text = (text or "").strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    try:
        v = json.loads(text)
        return v if isinstance(v, dict) else None
    except ValueError:
        pass
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        try:
            v = json.loads(m.group(0))
            return v if isinstance(v, dict) else None
        except ValueError:
            return None
    return None


def test_connection(cfg) -> dict:
    t = time.time()
    names = models_list(cfg)
    if cfg["model"] not in names:
        raise AiError(f"The AI server is running, but has no model called '{cfg['model']}'. It has: {', '.join(names) or 'none'}.")
    ans = chat_json(dict(cfg, max_tokens=60), 'Reply with this JSON exactly: {"ok": true}')
    return {"models": names, "ok": bool(ans.get("ok")), "seconds": round(time.time() - t, 1)}


# ---------------------------------------------------------------- words (to find candidate colleague pairs)
STOP = set("""a an the and or of to for in on at by with from into is are be as this that these those all any each per via
daily weekly monthly basis ensure ensuring timely proper accurate accurately properly relevant related necessary required
etc e g ie also work task tasks activity activities process processing team staff officer officers""".split())
SYN = {"approve": "authorize", "approval": "authorize", "authorisation": "authorize", "authorization": "authorize", "authorise": "authorize",
       "signoff": "authorize", "release": "authorize", "check": "verify", "checking": "verify", "validate": "verify",
       "validation": "verify", "scrutiny": "verify", "scrutinize": "verify", "review": "verify", "match": "reconcile",
       "tally": "reconcile", "reconciliation": "reconcile", "reconcil": "reconcile", "email": "mail", "e-mail": "mail",
       "upload": "input", "enter": "input", "entry": "input", "entries": "input", "capture": "input", "posting": "input",
       "post": "input", "gl": "ledger", "statement": "report", "mis": "report", "reporting": "report", "query": "complaint",
       "queries": "complaint", "customer": "client", "clients": "client", "document": "doc", "documents": "doc", "documentation": "doc"}


def stem(w: str) -> str:
    w = SYN.get(w, w)
    for suf in ("ations", "ation", "ments", "ment", "ings", "ing", "ions", "ion", "ers", "er", "ies", "es", "ed", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            w = w[: -len(suf)]
            break
    return SYN.get(w, w)


def words(*texts) -> set:
    out = set()
    for t in texts:
        for w in re.findall(r"[a-z0-9]+", (t or "").lower()):
            if w not in STOP and len(w) > 1:
                out.add(stem(w))
    return out


def _norm(s):
    return " ".join((s or "").lower().split())


# ---------------------------------------------------------------- reading the data (once per run)
def read_function(db, fid: int, days: Dict[str, float]) -> dict:
    """Plain copies of a function's working employees and their activities (threads never touch the session)."""
    emps = {e.code: e for e in db.query(models.Employee).filter(models.Employee.function_id == fid) if not e.resigned}
    acts: Dict[int, dict] = {}
    by_emp: Dict[str, List[int]] = {}
    for w in db.query(models.WorkItem).filter(models.WorkItem.employee_code.in_(list(emps) or ["-"])).order_by(models.WorkItem.employee_code, models.WorkItem.sort, models.WorkItem.id):
        d = days.get(w.frequency or "Daily", 1.0) or 1.0
        acts[w.id] = {"id": w.id, "code": w.employee_code, "desc": (w.description or "").strip()[:400], "cat": (w.category or "").strip(),
                      "process": (w.process or "").strip(), "product": (w.product or "").strip(), "freq": w.frequency or "",
                      "vday": round((w.volume or 0) / d, 1) if w.volume else 0, "volume": w.volume or 0,
                      "hours": round(float(w.minutes or 0) * float(w.volume or 0) / d / 60.0, 3)}
        by_emp.setdefault(w.employee_code, []).append(w.id)
    E = {c: {"code": c, "name": e.name, "position": e.position or "", "grade": e.grade or "", "emp_type": e.emp_type,
             "manager": e.manager_code or "", "unit": e.unit_name or "", "region": e.region or "", "acts": by_emp.get(c, [])}
         for c, e in emps.items()}
    return {"emps": E, "acts": acts}


def act_line(a, tag):
    bits = [f"{tag} |"]
    if a["cat"]:
        bits.append(f"Category: {a['cat']} |")
    if a["process"]:
        bits.append(f"Process: {a['process']} |")
    if a["product"]:
        bits.append(f"Product: {a['product']} |")
    if a.get("volume"):
        bits.append(f"Volume: {a['volume']:g} {(a.get('freq') or '').lower()} |")
    elif a.get("freq"):
        bits.append(f"{a['freq']} |")
    bits.append(a["desc"] or "(no description)")
    return " ".join(bits)


# ---------------------------------------------------------------- planning the requests
def plan_function(data: dict) -> dict:
    """Supervisor requests (a supervisor with a chunk of their reports) and colleague pair candidates."""
    E, A = data["emps"], data["acts"]
    kids: Dict[str, List[str]] = {}
    for c, e in E.items():
        if e["manager"] in E:
            kids.setdefault(e["manager"], []).append(c)
    sup_reqs = []
    for m, ks in kids.items():
        if not E[m]["acts"]:
            continue
        ks = sorted([k for k in ks if E[k]["acts"]], key=lambda k: E[k]["name"])
        if not ks:
            continue
        # requests are kept to about 4,500 words' worth of text (prompt + answer stay inside an 8,192-token model)
        cost = lambda code: 60 + sum(len(act_line(A[i], "R00.00")) + 1 for i in E[code]["acts"])
        base = 900 + cost(m)
        chunk, size, n_acts, first = [], base, len(E[m]["acts"]), True
        for k in ks:
            ck, n = cost(k), len(E[k]["acts"])
            if chunk and (size + ck > MAX_PROMPT_CHARS or n_acts + n > MAX_ACTS_PER_PROMPT):
                sup_reqs.append({"kind": "sup", "manager": m, "reports": chunk, "labels": first})
                chunk, size, n_acts, first = [], base, len(E[m]["acts"]), False
            chunk.append(k)
            size += ck
            n_acts += n
        sup_reqs.append({"kind": "sup", "manager": m, "reports": chunk, "labels": first})
    # colleague pairs: same manager, or the same unit under different managers (not a manager and their own report)
    groups = {}
    for c, e in E.items():
        if not e["acts"]:
            continue
        if e["manager"]:
            groups.setdefault(("mgr", e["manager"]), []).append(c)
        if e["unit"]:
            groups.setdefault(("unit", e["unit"].lower()), []).append(c)
    W = {i: words(a["desc"], a["process"]) for i, a in A.items()}
    cand: Dict[tuple, float] = {}
    for (kind, _), members in groups.items():
        if len(members) < 2:
            continue
        pool = [i for c in members for i in E[c]["acts"]]
        index: Dict[str, List[int]] = {}
        for i in pool:
            for w in W[i]:
                index.setdefault(w, []).append(i)
            if A[i]["cat"]:
                index.setdefault("#cat:" + _norm(A[i]["cat"]), []).append(i)
        common = len(pool) * 0.25   # very common words do not suggest a match on their own
        for i in pool:
            seen = set()
            keys = [w for w in W[i] if len(index.get(w, [])) <= max(4, common)] + (["#cat:" + _norm(A[i]["cat"])] if A[i]["cat"] else [])
            for k in keys:
                for j in index.get(k, []):
                    if j <= i or j in seen:
                        continue
                    seen.add(j)
                    a, b = A[i], A[j]
                    if a["code"] == b["code"]:
                        continue
                    ea, eb = E[a["code"]], E[b["code"]]
                    if ea["manager"] == b["code"] or eb["manager"] == a["code"]:
                        continue   # a manager and their own report: the supervisor request covers it
                    wa, wb = W[i], W[j]
                    jac = len(wa & wb) / max(1, len(wa | wb))
                    samecat = bool(a["cat"]) and _norm(a["cat"]) == _norm(b["cat"])
                    if samecat or jac >= 0.3 or (a["process"] and _norm(a["process"]) == _norm(b["process"]) and jac >= 0.15):
                        key = (min(i, j), max(i, j))
                        cand[key] = max(cand.get(key, 0), jac + (0.5 if samecat else 0))
    # the strongest candidates first, a few per pair of colleagues
    per_pair: Dict[tuple, List[tuple]] = {}
    for (i, j), sc in cand.items():
        pk = tuple(sorted((A[i]["code"], A[j]["code"])))
        per_pair.setdefault(pk, []).append((sc, i, j))
    pairs = []
    for pk, lst in per_pair.items():
        lst.sort(reverse=True)
        pairs += [(i, j, sc) for sc, i, j in lst[:12]]
    pairs.sort(key=lambda x: -x[2])
    pairs = [(i, j) for i, j, _ in pairs[:MAX_PAIRS_PER_FUNCTION]]
    pair_reqs = [{"kind": "pairs", "pairs": pairs[k:k + PAIR_BATCH]} for k in range(0, len(pairs), PAIR_BATCH)]
    return {"sup": sup_reqs, "pairs": pair_reqs}


def sup_prompt(data, req):
    E, A = data["emps"], data["acts"]
    m = E[req["manager"]]
    ids = {}
    lines = [f"Supervisor: {m['name']}, {m['position'] or 'no position'}.", "", "Supervisor's activities:"]
    for n, i in enumerate(m["acts"], 1):
        tag = f"M{n}"; ids[tag] = i; lines.append(act_line(A[i], tag))
    lines.append("")
    lines.append("Direct reports and their activities:")
    for r, k in enumerate(req["reports"], 1):
        e = E[k]
        lines.append(f"R{r}: {e['name']}, {e['position'] or 'no position'}")
        for n, i in enumerate(e["acts"], 1):
            tag = f"R{r}.{n}"; ids[tag] = i; lines.append(act_line(A[i], tag))
    task = ["", "Tasks:"]
    if req["labels"]:
        task.append('1. Label every supervisor activity (M...) "supervisory" (reviewing, checking, approving or authorizing others\' work, '
                    'supervising, allocating work, monitoring the team, people management) or "hands-on" (doing the work itself).')
    task.append(f'{2 if req["labels"] else 1}. List every pair of a supervisor activity (M...) and a direct report activity (R...) that are the same work. '
                'confidence "high" when clearly the same task on the same thing, "medium" when they partly overlap. '
                'Do not list pairs that only share a general topic. Never match a supervisor activity you labelled "supervisory": checking, approving or authorizing '
                'what a report prepared is a different role (maker-checker), even when it is about the same file. '
                'Managing, overseeing, monitoring or ensuring work that a report executes is supervision, not the same work: '
                'match only when both do the task themselves.')
    task.append(f'{3 if req["labels"] else 2}. One short sentence that summarises how much of the supervisor\'s work is also done by the reports.')
    task.append("")
    task.append('Answer JSON: {' + ('"labels": {"M1": "supervisory"}, ' if req["labels"] else "") +
                '"matches": [{"m": "M1", "r": "R1.2", "confidence": "high", "reason": "a few words"}], "summary": "one sentence"}')
    return "\n".join(lines + task), ids


def pairs_prompt(data, req):
    A = data["acts"]
    lines = ["For each numbered pair, decide whether the two activities (done by two different colleagues) are the same work.", ""]
    for n, (i, j) in enumerate(req["pairs"], 1):
        lines.append(f"Pair {n}:")
        lines.append("  " + act_line(A[i], "A"))
        lines.append("  " + act_line(A[j], "B"))
    lines += ["", 'same: "high" (clearly the same task on the same thing), "medium" (partly the same), or "no".',
              'Answer JSON: {"results": [{"pair": 1, "same": "high", "reason": "a few words"}]} with every pair.']
    return "\n".join(lines)


# ---------------------------------------------------------------- turning answers into results
def _conf(v):
    v = str(v or "").strip().lower()
    return "high" if v.startswith("h") else "medium" if v.startswith("m") else None


def read_sup_answer(ans, ids, req):
    labels, matches = {}, []
    for tag, v in (ans.get("labels") or {}).items():
        if tag in ids and str(tag).startswith("M"):
            labels[ids[tag]] = "supervisory" if str(v).lower().startswith("sup") else "hands-on"
    for x in ans.get("matches") or []:
        if not isinstance(x, dict):
            continue
        a, b, c = ids.get(str(x.get("m", "")).strip()), ids.get(str(x.get("r", "")).strip()), _conf(x.get("confidence"))
        if a and b and c and str(x.get("m", "")).startswith("M") and str(x.get("r", "")).startswith("R"):
            matches.append({"a": a, "b": b, "conf": c, "reason": str(x.get("reason") or "")[:200]})
    return labels, matches, str(ans.get("summary") or "")[:500]


def read_pairs_answer(ans, req):
    out = []
    for x in ans.get("results") or []:
        if not isinstance(x, dict):
            continue
        try:
            n = int(x.get("pair"))
        except (TypeError, ValueError):
            continue
        c = _conf(x.get("same"))
        if c and 1 <= n <= len(req["pairs"]):
            i, j = req["pairs"][n - 1]
            out.append({"a": i, "b": j, "conf": c, "reason": str(x.get("reason") or "")[:200]})
    return out


# Not used at the moment (the AI decides): word lists for overseeing vs doing. A supervisor's activity that manages, oversees, reviews or authorises
# what a report executes is maker-checker / supervision, even when the AI matched the two.
OVERSIGHT = {"manage", "manages", "oversee", "oversees", "overseeing", "supervise", "supervises", "monitor", "monitors", "review", "reviews",
             "authorize", "authorizes", "authorise", "authorises", "approve", "approves", "verify", "verifies", "ensure", "ensures",
             "lead", "leads", "coordinate", "coordinates", "guide", "guides", "check", "checks", "validate", "validates", "allocate", "allocates",
             "scrutinize", "scrutinizes", "scrutinise", "scrutinises", "examine", "examines", "inspect", "inspects"}
EXECUTE = {"execute", "executes", "perform", "performs", "post", "posts", "prepare", "prepares", "input", "inputs",
           "enter", "enters", "maintain", "maintains", "resolve", "resolves", "reconcile", "reconciles", "upload", "uploads", "update", "updates",
           "create", "creates", "generate", "generates", "send", "sends", "handle", "handles",
           "assist", "assists", "provide", "provides", "conduct", "conducts", "carry", "carries", "incorporate", "incorporates", "draft", "drafts",
           "compile", "compiles", "collect", "collects", "scan", "scans", "dispatch", "dispatches", "respond", "responds",
           "submit", "submits", "configure", "configures", "develop", "develops", "calculate", "calculates"}


def _verbs(text):
    w = re.findall(r"[a-z]+", (text or "").lower())
    return {x for x in w if x in OVERSIGHT}, {x for x in w if x in EXECUTE}


def oversight_only(desc) -> bool:
    o, e = _verbs(desc)
    return bool(o) and not e


def oversees(sup_desc, rep_desc) -> bool:
    """The supervisor oversees what the report does: an oversight verb on the supervisor's side, and no doing-verb in common."""
    so, se = _verbs(sup_desc)
    ro, re_ = _verbs(rep_desc)
    if so & ro:
        return False   # both review / check / scrutinise the same thing (a four-eyes step done by both): the AI's match stands
    return bool(so) and not (se & re_) and not (ro and not re_)


def summarise(data, sup_out, pair_out, threshold, ph):
    """The figures and flags of a function, from the AI's answers."""
    E, A = data["emps"], data["acts"]
    sups = []
    for m, o in sup_out.items():
        e = E[m]
        reports = [k for k in o["reports"]]
        mine = e["acts"]
        ai_labels = o["labels"]
        labels = dict(ai_labels)
        o = dict(o, labels=labels)
        # a supervisor's check or approval of what a report prepared is maker-checker, not the same work:
        # such a match is kept for reading ("check") but never counts towards "same as team"
        ms = []
        for x in o["matches"]:
            x = dict(x)
            x["check"] = o["labels"].get(x["a"]) == "supervisory"   # the AI's own label decides (no word rules)
            ms.append(x)
        counted = [x for x in ms if not x["check"]]
        matched = {x["a"] for x in counted}
        by_r: Dict[str, set] = {}
        for x in counted:
            by_r.setdefault(A[x["b"]]["code"], set()).add(x["a"])
        sup_n = sum(1 for i in mine if o["labels"].get(i) == "supervisory")
        same = round(100 * len(matched) / len(mine)) if mine else 0
        supp = round(100 * sup_n / len(mine)) if mine and o["labels"] else None
        team = [k for k, x in E.items() if x["manager"] == m]
        enough = len(mine) >= MIN_ACTS   # a percentage of one or two activities says nothing
        flags = []
        if same >= threshold and enough:
            flags.append("team_work")
        if len(team) == 1:
            flags.append("single")
        near = [k for k, s in by_r.items() if enough and len(s) >= 2 and len(s) / len(mine) >= 0.7]
        if near:
            flags.append("near")
        if supp is not None and supp >= 60 and (same < threshold or not enough):
            flags.append("supervisory")
        if not enough:
            flags.append("few")
        # indicative overlap in FTE: the share of the supervisor's activities also done by the team (never more than 1)
        share = round(len(matched) / len(mine), 2) if mine else 0
        if not enough:
            share = 0
        summary = o["summary"]
        n_chk = len({x["a"] for x in ms if x["check"]})
        if n_chk or not enough:
            # the AI's own sentence may count approvals as the same work: the portal states the figures instead
            bits = [f"{len(matched)} of {len(mine)} of the supervisor's activities {'is' if len(matched) == 1 else 'are'} also done by the team"]
            if n_chk:
                bits.append(f"{n_chk} {'is a check or approval' if n_chk == 1 else 'are checks or approvals'} of the team's work (maker-checker, not counted)")
            if not enough:
                bits.append("too few activities captured to judge the role")
            summary = "; ".join(bits) + "."
        sups.append({"code": m, "team": len(team), "reports_compared": reports, "activities": len(mine), "matched": len(matched),
                     "checks": n_chk, "same_pct": same,
                     "supervisory_pct": supp, "flags": flags, "near": near, "summary": summary, "ai_summary": o["summary"], "labels": {str(k): v for k, v in o["labels"].items()}, "ai_labels": {str(k): v for k, v in ai_labels.items()},
                     "matches": ms, "overlap_fte": share})
    sups.sort(key=lambda s: ("few" in s["flags"], -s["same_pct"], -s["matched"], E[s["code"]]["name"]))
    # colleague pairs
    pp: Dict[tuple, list] = {}
    for x in pair_out:
        a, b = A[x["a"]]["code"], A[x["b"]]["code"]
        if a > b:
            x = {"a": x["b"], "b": x["a"], "conf": x["conf"], "reason": x["reason"]}
            a, b = b, a
        pp.setdefault((a, b), []).append(x)
    pairs = []
    for (a, b), ms in pp.items():
        ea, eb = E[a], E[b]
        ra, rb = ea["region"].strip().lower(), eb["region"].strip().lower()
        region = "unknown" if not ra or not rb else "same" if ra == rb else "different"
        ma, mb = {x["a"] for x in ms}, {x["b"] for x in ms}
        pairs.append({"a": a, "b": b, "same_manager": ea["manager"] == eb["manager"], "region": region,
                      "a_matched": len(ma), "a_acts": len(ea["acts"]), "b_matched": len(mb), "b_acts": len(eb["acts"]),
                      "a_vday": round(sum(A[i]["vday"] for i in ma), 1), "b_vday": round(sum(A[i]["vday"] for i in mb), 1),
                      "flag": region in ("same", "unknown"), "matches": ms,
                      # indicative: the smaller of the two shares of their activities that are the same (at most 1 FTE)
                      "overlap_fte": round(min(len(ma) / max(1, len(ea["acts"])), len(mb) / max(1, len(eb["acts"]))), 2)})
    pairs.sort(key=lambda p: (not p["flag"], -(p["a_matched"] + p["b_matched"])))
    keep = {s["code"] for s in sups} | {k for s in sups for k in s["reports_compared"]} | {p["a"] for p in pairs} | {p["b"] for p in pairs}
    # each person counts once, by their largest overlap: a flagged supervisor by the share of their work the team also
    # does; colleagues doing the same work in the same region by half their shared share each (one of the two could absorb it)
    per: Dict[str, float] = {}
    for s_ in sups:
        if any(f in s_["flags"] for f in ("team_work", "single", "near")):
            per[s_["code"]] = max(per.get(s_["code"], 0), s_["overlap_fte"])
    for p_ in pairs:
        if p_["region"] == "same":
            for c in (p_["a"], p_["b"]):
                per[c] = max(per.get(c, 0), p_["overlap_fte"] / 2)
    fte = sum(per.values())
    used = {i for s in sups for x in s["matches"] for i in (x["a"], x["b"])} | {i for p in pairs for x in p["matches"] for i in (x["a"], x["b"])}
    used |= {i for s in sups for i in E[s["code"]]["acts"]} | {i for s in sups for k in s["reports_compared"] for i in E[k]["acts"]}
    return {"supervisors": sups, "pairs": pairs, "fte": round(fte, 1), "threshold": threshold,
            "emps": {c: dict(e) for c, e in E.items() if c in keep},
            "acts": {str(i): A[i] for i in used}}


# ---------------------------------------------------------------- the background run
_lock = threading.Lock()
_cancel = set()


def busy(db) -> Optional[models.RoRun]:
    return db.query(models.RoRun).filter(models.RoRun.status.in_(["queued", "running"])).order_by(models.RoRun.id.desc()).first()


def start(db, function_id: Optional[int], user) -> models.RoRun:
    with _lock:
        if busy(db):
            raise AiError("The AI is busy with another run (Role Overlap or work summaries). Wait for it to finish, or stop it.")
        cfg = settings(db)
        run = models.RoRun(function_id=function_id, status="queued", model=cfg["model"], started_by=user.username)
        db.add(run)
        db.commit()
        threading.Thread(target=_run, args=(run.id,), daemon=True, name=f"roleai-{run.id}").start()
        return run


def cancel(run_id: int):
    _cancel.add(run_id)


def _update(run_id, **kw):
    db = SessionLocal()
    try:
        r = db.get(models.RoRun, run_id)
        for k, v in kw.items():
            setattr(r, k, v)
        db.commit()
    finally:
        db.close()


def _run(run_id: int):
    db = SessionLocal()
    try:
        run = db.get(models.RoRun, run_id)
        cfg = settings(db)
        from .logic import Calc
        c = Calc(db)
        fids = [run.function_id] if run.function_id else [f.id for f in db.query(models.Function).order_by(models.Function.name)]
        fnames = {f.id: f.name for f in db.query(models.Function)}
        work = []
        for fid in fids:
            data = read_function(db, fid, c.days)
            plan = plan_function(data)
            work.append((fid, data, plan))
        total = sum(len(p["sup"]) + len(p["pairs"]) for _, _, p in work)
        run.status, run.total = "running", total
        db.commit()
    except Exception as e:   # noqa: BLE001
        log.exception("role overlap run %s could not start", run_id)
        _update(run_id, status="failed", error=str(e)[:2000], finished_at=datetime.utcnow())
        db.close()
        return
    db.close()
    done = failed = 0
    errors: List[str] = []
    try:
        for fid, data, plan in work:
            if run_id in _cancel:
                break
            _update(run_id, current=fnames.get(fid, ""))
            sup_out: Dict[str, dict] = {}
            pair_out: List[dict] = []
            jobs = []
            with ThreadPoolExecutor(max_workers=cfg["concurrency"]) as ex:
                for req in plan["sup"]:
                    prompt, ids = sup_prompt(data, req)
                    jobs.append(ex.submit(lambda p=prompt: chat_json(cfg, p)))
                    jobs[-1].meta = ("sup", req, ids)
                for req in plan["pairs"]:
                    jobs.append(ex.submit(lambda p=pairs_prompt(data, req): chat_json(cfg, p)))
                    jobs[-1].meta = ("pairs", req, None)
                for f in as_completed(jobs):
                    kind, req, ids = f.meta
                    try:
                        ans = f.result()
                        if kind == "sup":
                            labels, matches, summary = read_sup_answer(ans, ids, req)
                            o = sup_out.setdefault(req["manager"], {"labels": {}, "matches": [], "summary": "", "reports": []})
                            o["labels"].update(labels)
                            o["matches"] += matches
                            o["reports"] += req["reports"]
                            if summary and (req["labels"] or not o["summary"]):
                                o["summary"] = summary
                        else:
                            pair_out += read_pairs_answer(ans, req)
                        done += 1
                    except Exception as e:   # noqa: BLE001
                        failed += 1
                        if len(errors) < 5:
                            errors.append(str(e)[:300])
                    if (done + failed) % 2 == 0 or done + failed == total:
                        _update(run_id, done=done, failed=failed)
                    if run_id in _cancel:
                        for j in jobs:
                            j.cancel()
                        break
            if run_id in _cancel:
                break
            db = SessionLocal()
            try:
                ph = float(get_setting(db, "productive_hours") or 7.5)
                payload = summarise(data, sup_out, pair_out, cfg["threshold"], ph)
                payload["v"] = RESULT_VERSION
                payload["requests"] = {"planned": len(plan["sup"]) + len(plan["pairs"])}
                db.query(models.RoResult).filter(models.RoResult.function_id == fid).delete()
                db.add(models.RoResult(function_id=fid, run_id=run_id, payload=payload))
                db.commit()
            finally:
                db.close()
        if run_id in _cancel:
            _update(run_id, status="cancelled", done=done, failed=failed, finished_at=datetime.utcnow(), current="", error="\n".join(errors))
        elif total and failed == total:
            _update(run_id, status="failed", done=done, failed=failed, finished_at=datetime.utcnow(), current="",
                    error="Every AI request failed. " + ("\n".join(errors) or ""))
        else:
            _update(run_id, status="done", done=done, failed=failed, finished_at=datetime.utcnow(), current="", error="\n".join(errors))
    except Exception as e:   # noqa: BLE001
        log.exception("role overlap run %s failed", run_id)
        _update(run_id, status="failed", error=str(e)[:2000], finished_at=datetime.utcnow(), done=done, failed=failed)
    finally:
        _cancel.discard(run_id)


RESULT_VERSION = 6


def recompute_stored(db, force=False) -> int:
    """Rebuilds the figures and flags of stored results from the AI's saved answers (no AI requests), with today's rules."""
    from .logic import Calc
    rows = list(db.query(models.RoResult))
    rows = [r for r in rows if force or (r.payload or {}).get("v", 1) < RESULT_VERSION]
    if not rows:
        return 0
    c = Calc(db)
    cfg = settings(db)
    ph = float(get_setting(db, "productive_hours") or 7.5)
    n = 0
    for r in rows:
        old = r.payload or {}
        data = read_function(db, r.function_id, c.days)
        E, A = data["emps"], data["acts"]
        sup_out = {}
        for s_ in old.get("supervisors", []):
            if s_["code"] not in E:
                continue
            sup_out[s_["code"]] = {
                "labels": {int(k): v for k, v in (s_.get("ai_labels", s_.get("labels")) or {}).items() if int(k) in A},
                "matches": [{"a": x["a"], "b": x["b"], "conf": x["conf"], "reason": x.get("reason", "")}
                            for x in s_.get("matches", []) if x["a"] in A and x["b"] in A],
                "summary": s_.get("ai_summary", s_.get("summary", "")),
                "reports": [k for k in s_.get("reports_compared", []) if k in E]}
        pair_out = [{"a": x["a"], "b": x["b"], "conf": x["conf"], "reason": x.get("reason", "")}
                    for p_ in old.get("pairs", []) for x in p_.get("matches", []) if x["a"] in A and x["b"] in A]
        new = summarise(data, sup_out, pair_out, cfg["threshold"], ph)
        if "requests" in old:
            new["requests"] = old["requests"]
        new["v"] = RESULT_VERSION
        r.payload = new
        n += 1
    db.commit()
    return n


def mark_interrupted():
    """At start: a run that was going when the portal stopped is marked as stopped."""
    db = SessionLocal()
    try:
        for r in db.query(models.RoRun).filter(models.RoRun.status.in_(["queued", "running"])):
            r.status, r.error, r.finished_at = "failed", "The portal was restarted while this analysis was running. Run it again.", datetime.utcnow()
        db.commit()
    finally:
        db.close()
