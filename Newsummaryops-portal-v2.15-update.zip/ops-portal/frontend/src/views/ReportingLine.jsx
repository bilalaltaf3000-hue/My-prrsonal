import React, { useEffect, useState } from 'react'
import { fmt } from '../org.js'
import { Dot, Modal } from '../ui.jsx'
import { Classic } from './Organogram.jsx'

// Who an employee reports to (the whole line up to the top) and who reports to them, as a chart.
export default function ReportingLine({ code, org, theme, lookups, onClose, go }) {
  const [p, setP] = useState(() => org.byId.get(code) || null)
  if (!p) return <Modal title="Reporting Line" onClose={onClose}><div className="empty">This employee is not in the organisation data you can see.</div></Modal>
  const mgr = p.m >= 0 ? org.P[p.m] : null
  const chain = []; let x = p; while (x.m >= 0) { x = org.P[x.m]; chain.unshift(x) }
  return <Modal wide onClose={onClose} title={`Reporting Line: ${p.n}`} sub={`${p.pos || '-'} · ${p.g} · ${p.id} · ${org.F[p.f] || ''}`}>
    <div className="facts">
      <div><span>Reports To</span>{mgr ? <><b><button onClick={() => setP(mgr)} title="Centre the chart on this manager">{mgr.n}</button></b><small>{mgr.pos || '-'}</small></> : <b>Top of the Organisation</b>}</div>
      <div><span>Direct Reports</span><b>{fmt(p.nk)}</b><small><Dot fte />{fmt(p.kids.filter(k => org.counted(k) && k.fte).length)} FTE &nbsp;<Dot />{fmt(p.kids.filter(k => org.counted(k) && !k.fte).length)} FTC</small></div>
      <div><span>Total Team</span><b>{fmt(p.team)}</b><small>{p.depthBelow} Layer{p.depthBelow === 1 ? '' : 's'} Below</small></div>
      <div><span>Layer</span><b>{p.d >= 0 ? p.d + 1 : '-'}</b><small>{chain.length} Manager{chain.length === 1 ? '' : 's'} Above</small></div>
      <div><span>Type and Region</span><b>{p.fte ? 'FTE' : 'FTC'}{p.st ? ` · ${p.st}` : ''}</b><small>{p.rg || 'Region Not Set'}</small></div>
    </div>
    <Classic root={p} focus={p} onFocus={setP} org={org} theme={theme} largeTeam={lookups?.large_team || 40} compact
      onReroot={setP} onOpenList={setP} />
  </Modal>
}
