"""Vacant and to be hired positions: written by the admin for a function, shown in that function's organogram
under the manager they will report to. They are never counted as employees."""
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import audit, require_admin, require_dashboard, sees_everything, view_ids

router = APIRouter()


class VacancyIn(BaseModel):
    function_id: int
    manager_code: Optional[str] = None
    parent_id: Optional[int] = None      # reports to another vacant position (instead of an employee)
    position: str
    grade: str = ""
    emp_type: str = "FTE"
    count: int = 1
    unit: str = ""
    note: str = ""


class FillIn(BaseModel):
    code: Optional[str] = None   # the employee who filled the position (optional)
    on: Optional[str] = None


def _out(v: models.Vacancy, names, fnames, pos):
    filled = min(v.filled or 0, v.count or 1)
    return {"id": v.id, "function_id": v.function_id, "function": fnames.get(v.function_id, ""), "manager_code": v.manager_code or "",
            "manager_name": names.get(v.manager_code, "") if v.manager_code else "", "parent_id": v.parent_id,
            "parent_position": pos.get(v.parent_id, "") if v.parent_id else "", "position": v.position or "", "grade": v.grade or "",
            "emp_type": v.emp_type or "FTE", "count": v.count or 1, "filled": filled, "open": (v.count or 1) - filled,
            "filled_log": list(v.filled_log or []), "unit": v.unit or "", "note": v.note or ""}


def _descendants(db, vid):
    kids = {}
    for x in db.query(models.Vacancy):
        if x.parent_id:
            kids.setdefault(x.parent_id, []).append(x.id)
    out, todo = set(), [vid]
    while todo:
        for k in kids.get(todo.pop(), []):
            if k not in out:
                out.add(k)
                todo.append(k)
    return out


def _clean(db, b: VacancyIn, vid=None) -> dict:
    if not db.get(models.Function, b.function_id):
        raise HTTPException(400, "Unknown function.")
    pos = " ".join((b.position or "").split())[:250]
    if len(pos) < 2:
        raise HTTPException(400, "Write the position, for example Officer Clearing.")
    m = (b.manager_code or "").strip() or None
    par = b.parent_id or None
    if par:
        pv = db.get(models.Vacancy, par)
        if not pv or pv.function_id != b.function_id:
            raise HTTPException(400, "The vacant position it reports to must be in the same function.")
        if vid and (par == vid or par in _descendants(db, vid)):
            raise HTTPException(400, "A position cannot report to itself or to a position below it.")
        m = None
    if m:
        e = db.get(models.Employee, m)
        if not e:
            raise HTTPException(400, f"No employee has the code {m}.")
    if b.emp_type not in ("FTE", "FTC"):
        raise HTTPException(400, "Choose FTE or FTC.")
    if not 1 <= int(b.count or 1) <= 500:
        raise HTTPException(400, "The number of positions must be 1 to 500.")
    return {"function_id": b.function_id, "manager_code": m, "parent_id": par, "position": pos, "grade": " ".join((b.grade or "").split())[:60],
            "emp_type": b.emp_type, "count": int(b.count or 1), "unit": " ".join((b.unit or "").split())[:200], "note": (b.note or "").strip()[:2000]}


def _list(db, fids):
    names = {c: n for c, n in db.query(models.Employee.code, models.Employee.name)}
    fnames = {f.id: f.name for f in db.query(models.Function)}
    q = db.query(models.Vacancy)
    if fids is not None:
        q = q.filter(models.Vacancy.function_id.in_(list(fids) or [-1]))
    rows = sorted(q, key=lambda v: (fnames.get(v.function_id, ""), names.get(v.manager_code, ""), v.position or ""))
    pos = {v.id: v.position for v in db.query(models.Vacancy)}
    return [_out(v, names, fnames, pos) for v in rows]


@router.get("/api/vacancies")
def vacancies(functions: str = Query(""), user=Depends(require_dashboard), db: Session = Depends(get_db)):
    """The vacant positions of the functions on show (only those the login may see)."""
    allowed = None if sees_everything(user) else view_ids(user, db)
    want = {int(x) for x in functions.split(",") if x.strip().isdigit()}
    fids = (want & allowed if allowed is not None else want) if want else allowed
    return _list(db, fids)


@router.get("/api/admin/vacancies")
def admin_list(function_id: Optional[int] = Query(None), user=Depends(require_admin), db: Session = Depends(get_db)):
    return _list(db, {function_id} if function_id else None)


@router.post("/api/admin/vacancies")
def add(body: VacancyIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    v = models.Vacancy(**_clean(db, body), created_by=user.username)
    db.add(v)
    audit(db, user, "vacancy_add", f"{v.position} x{v.count}")
    db.commit()
    return {"id": v.id}


@router.patch("/api/admin/vacancies/{vid}")
def edit(vid: int, body: VacancyIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    v = db.get(models.Vacancy, vid)
    if not v:
        raise HTTPException(404, "Vacant position not found.")
    for k, val in _clean(db, body, vid).items():
        setattr(v, k, val)
    v.filled = min(v.filled or 0, v.count)
    audit(db, user, "vacancy_edit", f"{v.position} x{v.count}")
    db.commit()
    return {"ok": True}


@router.delete("/api/admin/vacancies/{vid}")
def delete(vid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    v = db.get(models.Vacancy, vid)
    if not v:
        raise HTTPException(404, "Vacant position not found.")
    audit(db, user, "vacancy_delete", v.position)
    for x in db.query(models.Vacancy).filter(models.Vacancy.parent_id == v.id):   # positions below it move up to its manager
        x.parent_id, x.manager_code = v.parent_id, v.manager_code
    db.delete(v)
    db.commit()
    return {"ok": True}


@router.post("/api/admin/vacancies/{vid}/fill")
def fill(vid: int, body: FillIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    """One of the positions is filled (by an employee already in the portal, or not yet named). A position with
    nothing left open no longer shows in the organogram; positions reporting to it then show under that employee."""
    v = db.get(models.Vacancy, vid)
    if not v:
        raise HTTPException(404, "Vacant position not found.")
    if (v.filled or 0) >= (v.count or 1):
        raise HTTPException(400, "All of these positions are already filled.")
    code = (body.code or "").strip() or None
    e = db.get(models.Employee, code) if code else None
    if code and not e:
        raise HTTPException(400, f"No employee has the code {code}.")
    on = (body.on or "").strip()[:10] or datetime.now().strftime("%Y-%m-%d")
    v.filled_log = list(v.filled_log or []) + [{"code": code or "", "name": e.name if e else "", "on": on, "by": user.username}]
    v.filled = (v.filled or 0) + 1
    audit(db, user, "vacancy_fill", f"{v.position}: {e.name if e else 'filled'}")
    db.commit()
    return {"ok": True, "open": v.count - v.filled}


@router.post("/api/admin/vacancies/{vid}/reopen")
def reopen(vid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Undo the last fill."""
    v = db.get(models.Vacancy, vid)
    if not v or not (v.filled or 0):
        raise HTTPException(400, "Nothing to reopen.")
    log = list(v.filled_log or [])
    if log:
        log.pop()
    v.filled_log, v.filled = log, v.filled - 1
    audit(db, user, "vacancy_reopen", v.position)
    db.commit()
    return {"ok": True}
