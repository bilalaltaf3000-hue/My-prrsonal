import React, { useEffect, useState } from 'react'
import { api } from '../api.js'
import { fmt } from '../org.js'
import { Modal } from '../ui.jsx'

// Admin: vacant and to be hired positions of a function. They show in the function's organogram under the manager
// (or the vacant position) they will report to, as dashed boxes, and are never counted as employees.
// Filling a position takes it out of the chart; positions reporting to it then show under the employee who filled it.
const blank = fid => ({ function_id: fid, manager_code: '', manager_name: '', parent_id: null, position: '', grade: '', emp_type: 'FTE', count: 1, unit: '', note: '' })
const today = () => new Date().toISOString().slice(0, 10)

function EmpSearch({ fid, onPick, placeholder }) {
  const [q, setQ] = useState('')
  const [hits, setHits] = useState([])
  useEffect(() => {
    if (q.trim().length < 2) { setHits([]); return }
    const t = setTimeout(() => api(`/api/admin/employees?function_id=${fid}&q=${encodeURIComponent(q.trim())}`).then(r => setHits(r.filter(e => !e.resigned).slice(0, 12))).catch(() => setHits([])), 250)
    return () => clearTimeout(t)
  }, [q, fid])
  return <><input className="inp" value={q} onChange={e => setQ(e.target.value)} placeholder={placeholder} autoFocus />
    {hits.length > 0 && <div className="pick" style={{ maxHeight: 200 }}>{hits.map(e => <button key={e.code} type="button" onClick={() => { onPick(e); setQ('') }}>
      <span><b>{e.name}</b><small>{[e.position, e.grade, e.code, e.unit].filter(Boolean).join(' · ')}</small></span></button>)}</div>}</>
}

export default function VacanciesTab({ notify }) {
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState('')
  const [rows, setRows] = useState(null)
  const [form, setForm] = useState(null)
  const [to, setTo] = useState('emp')          // the form's Reports To: an employee or a vacant position
  const [fill, setFill] = useState(null)        // { v, emp, on }: filling one position
  const [busy, setBusy] = useState(false)
  useEffect(() => { api('/api/capture/functions').then(r => { const s = [...r].sort((a, b) => a.name.localeCompare(b.name)); setFns(s); if (s.length) setFid(String(s[0].id)) }).catch(e => notify(e.message, true)) }, [])
  const load = () => fid && api('/api/admin/vacancies?function_id=' + fid).then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { setRows(null); setForm(null); load() }, [fid])
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const open = f => { setForm(f); setTo(f.parent_id ? 'vac' : 'emp') }
  const save = async () => {
    setBusy(true)
    const body = { ...form, function_id: +fid, count: +form.count || 1, parent_id: to === 'vac' ? (form.parent_id ? +form.parent_id : null) : null, manager_code: to === 'emp' ? form.manager_code : null }
    try {
      if (form.id) await api(`/api/admin/vacancies/${form.id}`, { method: 'PATCH', body }); else await api('/api/admin/vacancies', { method: 'POST', body })
      notify(form.id ? 'Vacant position saved.' : 'Vacant position added.'); setForm(null); load()
    } catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const remove = async v => {
    if (!confirm(`Remove the vacant position "${v.position}"? Positions reporting to it move up to its manager.`)) return
    try { await api(`/api/admin/vacancies/${v.id}`, { method: 'DELETE' }); notify('Removed.'); load() } catch (e) { notify(e.message, true) }
  }
  const doFill = async () => {
    setBusy(true)
    try { await api(`/api/admin/vacancies/${fill.v.id}/fill`, { method: 'POST', body: { code: fill.emp?.code || null, on: fill.on } }); notify(fill.emp ? `Filled by ${fill.emp.name}.` : 'Marked as filled.'); setFill(null); load() }
    catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const reopen = async v => {
    if (!confirm(`Reopen one "${v.position}" position (undo the last fill)?`)) return
    try { await api(`/api/admin/vacancies/${v.id}/reopen`, { method: 'POST' }); notify('Reopened.'); load() } catch (e) { notify(e.message, true) }
  }
  // the positions a position can report to: any other in the function, except the ones below it
  const below = id => { const out = new Set(), todo = [id]; while (todo.length) { const x = todo.pop(); (rows || []).filter(r => r.parent_id === x).forEach(r => { if (!out.has(r.id)) { out.add(r.id); todo.push(r.id) } }) } return out }
  const parents = !rows || !form ? [] : rows.filter(r => r.id !== form.id && !(form.id && below(form.id).has(r.id)))
  const tot = (t, k = 'open') => (rows || []).filter(v => !t || v.emp_type === t).reduce((a, v) => a + v[k], 0)
  return <div>
    <p className="sub">Positions that are vacant or to be hired. They show in the function's organogram on the Dashboard, under the manager or the vacant position they will report to, with a dashed border. They are not counted as employees anywhere. When a position is filled, mark it filled: it leaves the chart, and positions reporting to it show under the employee who filled it.</p>
    <div className="kvline" style={{ marginBottom: 12 }}>
      <select value={fid} onChange={e => setFid(e.target.value)}>{fns.map(f => <option key={f.id} value={String(f.id)}>{f.name}</option>)}</select>
      {rows && <span className="formula">{!rows.length ? 'No vacant positions' : `${tot('')} open (${tot('FTE')} FTE, ${tot('FTC')} FTC)${tot('', 'filled') ? ` · ${tot('', 'filled')} filled` : ''}`}</span>}
      <span style={{ flex: 1 }} />
      <button className="btn pri" disabled={!fid} onClick={() => open(blank(+fid))}>Add a Vacant Position</button>
    </div>
    {form && <div className="panel vac-form">
      <div className="dc-grid">
        <label>Position<input className="inp" value={form.position} onChange={e => set('position', e.target.value)} placeholder="For example Officer Clearing" autoFocus /></label>
        <label>Type<span className="seg sm" role="group">{['FTE', 'FTC'].map(t => <button key={t} type="button" aria-pressed={form.emp_type === t} onClick={() => set('emp_type', t)}>{t}</button>)}</span></label>
        <label>Number of Positions<input className="inp" type="number" min="1" max="500" value={form.count} onChange={e => set('count', e.target.value)} style={{ width: 110 }} /></label>
        <label>Grade (Optional)<input className="inp" value={form.grade} onChange={e => set('grade', e.target.value)} placeholder="For example OG II" /></label>
        <label>Unit (Optional)<input className="inp" value={form.unit} onChange={e => set('unit', e.target.value)} /></label>
      </div>
      <label>Reports To
        <span className="seg sm" role="group" style={{ alignSelf: 'flex-start' }}>
          <button type="button" aria-pressed={to === 'emp'} onClick={() => setTo('emp')}>An Employee</button>
          <button type="button" aria-pressed={to === 'vac'} onClick={() => setTo('vac')} disabled={!parents.length} title={parents.length ? '' : 'Add the other vacant position first'}>Another Vacant Position</button></span>
        {to === 'vac' ? <select value={form.parent_id || ''} onChange={e => set('parent_id', e.target.value ? +e.target.value : null)} style={{ maxWidth: 520 }}>
            <option value="">Choose the vacant position</option>{parents.map(p => <option key={p.id} value={p.id}>{p.position} ({p.emp_type}{p.grade ? ', ' + p.grade : ''})</option>)}</select>
          : form.manager_code ? <div className="chosen"><span><b>{form.manager_name || form.manager_code}</b><small>{form.manager_code}</small></span><button type="button" className="linkbtn" onClick={() => { set('manager_code', ''); set('manager_name', '') }}>Change</button></div>
          : <EmpSearch fid={fid} onPick={e => setForm(f => ({ ...f, manager_code: e.code, manager_name: e.name }))} placeholder="Search the manager by name, code or position (blank: the function head)" />}</label>
      <label>Note (Optional)<textarea rows={2} value={form.note} maxLength={2000} onChange={e => set('note', e.target.value)} placeholder="For example approved in the October review; hiring in Q1" /></label>
      <div className="row-actions"><button className="btn pri" disabled={busy || form.position.trim().length < 2 || (to === 'vac' && !form.parent_id)} onClick={save}>{busy ? 'Saving…' : form.id ? 'Save' : 'Add Position'}</button><button className="btn" onClick={() => setForm(null)}>Cancel</button></div>
    </div>}
    {!rows ? <div className="loading">Loading…</div> : !rows.length ? <div className="empty">No vacant positions recorded for this function.</div>
      : <div className="panel" style={{ padding: 0 }}><div className="tw"><table>
        <thead><tr><th>Position</th><th>Reports To</th><th>Type</th><th>Grade</th><th>Unit</th><th>Status</th><th>Note</th><th></th></tr></thead>
        <tbody>{rows.map(v => <tr key={v.id} className={v.open ? '' : 'vac-done'}><td><b>{v.position}</b></td>
          <td>{v.parent_id ? <>{v.parent_position}<div className="formula">vacant position</div></> : <>{v.manager_name || 'Function head'}<div className="formula">{v.manager_code}</div></>}</td>
          <td>{v.emp_type}</td><td>{v.grade || '-'}</td><td>{v.unit || '-'}</td>
          <td>{v.open ? <span className="pill p-warn">{v.count > 1 ? `${v.open} of ${v.count} open` : 'Open'}</span> : <span className="pill p-ok">Filled</span>}
            {v.filled_log.length > 0 && <div className="formula">{v.filled_log.map(x => x.name || 'filled').join(', ')}</div>}</td>
          <td className="formula" style={{ maxWidth: 240 }}>{v.note}</td>
          <td style={{ whiteSpace: 'nowrap' }}>{v.open > 0 && <button className="linkbtn" onClick={() => setFill({ v, emp: null, on: today() })}>Fill</button>}{' '}
            {v.filled > 0 && <button className="linkbtn" onClick={() => reopen(v)}>Reopen</button>}{' '}
            <button className="linkbtn" onClick={() => open({ ...v })}>Edit</button>{' '}<button className="linkbtn" onClick={() => remove(v)}>Remove</button></td></tr>)}</tbody></table></div></div>}
    {fill && <Modal title={`Fill: ${fill.v.position}`} sub={fill.v.count > 1 ? `${fill.v.open} of ${fill.v.count} still open; this fills one` : 'This position leaves the organogram once filled'} onClose={() => setFill(null)}>
      <div className="vac-form" style={{ padding: 0 }}>
        <label>Filled By (Optional)
          {fill.emp ? <div className="chosen"><span><b>{fill.emp.name}</b><small>{[fill.emp.position, fill.emp.code].filter(Boolean).join(' · ')}</small></span><button type="button" className="linkbtn" onClick={() => setFill(f => ({ ...f, emp: null }))}>Change</button></div>
            : <EmpSearch fid={fid} onPick={e => setFill(f => ({ ...f, emp: e }))} placeholder="Search the employee who took the position (once in the portal)" />}</label>
        <label>Date Filled<input className="inp" type="date" value={fill.on} onChange={e => setFill(f => ({ ...f, on: e.target.value }))} style={{ maxWidth: 200 }} /></label>
        <p className="formula" style={{ margin: 0 }}>Positions that report to this one will show under the employee chosen here.</p>
        <div className="row-actions"><button className="btn pri" disabled={busy} onClick={doFill}>{busy ? 'Saving…' : 'Mark as Filled'}</button><button className="btn" onClick={() => setFill(null)}>Cancel</button></div>
      </div></Modal>}
  </div>
}
