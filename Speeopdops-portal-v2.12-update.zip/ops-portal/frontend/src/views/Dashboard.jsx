import React, { useEffect, useMemo, useRef, useState } from 'react'
import { api, unitQS, download } from '../api.js'
import { canExport } from '../rights.js'
import { ThemeCatBrowser, VolPair } from './Insights.jsx'
import { fmt, hrs, pct, short, TYPE_COL, typeLabel, pcs, vfmt } from '../org.js'
import { PeopleModal, ChartBox, css, Dot, Expand, Modal, Kpi, Ring, Split, Steps, useLive } from '../ui.jsx'
import { Classic } from './Organogram.jsx'
import Opportunities from './Opportunities.jsx'
import { prefs, L, themeColor } from '../prefs.js'

const SECTIONS = [['org', 'Organogram', 'Reporting Structure'], ['layers', 'Layers and Spans', 'Depth of the Structure'], ['work', 'Service or Support', 'Type of Work'], ['acts', 'Activities', 'Activity Themes'], ['opps', 'Opportunities', 'Structure Findings']]
const TYPES = ['Service', 'Support']   // employees not yet marked are not shown on the dashboard
// writes each bar's value above it
const barValues = { id: 'barValues', afterDatasetsDraw(chart) {
  const { ctx } = chart
  chart.data.datasets.forEach((ds, di) => chart.getDatasetMeta(di).data.forEach((bar, i) => {
    const v = ds.data[i]; if (!v) return
    ctx.save(); ctx.fillStyle = css('--ink-2'); ctx.font = '700 12px Manrope, Segoe UI, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom'
    ctx.fillText(Number(v).toLocaleString('en-US'), bar.x, bar.y - 4); ctx.restore()
  }))
} }
const byType = et => p => !et || (et === 'FTE' ? p.fte : !p.fte)
// FTE / FTC filter shown on the right of a section heading
export function TypeFilter({ value, onChange }) {
  return <span className="seg sm" role="group" aria-label="Filter by employee type">
    {[['', 'All Employees'], ['FTE', 'FTE'], ['FTC', 'FTC']].map(([v, l]) => <button key={v} type="button" aria-pressed={value === v} onClick={() => onChange(v)}>{l}</button>)}</span>
}

// ------------------------------------------------------------------ function filter (drop-down)
export function FilterBar({ fns, sel, setSel, label, scoped, total }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const ref = useRef(null)
  useEffect(() => {
    if (!open) return
    const out = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    const esc = e => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', out); document.addEventListener('keydown', esc)
    return () => { document.removeEventListener('mousedown', out); document.removeEventListener('keydown', esc) }
  }, [open])
  const toggle = id => setSel(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id])
  const all = scoped ? 'All my functions' : label
  const picked = fns.filter(f => sel.includes(f.id))
  const count = picked.length ? picked.reduce((a, f) => a + f.hc, 0) : total
  const ql = q.trim().toLowerCase()
  const shown = fns.filter(f => !ql || f.name.toLowerCase().includes(ql))
  return <div className="fpick" ref={ref}>
    <button type="button" className="fpick-btn" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(o => !o)}>
      {picked.length > 0 && <span className="fp-label">{picked.length === 1 ? "Function" : "Functions"}</span>}
      <span className="fp-val">{!picked.length ? <b>{all}</b> : picked.length === 1 ? <><i style={{ background: picked[0].color }} /><b>{picked[0].name}</b></> : <><span className="fp-dots">{picked.slice(0, 5).map(f => <i key={f.id} style={{ background: f.color }} />)}</span><b>{picked.length} functions</b></>}</span>
      <small>{fmt(count)}</small><span className="fp-caret">▾</span>
    </button>
    {picked.length > 1 && <span className="fp-names">{picked.map(f => f.name).join(' · ')}</span>}
    {picked.length > 0 && <button type="button" className="linkbtn" onClick={() => setSel([])}>Show {all}</button>}
    {open && <div className="fpick-pop" role="listbox" aria-multiselectable="true">
      <input className="inp" placeholder="Find a function" value={q} onChange={e => setQ(e.target.value)} autoFocus />
      <button type="button" className={'fp-row grp' + (!picked.length ? ' on' : '')} onClick={() => { setSel([]); setOpen(false) }}>
        <span className="fp-check">{!picked.length ? '✓' : ''}</span><b>{all}</b><small>{fmt(total)}</small></button>
      <div className="fp-list">{shown.map(f => { const on = sel.includes(f.id)
        return <button type="button" key={f.id} className={'fp-row' + (on ? ' on' : '')} role="option" aria-selected={on} onClick={() => toggle(f.id)}>
          <span className="fp-check">{on ? '✓' : ''}</span><i style={{ background: f.color }} /><span className="fp-name">{f.name}</span><small>{fmt(f.hc)}</small></button> })}
        {!shown.length && <div className="formula" style={{ padding: 10 }}>No function matches.</div>}</div>
      <div className="fp-foot"><span className="formula">{picked.length ? `${picked.length} selected` : ''}</span>
        <button type="button" className="btn" onClick={() => setSel([])} disabled={!picked.length}>Clear</button>
        <button type="button" className="btn pri" onClick={() => setOpen(false)}>Done</button></div>
    </div>}
  </div>
}

// unit filter: shown next to the function filter when the selected functions use units
export function UnitFilter({ units, sel, setSel }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const ref = useRef(null)
  useEffect(() => {
    if (!open) return
    const out = e => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    const esc = e => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', out); document.addEventListener('keydown', esc)
    return () => { document.removeEventListener('mousedown', out); document.removeEventListener('keydown', esc) }
  }, [open])
  const toggle = u => setSel(s => s.includes(u) ? s.filter(x => x !== u) : [...s, u])
  const ql = q.trim().toLowerCase()
  const shown = units.filter(u => !ql || u.toLowerCase().includes(ql))
  return <div className="fpick" ref={ref}>
    <button type="button" className="fpick-btn" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(o => !o)}>
      {sel.length > 0 && <span className="fp-label">{sel.length === 1 ? 'Unit' : 'Units'}</span>}
      <span className="fp-val"><b>{!sel.length ? 'All Units' : sel.length === 1 ? sel[0] : `${sel.length} units`}</b></span><span className="fp-caret">▾</span>
    </button>
    {sel.length > 1 && <span className="fp-names">{sel.join(', ')}</span>}
    {sel.length > 0 && <button type="button" className="linkbtn" onClick={() => setSel([])}>Show All Units</button>}
    {open && <div className="fpick-pop" role="listbox" aria-multiselectable="true">
      {units.length > 8 && <input className="inp" placeholder="Find a unit" value={q} onChange={e => setQ(e.target.value)} autoFocus />}
      <button type="button" className={'fp-row grp' + (!sel.length ? ' on' : '')} onClick={() => { setSel([]); setOpen(false) }}>
        <span className="fp-check">{!sel.length ? '✓' : ''}</span><b>All Units</b></button>
      <div className="fp-list">{shown.map(u => { const on = sel.includes(u)
        return <button type="button" key={u} className={'fp-row u' + (on ? ' on' : '')} role="option" aria-selected={on} onClick={() => toggle(u)}>
          <span className="fp-check">{on ? '✓' : ''}</span><span className="fp-name">{u}</span></button> })}
        {!shown.length && <div className="formula" style={{ padding: 10 }}>No unit matches.</div>}</div>
      <div className="fp-foot"><span className="formula">{sel.length ? `${sel.length} selected` : ''}</span>
        <button type="button" className="btn" onClick={() => setSel([])} disabled={!sel.length}>Clear</button>
        <button type="button" className="btn pri" onClick={() => setOpen(false)}>Done</button></div>
    </div>}
  </div>
}

function Sec({ id, n, title, sub, right, children, busy }) {
  return <section id={'sec-' + id} className={'dsec' + (busy ? ' busy' : '')}>
    <div className="dsec-h"><div><span className="dbul" /><h2>{title}</h2></div>{right}</div>
    {children}
  </section>
}

function Tile({ label, value, sub, tone, onClick, foot }) {
  const El = onClick ? 'button' : 'div'
  return <El className={'tile' + (onClick ? ' click' : '')} onClick={onClick} style={{ '--tc': tone || 'var(--teal)' }}>
    <span className="tl">{label}</span><b className="tv">{value}</b>{sub && <span className="ts">{sub}</span>}{foot}
    {onClick && <span className="tgo">View breakdown ›</span>}</El>
}

const HeadCard = ({ p, org, onOpen, big }) => <button className={'head' + (big ? ' big' : '')} style={{ '--fc': org.FCOL[p.f] }} onClick={() => onOpen(p)}>
  <span className="nm">{p.n}</span><span className="ps">{p.pos || '-'}</span>
  <span className="hk"><span><b>{fmt(p.nk)}</b> direct reports</span><span><b>{fmt(p.team)}</b> total team</span></span></button>

export default function Dashboard({ org, orgFor, orgSpan, go, theme, user, includeFlagged, setIncludeFlagged, sel, units, titleUnits, showLine }) {
  const { C, P, F, ROOT, fstats, FCOL } = org
  const [modal, setModal] = useState(null)
  const [croot, setCroot] = useState(null)
  const selKey = (sel || []).join(',')

  const fsorted = useMemo(() => [...fstats].sort((a, b) => a.name.localeCompare(b.name)), [fstats])
  const single = fsorted.length === 1
  const heads = useMemo(() => {
    if (!sel?.length) return [ROOT]
    return fsorted.map(s => s.head).filter(Boolean)
  }, [org])
  const chartRoot = single && heads[0] ? heads[0] : ROOT
  // section 1 can be limited to FTE or FTC staff
  const O = org   // the dashboard organogram shows all staff (no FTE / FTC filter)
  const H1 = heads.map(h => O.byId.get(h.id)).filter(Boolean)
  const R1 = O.byId.get(chartRoot.id) || O.ROOT
  const headSet = useMemo(() => new Set([ROOT.i, ...fstats.map(s => s.head?.i).filter(i => i !== undefined)]), [org])
  useEffect(() => setCroot(null), [org])
  const people = (title, list, sub, initial) => setModal({ kind: 'people', title, list, sub, initial })
  const openP = p => { if (showLine) showLine(p.id); else { setModal(null); go('org', p.i) } }

  // the title: the functions on show (by name), with the units when the unit filter is on
  const fnNames = [...fsorted].map(s => s.name).sort((a, b) => a.localeCompare(b))
  const fnTitle = !sel?.length && !org.scoped ? L('dash.title') : fnNames.length <= 4 ? fnNames.join(', ') : `${fnNames.length} Functions`
  const tu = titleUnits?.length ? titleUnits : units
  const title = tu?.length ? `${fnTitle}: ${tu.length <= 3 ? tu.join(', ') : tu.length + ' Units'}` : fnTitle
  const fte = C.filter(p => p.fte), ftc = C.filter(p => !p.fte)
  const mgrsAll = C.filter(p => p.nk > 0 && p !== ROOT)
  const avgSpan = mgrsAll.length ? mgrsAll.reduce((a, m) => a + m.nk, 0) / mgrsAll.length : 0
  const nLayers = new Set(C.filter(p => p.d > 0).map(p => p.d)).size
  const allGrades = useMemo(() => { const m = new Map(); C.forEach(p => { if (!m.has(p.g)) m.set(p.g, { g: p.g, rk: p.rk ?? -9, ps: [] }); m.get(p.g).ps.push(p) }); return [...m.values()].sort((a, b) => b.rk - a.rk || String(a.g).localeCompare(String(b.g))) }, [org])
  // outsourced and ungraded staff are shown apart, so they do not dwarf the graded structure
  const grades = allGrades.filter(g => g.rk > 0), ungraded = allGrades.filter(g => !(g.rk > 0))
  const svcN = C.filter(p => p.st === 'Service').length, supN = C.filter(p => p.st === 'Support').length

  const [openSec, setOpenSec] = useState(null)
  const [focusP, setFocusP] = useState(null)
  useEffect(() => setFocusP(null), [org])
  const toggleSec = k => { setOpenSec(o => o === k ? null : k); setTimeout(() => document.getElementById('sec-' + k)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60) }
  const fp = focusP ? O.byId.get(focusP) : null
  // vacant / to be hired positions: in the organogram of one function only (not the whole organisation)
  const oneFid = single && org.fids ? org.fids[fsorted[0].f] : null
  const [vac, setVac] = useState([])
  const [showTbh, setShowTbh] = useState(false)   // to be hired positions are hidden from the chart until asked for
  useEffect(() => { if (!oneFid) { setVac([]); return } api('/api/vacancies?functions=' + oneFid).then(r => setVac((units || []).length ? r.filter(v => !v.unit || units.includes(v.unit)) : r)).catch(() => setVac([])) }, [oneFid, (units || []).join('|')])
  const openVac = vac.filter(v => v.open > 0)
  const vacN = t => openVac.filter(v => !t || v.emp_type === t).reduce((a, v) => a + v.open, 0).toLocaleString('en-US')
  const vacMap = useMemo(() => {
    // where each open position sits: under the open position it reports to; if that one is filled, under the employee
    // who filled it; otherwise under its manager (the function head when the manager is not on show)
    const byId = new Map(vac.map(v => [v.id, v])), byMgr = new Map(), byParent = new Map()
    const add = (m, k, v) => m.set(k, [...(m.get(k) || []), v])
    if (!showTbh) return { byMgr, byParent }
    openVac.forEach(v => {
      let p = v, n = 0
      while (p.parent_id && byId.has(p.parent_id) && n++ < 30) {
        const pv = byId.get(p.parent_id)
        if (pv.open > 0) { add(byParent, pv.id, v); return }
        const who = [...(pv.filled_log || [])].reverse().find(x => x.code && O.byId.get(x.code))
        if (who) { add(byMgr, who.code, v); return }
        p = pv
      }
      add(byMgr, p.manager_code && O.byId.get(p.manager_code) ? p.manager_code : R1.id, v)
    })
    return { byMgr, byParent }
  }, [vac, O, R1, showTbh])
  return <section className="view on dash">
    <header className="pghead">
      <h1>{title}</h1>
      <div className="pg-side">
      {(org.excluded.length > 0 || org.resigned.length > 0) && <div className="exnote pg-side">
        {org.excluded.length > 0 && <span>{fmt(org.excluded.length)} Excluded{includeFlagged ? ' (Counted)' : ''}
          <button className="linkbtn" onClick={() => people('Excluded from Count', org.excluded, '', 'people')}>View</button>
          {setIncludeFlagged && <button className="linkbtn" onClick={() => setIncludeFlagged(!includeFlagged)}>{includeFlagged ? 'Do Not Count' : 'Count Them'}</button>}</span>}
        {org.resigned.length > 0 && <span>{fmt(org.resigned.length)} Resigned<button className="linkbtn" onClick={() => people('Resigned', org.resigned, '', 'people')}>View</button></span>}
      </div>}
      {SHOW_SUMMARY && canExport(user) && <SummaryButton sel={sel} units={units} includeFlagged={includeFlagged} />}
      </div>
    </header>
    <div className="kpis six">
      <Kpi icon="people" label={L('dash.total')} value={fmt(C.length)} sub={fsorted.length > 1 ? `${fmt(fsorted.length)} Functions` : fsorted[0]?.name} onClick={() => people('Total Employees by Grade', C)} />
      <Kpi icon="fte" label={L('dash.fte')} value={fmt(fte.length)} viz={<Ring value={pct(fte.length, C.length)} color="var(--fte)" />} onClick={() => people('FTE by Grade', fte)} />
      <Kpi icon="ftc" tone="ftc" label={L('dash.ftc')} value={fmt(ftc.length)} viz={<Ring value={pct(ftc.length, C.length)} color="var(--ftc-ink)" track="color-mix(in srgb, var(--ftc) 30%, var(--surface))" />} onClick={() => people('FTC by Grade', ftc)} />
      <Kpi icon="layers" label={L('dash.layers')} value={fmt(nLayers)} viz={<Steps n={nLayers} />} onClick={() => toggleSec('layers')} />
      <Kpi icon="managers" label={L('dash.managers')} value={fmt(mgrsAll.length)} sub={`Average Span ${fmt(Math.round(avgSpan))}`} onClick={() => people('Managers by Grade', mgrsAll, 'employees with direct reports', 'people')} />
      <Kpi icon="work" label={L('dash.svc')} value={<span className="kpi-pair"><span>{fmt(svcN)}</span><small>/</small><span>{fmt(supN)}</span></span>} onClick={() => toggleSec('work')}
        foot={<><Split parts={[{ v: svcN, color: TYPE_COL.Service, label: 'Service' }, { v: supN, color: TYPE_COL.Support, label: 'Support' }]} />
          <span className="klegend"><span><i style={{ background: TYPE_COL.Service }} />Service <b>{pcs(svcN, svcN + supN)}</b></span><span><i style={{ background: TYPE_COL.Support }} />Support <b>{pcs(supN, svcN + supN)}</b></span></span></>} />
    </div>

    <div className="seclaunch" role="group" aria-label="Dashboard sections">{SECTIONS.map(([k, l, d]) => <button key={k} type="button" aria-pressed={openSec === k} onClick={() => toggleSec(k)}>
      <i className="sl-dot" /><span><b>{L('sec.' + k)}</b></span><em className="sl-go">{openSec === k ? '–' : '+'}</em></button>)}</div>

    {openSec === 'org' && <Sec id="org" title={L('sec.org')}
      right={single && openVac.length > 0 && <button type="button" className={'btn tbh-btn' + (showTbh ? ' on' : '')} aria-pressed={showTbh} onClick={() => setShowTbh(x => !x)}>
        <span className="vac-key" />{showTbh ? 'Hide' : 'Show'} To Be Hired ({vacN('')})</button>}>
      {showTbh && openVac.length > 0 && <div className="vac-note"><span className="vac-key" /><span><b>{vacN('')}</b> vacant / to be hired positions ({vacN('FTE')} FTE, {vacN('FTC')} FTC)</span>
        <button className="linkbtn" onClick={() => setModal({ kind: 'vac' })}>View List</button></div>}
      <div className="orgchart wide">{single
        ? <Classic root={(croot && O.byId.get(croot.id)) || R1} org={O} theme={theme} largeTeam={40} onReroot={p => { let x = R1; while (x) { if (x === p) { setCroot(null); return } x = x.m >= 0 ? O.P[x.m] : null } setCroot(p) }}
            onOpenList={x => people(`${x.n}: direct reports`, x.kids.filter(O.counted), '', 'people')} vacancies={vacMap} onVacancy={v => setModal({ kind: 'vacjd', v })} top={R1} />
        : <Classic simple root={R1} focus={fp} onFocus={p => setFocusP(p ? p.id : null)} org={O} theme={theme} largeTeam={40} onReroot={() => {}} onOpenList={x => people(`${x.n}: direct reports`, x.kids.filter(O.counted), '', 'people')} />}</div>
    </Sec>}

    {openSec === 'layers' && <Layers org={org} fsorted={fsorted} single={single} theme={theme} people={people} />}

    {openSec === 'work' && <Roles org={org} fsorted={fsorted} people={people} />}



    {openSec === 'acts' && <ActsSection sel={sel} units={units} includeFlagged={includeFlagged} theme={theme} />}
    {openSec === 'opps' && <OppsSection org={org} orgSpan={orgSpan} go={go} showLine={showLine} />}

    {modal?.kind === 'vac' && <Modal wide title="Vacant / To Be Hired Positions" sub={`${fsorted[0]?.name || ''} · not counted as employees`} onClose={() => setModal(null)}>
      <div className="tw"><table><thead><tr><th>Position</th><th>Reports To</th><th>Type</th><th>Grade</th><th>Unit</th><th className="num">Open</th><th>Note</th></tr></thead>
        <tbody>{openVac.map(v => <tr key={v.id} className="click" onClick={() => setModal({ kind: 'vacjd', v, back: true })}><td><b>{v.position}</b>{v.jd && <div className="formula">View JD ›</div>}</td><td>{v.parent_position ? `${v.parent_position} (vacant)` : v.manager_name || 'Function head'}</td><td>{v.emp_type}</td><td>{v.grade || '-'}</td><td>{v.unit || '-'}</td><td className="num">{fmt(v.open)}{v.filled ? <div className="formula">{v.filled} of {v.count} filled</div> : null}</td><td className="formula">{v.note || ''}</td></tr>)}</tbody></table></div></Modal>}
    {modal?.kind === 'vacjd' && <Modal title={modal.v.position} sub={['Vacant / to be hired', modal.v.emp_type, modal.v.grade, modal.v.unit].filter(Boolean).join(' · ')} onClose={() => setModal(modal.back ? { kind: 'vac' } : null)}>
      <div className="facts">
        <div><span>Reports To</span><b>{modal.v.parent_position ? `${modal.v.parent_position} (vacant)` : modal.v.manager_name || 'Function head'}</b></div>
        <div><span>Open Positions</span><b>{fmt(modal.v.open)}{modal.v.count > 1 ? ` of ${fmt(modal.v.count)}` : ''}</b></div>
        <div><span>Type</span><b>{modal.v.emp_type}</b></div>
      </div>
      <h3 style={{ margin: '14px 0 6px', fontSize: 15 }}>Job Description</h3>
      {modal.v.jd ? <div className="jd-text">{modal.v.jd}</div> : <p className="formula">No job description written yet. The admin adds it in Admin, Vacant Positions.</p>}
      {modal.v.note && <p className="formula" style={{ marginTop: 12 }}>Note: {modal.v.note}</p>}
    </Modal>}
    {modal?.kind === 'people' && <PeopleModal title={modal.title} sub={modal.sub} people={modal.list} F={F} heads={org.headIds} onPerson={openP} initial={modal.initial} onClose={() => setModal(null)} />}
  </section>
}

const SHOW_SUMMARY = false   // the one-page summary PDF button, hidden for now (set to true to show it)
// the one-page summary PDF of what is on show (the functions, units and the excluded setting of the dashboard)
function SummaryButton({ sel, units, includeFlagged }) {
  const [busy, setBusy] = useState(false)
  const go = async () => {
    const q = new URLSearchParams({ include_flagged: includeFlagged ? 'true' : 'false' })
    if (sel?.length) q.set('functions', sel.join(','))
    ;(units || []).forEach(u => q.append('units', u))
    setBusy(true)
    try { await download('/api/export/summary?' + q, 'summary.pdf') } catch (e) { alert(e.message) } finally { setBusy(false) }
  }
  return <button type="button" className="btn pg-sum" onClick={go} disabled={busy} title="One page with the headline figures, top activity themes, functions and structure findings">{busy ? 'Preparing…' : 'Summary PDF'}</button>
}

// executive view: the activity themes (or the main categories until themes are on), each with its activities and
// employees, for all activities or only volume based / non volume based ones; every bar opens its activities
const MAXT = 10
const share = (n, t) => !n || !t ? '-' : n / t < 0.01 ? '<1%' : Math.round(n / t * 100) + '%'
function ActsSection({ sel, units, includeFlagged, theme }) {
  const [vol, setVol] = useState('')
  const [et, setEt] = useState('')        // FTE / FTC filter
  const [open, setOpen] = useState(null)
  const [all, setAll] = useState(false)   // the pop-up with every theme (or category)
  const fq = `functions=${(sel || []).join(',')}&include_flagged=${includeFlagged}&emp_type=${et}&groups=true&limit=0${unitQS()}`
  const [d, dBusy] = useLive(() => Promise.all(['', '&volume=true', '&novolume=true'].map(x => api('/api/dashboard/activities?' + fq + x)))
    .then(([all, w, wo]) => ({ all, w, wo })).catch(() => ({ error: true })), [fq])
  const cur = !d || d.error ? null : vol === 'with' ? d.w : vol === 'without' ? d.wo : d.all
  const byTheme = !!cur && prefs.showThemes && (d.all.groups?.themes || []).some(t => t.name !== 'No Theme')
  const allRows = !cur ? [] : (byTheme ? cur.groups.themes : cur.groups.categories.filter(c => c.name !== 'Not categorised'))
  const rows = allRows.slice(0, MAXT)
  const nVol = d && !d.error ? d.w.total : 0, nAll = d && !d.error ? d.all.total : 0, nNo = nAll - nVol
  const vf = { ...(vol === 'with' ? { volume: 'true' } : vol === 'without' ? { novolume: 'true' } : {}), ...(et ? { emp_type: et } : {}) }
  const seg = <span className="dsec-right"><TypeFilter value={et} onChange={setEt} /><span className="seg sm" role="group">{[['', 'All Activities'], ['with', L('ins.volbased')], ['without', L('ins.nonvol')]].map(([k, l]) =>
    <button key={k} type="button" aria-pressed={vol === k} onClick={() => setVol(k)}>{l}</button>)}</span></span>
  const what = byTheme ? 'Themes' : 'Categories'
  return <Sec id="acts" title={L('dash.actshead')} right={seg} busy={dBusy && !!d}>
    {!d ? <div className="loading">Loading activities…</div> : d.error ? <div className="empty">Could not load the activities.</div> : !nAll ? <div className="empty">No activities recorded yet for this selection.</div> : <>
      <div className="ex-top" style={{ gridTemplateColumns: `repeat(3, minmax(120px, 1fr))${cur.groups.per_day > 0 ? ' minmax(230px, 1.5fr)' : ''}` }}>
        <div className="ex-fig"><span>{L('ins.employees')}</span><b>{fmt(cur.groups.staff)}</b></div>
        <div className="ex-fig"><span>{L('ins.activities')}</span><b>{fmt(cur.total)}</b></div>
        <div className="ex-fig"><span>{byTheme ? L('ins.themes') : L('ins.categories')}</span><b>{fmt(byTheme ? cur.groups.themes.filter(t => t.name !== 'No Theme').length : cur.groups.categories.filter(c => c.name !== 'Not categorised').length)}</b></div>
        {cur.groups.per_day > 0 && <div className="ex-fig vol"><span>{L('ins.volume')}</span><VolPair total={cur.groups.per_day} file={cur.groups.file_per_day || 0} /></div>}
      </div>
      <div className="panel ex-panel">
        {!rows.length ? <p className="formula">No activities in this selection.</p> : <ExecRows rows={rows} showVol={cur.groups.per_day > 0} onPick={r => setOpen(r.name)} byTheme={byTheme} multi={(cur.groups.functions || []).length > 1} />}
        {allRows.length > MAXT && <div className="pfoot"><span className="formula">The {MAXT} largest of {fmt(allRows.length)} {what.toLowerCase()}.</span>
          <button type="button" className="linkbtn" onClick={() => setAll(true)}>View All {fmt(allRows.length)} {what} ›</button></div>}
      </div>
      {all && <Modal wide title={byTheme ? L('ins.themepanel') : 'Activity Categories'} sub={[`${fmt(allRows.length)} ${what.toLowerCase()}`, et, vol === 'with' ? L('ins.volbased') : vol === 'without' ? L('ins.nonvol') : ''].filter(Boolean).join(' · ')} onClose={() => setAll(false)}>
        <ExecRows rows={allRows} showVol={cur.groups.per_day > 0} onPick={r => { setAll(false); setOpen(r.name) }} byTheme={byTheme} multi={(cur.groups.functions || []).length > 1} /></Modal>}
      {open && <Modal wide title={open} sub={[et, vol === 'with' ? L('ins.volbased') : vol === 'without' ? L('ins.nonvol') : ''].filter(Boolean).join(' · ') || undefined} onClose={() => setOpen(null)}>
        <ThemeCatBrowser key={open + vol + et} filter={vf} sel={sel} includeFlagged={includeFlagged} initTheme={byTheme ? open : null} initCat={byTheme ? '*' : open} filterBar />
      </Modal>}
    </>}
  </Sec>
}

// one row per theme: activities, employees and average daily volume as bars on their own scales; the headings sort
function ExecRows({ rows, showVol, onPick, byTheme, multi }) {
  const [by, setBy] = useState('staff')
  const list = [...rows].sort((a, b) => (b[by] || 0) - (a[by] || 0) || b.staff - a.staff || b.activities - a.activities)
  const mx = k => Math.max(1, ...rows.map(r => r[k] || 0))
  const ma = mx('activities'), ms = mx('staff'), mv = mx('per_day')
  const tot = rows.reduce((t, r) => t + (r.per_day || 0), 0)
  const H = ({ k, children }) => <button type="button" className={'ex-h' + (by === k ? ' on' : '')} onClick={() => setBy(k)}>{children}{by === k ? ' ▾' : ''}</button>
  return <div className={'ex-rows' + (showVol ? '' : ' novol') + (multi ? ' multi' : '')}>
    <div className="ex-row ex-head"><span className="ex-rank">#</span><span>{byTheme ? 'Activity Theme' : 'Activity Category'}</span>
      {multi && <H k="functions">Functions</H>}<H k="staff">Employees (FTE / FTC)</H><H k="activities">Activities</H>{showVol && <H k="per_day">Avg Daily Volume</H>}<span /></div>
    {list.map((r, i) => <button type="button" key={r.name} className="ex-row" onClick={() => onPick(r)}>
      <span className="ex-rank">{i + 1}</span>
      <span className="ex-name">{byTheme && <i style={{ background: themeColor(r.name) }} />}<b>{r.name}</b></span>
      {multi && <span className="ex-fn"><b>{fmt(r.functions)}</b></span>}
      <span className="ex-cell"><span className="ex-bar" title={`FTE ${r.fte_staff || 0} · FTC ${r.ftc_staff || 0}`}><i style={{ width: (r.fte_staff || 0) / ms * 100 + '%', background: 'var(--fte)' }} /><i style={{ width: (r.ftc_staff || 0) / ms * 100 + '%', background: 'var(--ftc)' }} /></span>
        <span className="ex-snums"><b>{fmt(r.staff)}</b><small>{r.fte_staff || 0} / {r.ftc_staff || 0}</small></span></span>
      <span className="ex-cell"><span className="ex-bar"><i style={{ width: r.activities / ma * 100 + '%', background: 'var(--x-act)' }} /></span><b>{fmt(r.activities)}</b></span>
      {showVol && <span className="ex-cell">{r.per_day > 0 ? <><span className="ex-bar">
        <i className="ex-vol" style={{ width: (r.per_day - (r.file_per_day || 0)) / mv * 100 + '%' }} />{r.file_per_day > 0 && <i className="ex-vfile" style={{ width: r.file_per_day / mv * 100 + '%' }} />}</span>
        <span className="ex-vnums">{r.per_day - (r.file_per_day || 0) > 0 && <span title={L('vol.txn')}><i className="t" />{vfmt(r.per_day - (r.file_per_day || 0))}</span>}
          {r.file_per_day > 0 && <span title={L('vol.file')}><i className="f" />{vfmt(r.file_per_day)}</span>}</span></> : <span className="ex-none">No volume</span>}</span>}
      <span className="ex-go">›</span></button>)}
  </div>
}

function OppsSection({ org, orgSpan, go, showLine }) {
  const [et, setEt] = useState('')
  const O = et && orgSpan ? orgSpan(et) : org
  return <Sec id="opps" title={L('dash.oppshead')} right={<TypeFilter value={et} onChange={setEt} />}>
    <Opportunities org={O} et={et} go={go} showLine={showLine} embedded />
  </Sec>
}

// ------------------------------------------------------------------ layers and spans
function Layers({ org, fsorted, single, theme, people }) {
  const { ROOT, F } = org
  const [et, setEt] = useState('')     // the function-wise layer table
  const [cet, setCet] = useState('')   // the span of control chart, filtered on its own
  const C = org.C.filter(byType(et))
  // span of control by type of direct report: with FTE or FTC selected, a manager's span counts only
  // their FTE or FTC direct reports, so it shows whether wide spans come from contract staff
  const reports = (m, t) => m.kids.filter(k => org.counted(k) && byType(t)(k)).length
  const sp = m => reports(m, et)
  const allM = org.MGR.filter(m => m !== ROOT && !m.ctx)
  const mgrs = allM.filter(m => sp(m) > 0)
  const avg = (ms, t) => { const x = ms.filter(m => reports(m, t) > 0); return x.length ? x.reduce((a, m) => a + reports(m, t), 0) / x.length : 0 }
  const fmg = f => mgrs.filter(m => m.f === f)
  const csp = m => reports(m, cet), cm = allM.filter(m => csp(m) > 0)
  const fspan = f => { const ms = fmg(f); return ms.length ? ms.reduce((t, m) => t + sp(m), 0) / ms.length : 0 }
  const wide = allM.filter(m => m.nk > 15), wideK = wide.reduce((a, m) => a + m.nk, 0), wideC = wide.reduce((a, m) => a + reports(m, 'FTC'), 0)
  const wideFteOk = wide.filter(m => reports(m, 'FTE') <= 15).length
  const depths = C.filter(p => p.d >= 0).map(p => p.d)
  const lo = Math.min(...depths, 1), hi = Math.max(...depths, 1)
  const LYR = []; for (let l = lo; l <= hi; l++) LYR.push(l)
  const cell = (f, l) => C.filter(p => p.f === f && p.d === l)
  const bins = [['1', 1, 1], ['2', 2, 2], ['3–5', 3, 5], ['6–10', 6, 10], ['11–15', 11, 15], ['16–30', 16, 30], ['31+', 31, 1e9]]
  const lname = l => l === 0 ? `Layer 0 (${short(ROOT.n, 18)})` : `Layer ${l}`
  return <Sec id="layers" title={L('dash.layerhead')}
    right={<TypeFilter value={et} onChange={setEt} />}>
    <div className="panel" style={{ padding: '10px 14px' }}><div className="tw"><table className="heat">
      <thead><tr><th>Function</th>{LYR.map(l => <th key={l} className="num">{l === 0 ? 'L0' : 'L' + l}</th>)}<th className="num">Employees</th><th className="num">Layers</th><th className="num">{et ? `${et}'s Managers` : 'Managers'}</th><th className="num">{et ? `${et}'s Avg Span` : 'Avg Span'}</th></tr></thead>
      <tbody>{fsorted.length > 1 && <tr className="tot top"><td>Total</td>{LYR.map(l => { const r = C.filter(p => p.d === l); return <td key={l} className="num">{r.length ? <button className="cellbtn" onClick={() => people(lname(l), r)}>{fmt(r.length)}</button> : ''}</td> })}
          <td className="num">{fmt(C.length)}</td><td className="num">{fmt(LYR.filter(l => l > 0 && C.some(p => p.d === l)).length)}</td><td className="num">{fmt(mgrs.length)}</td><td className="num">{fmt(Math.round(mgrs.length ? mgrs.reduce((t, m) => t + sp(m), 0) / mgrs.length : 0))}</td></tr>}
        {fsorted.map(s => { const row = LYR.map(l => cell(s.f, l)); const mx = Math.max(1, ...row.map(r => r.length)); const used = row.filter((r, i) => r.length && LYR[i] > 0).length;   // layer 0 (the top) is not counted as a layer
        const lo = row.findIndex(r => r.length), hi = row.length - 1 - [...row].reverse().findIndex(r => r.length)
        return <tr key={s.f}><td><span className="dot" style={{ background: org.FCOL[s.f] }} />{s.name}</td>
          {row.map((r, i) => <td key={i} className={'num hc' + (r.length / mx > 0.6 ? ' dk' : '')} style={{ '--h': r.length ? 0.12 + 0.78 * r.length / mx : 0 }}>
            {r.length ? <button className="cellbtn" onClick={() => people(`${s.name}: ${lname(LYR[i])}`, r)}>{fmt(r.length)}</button> : i > lo && i < hi ? <span className="dash">-</span> : ''}</td>)}
          <td className="num"><b>{fmt(C.filter(p => p.f === s.f).length)}</b></td><td className="num"><b>{fmt(used)}</b></td><td className="num">{fmt(fmg(s.f).length)}</td><td className="num">{fmt(Math.round(fspan(s.f)))}</td></tr> })}
      </tbody></table></div></div>
    <div className="grid" style={{ marginTop: 14 }}>
      <div className="panel"><div className="rhead"><h3>{L('dash.span')}{cet ? ` · ${cet} Direct Reports` : ''}</h3><TypeFilter value={cet} onChange={setCet} /></div>
        <ChartBox deps={[org, theme, cet]} config={() => ({ type: 'bar', plugins: [barValues], data: { labels: bins.map(b => b[0]), datasets: [{ data: bins.map(b => cm.filter(m => csp(m) >= b[1] && csp(m) <= b[2]).length), backgroundColor: bins.map((b, i) => i < 2 ? css('--amber') : i > 4 ? css('--coral') : css('--teal')), borderRadius: 5 }] },
          options: { onClick: (e, el) => { if (el.length) { const b = bins[el[0].index]; people(`Managers with ${b[0]} ${cet ? cet + ' ' : ''}direct reports`, cm.filter(m => csp(m) >= b[1] && csp(m) <= b[2]), '', 'people') } },
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => c.raw + ' managers' } } }, scales: { x: { title: { display: true, text: 'Direct Reports' }, grid: { display: false } }, y: { grace: '12%', title: { display: true, text: 'Managers' } } } } })} /></div>
    </div>
  </Sec>
}

// ------------------------------------------------------------------ service and support (the employee's type of work)
const ROLE_LABEL = { Service: 'Service Employees', Support: 'Support Employees', '': 'Not Yet Marked' }
function Roles({ org, fsorted, people }) {
  const [et, setEt] = useState('')
  // only employees marked Service or Support; those not yet marked are left out, so the two make 100%
  const C = org.C.filter(byType(et)).filter(p => TYPES.includes(p.st || ''))
  const groups = TYPES.map(t => ({ t, ps: C.filter(p => (p.st || '') === t) }))
  const n = C.length
  const scope = et === 'FTE' ? ' (FTE)' : et === 'FTC' ? ' (FTC)' : ''
  return <Sec id="work" title={L('sec.work')}
    right={<TypeFilter value={et} onChange={setEt} />}>
    <div className="panel roles">
      <div className="split big" role="img" aria-label="Service and support employees">{groups.map(g => g.ps.length ? <i key={g.t} style={{ width: g.ps.length / n * 100 + '%', background: TYPE_COL[g.t] }} title={`${ROLE_LABEL[g.t]}: ${g.ps.length}`} /> : null)}</div>
      <div className="rolefig r2">{groups.map(g => <button key={g.t} className="rf" style={{ '--tc': TYPE_COL[g.t] }} disabled={!g.ps.length}
        onClick={() => people(`${ROLE_LABEL[g.t]}${scope} by grade`, g.ps)}>
        <span className="rl"><i />{ROLE_LABEL[g.t]}{scope}</span><b>{fmt(g.ps.length)}</b><span className="rp">{pcs(g.ps.length, n)} of marked {et ? et + ' ' : ''}employees</span></button>)}</div>
    </div>
    {fsorted.length > 1 && <div className="panel" style={{ marginTop: 14 }}>
      <div className="rhead"><h3>By Function</h3><span className="legend">{TYPES.map(t => <span key={t}><i style={{ background: TYPE_COL[t] }} />{ROLE_LABEL[t]}</span>)}</span></div>
      <div className="tw"><table><thead><tr><th>Function</th><th className="num">Employees</th><th className="num">Service</th><th className="num">Support</th><th style={{ width: '30%' }}></th></tr></thead>
        <tbody><tr className="tot top"><td>Total</td><td className="num">{fmt(C.length)}</td>{TYPES.map(t => { const x = C.filter(p => (p.st || '') === t); return <td key={t} className="num">{x.length ? <button className="cellbtn" onClick={() => people(`${ROLE_LABEL[t]}${scope}`, x)}>{fmt(x.length)}</button> : '-'}</td> })}
          <td><div className="bar">{TYPES.map(t => <i key={t} style={{ width: pct(C.filter(p => (p.st || '') === t).length, C.length) + '%', background: TYPE_COL[t] }} />)}</div></td></tr>
        {fsorted.map(s => { const ps = C.filter(p => p.f === s.f)
          return <tr key={s.f}><td><span className="dot" style={{ background: org.FCOL[s.f] }} />{s.name}</td><td className="num"><b>{fmt(ps.length)}</b></td>
            {TYPES.map(t => { const x = ps.filter(p => (p.st || '') === t); return <td key={t} className="num">{x.length ? <button className="cellbtn" onClick={() => people(`${s.name}: ${ROLE_LABEL[t]}${scope}`, x)}>{fmt(x.length)}</button> : '-'}</td> })}
            <td><div className="bar">{TYPES.map(t => <i key={t} style={{ width: pct(ps.filter(p => (p.st || '') === t).length, ps.length) + '%', background: TYPE_COL[t] }} />)}</div></td></tr> })}</tbody></table></div></div>}
  </Sec>
}

// ------------------------------------------------------------------ activities
