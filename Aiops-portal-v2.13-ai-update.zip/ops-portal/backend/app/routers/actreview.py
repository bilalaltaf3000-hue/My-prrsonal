"""Admin: review the activities in Excel and bring the changes back, with a preview first and an undo.

Two kinds of file are read:
- The review sheet downloaded here (version 2.12 on, with a Delete activity column): every activity has its Activity ID,
  so every column can be edited - the employee's unit and service / support, product, process, channel, description,
  category, theme, frequency, volume, volume type, peaks, nature of work, processing time and automation - an activity
  can be deleted (Delete activity = Yes), and a row without an Activity ID adds a new activity for that employee.
- Any other activity sheet (the Excel export, an older review sheet, a reviewer's own copy without IDs): rows are
  matched to the portal's activities by employee and activity details, and the description, category, theme and
  volume columns (or the "Revised ..." columns) bring the changes. Nothing is added from these files."""
import io
from datetime import datetime
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..importer import code_text
from ..security import audit, get_setting, require_admin, set_setting
from ..logic import (HANDLING, NATURE_LEGACY, SERVICE_TYPES, VOL_FILE, freq_names, function_heads, nature_label, nature_value,
                     vol_labels, vol_type_value)
from .catreview import NO_THEME, theme_list, theme_map, theme_of

router = APIRouter(prefix="/api/admin/activity-review")

DELETE_HEAD = "Delete activity"
# the review sheet: (heading, width, editable)
def _head():
    return [("Activity ID", 11, False), ("Function", 26, False), ("Employee code", 13, False), ("Employee name", 26, False),
            ("Unit", 22, True), ("Service / support", 12, True), ("Product", 18, True), ("Process name", 22, True), ("Channel", 14, True),
            ("Activity description", 64, True), ("Activity category", 32, True), ("Activity theme", 28, True), ("Frequency", 12, True),
            ("Avg volume (per frequency)", 13, True), ("Volume type", 16, True), ("Peak volume start of month (avg per day)", 14, True),
            ("Peak volume end of month (avg per day)", 14, True), (nature_label(), 22, True), ("Employee processing time (min)", 13, True),
            ("Automation opportunity", 12, True), (DELETE_HEAD, 11, True)]


def _norm(v) -> str:
    return " ".join(str(v if v is not None else "").split())


def _safe(s):
    return "".join(ch if ch.isalnum() else "_" for ch in s)[:30]


@router.get("/download")
def download(functions: str = Query(""), user=Depends(require_admin), db: Session = Depends(get_db)):
    """Every activity of the chosen functions (all when none), one row each, to edit in Excel."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
    fids = {int(x) for x in functions.split(",") if x.strip().isdigit()}
    fns = {f.id: f for f in db.query(models.Function)}
    fnames = {k: f.name for k, f in fns.items()}
    emps = {e.code: e for e in db.query(models.Employee) if (not fids or e.function_id in fids) and not e.resigned}
    heads = set()
    for f in ({e.function_id for e in emps.values()} - {None}):
        heads |= function_heads(db, f)
    tm = theme_map(db)
    vf, vt = vol_labels()
    rows = []
    for w in db.query(models.WorkItem).order_by(models.WorkItem.employee_code, models.WorkItem.sort, models.WorkItem.id):
        e = emps.get(w.employee_code)
        if not e:
            continue
        rows.append([w.id, fnames.get(e.function_id, ""), e.code, e.name, "All units" if e.code in heads else (e.unit_name or ""),
                     e.service_role or "", w.product or "", w.process or "", w.channel or "", w.description or "", w.category or "",
                     theme_of(w.category, tm) if (w.category or "").strip() else "", w.frequency or "", w.volume,
                     vf if w.volume_type == VOL_FILE else (vt if w.volume is not None else ""), w.peak_som, w.peak_eom,
                     w.handling or "", w.minutes, w.automation or "", ""])
    rows.sort(key=lambda r: (r[1], r[3], r[2]))
    head = _head()
    wb = Workbook()
    ws = wb.active
    ws.title = "Activity review"
    ws.append([h for h, _, _ in head])
    for r in rows:
        ws.append(r)
    col = {h: get_column_letter(i) for i, (h, _, _) in enumerate(head, 1)}
    for i, (h, wd, ed) in enumerate(head, 1):
        c = ws.cell(1, i)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=("B23A3A" if h == DELETE_HEAD else "00796B") if ed else "4A6561")
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.column_dimensions[c.column_letter].width = wd
    for row in ws.iter_rows(min_row=2, min_col=10, max_col=10):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "E2"
    ws.auto_filter.ref = ws.dimensions
    last = len(rows) + 300   # room for new rows
    themes = theme_list(db)
    th = wb.create_sheet("Themes")
    th.append(["Activity themes (type one of these, or a new name to create a theme)"])
    th["A1"].font = Font(bold=True)
    for t in themes:
        th.append([t])
    th.column_dimensions["A"].width = 60
    lists = [(col["Frequency"], '"' + ",".join(freq_names())[:250] + '"'), (col["Volume type"], '"' + ",".join(vol_labels()) + '"'),
             (col[nature_label()], '"' + ",".join(HANDLING)[:250] + '"'), (col["Automation opportunity"], '"Yes,No"'),
             (col["Service / support"], '"Service,Support"'), (col[DELETE_HEAD], '"Yes"')]
    if themes:
        lists.append((col["Activity theme"], f"=Themes!$A$2:$A${len(themes) + 1}"))
    for c, formula in lists:
        dv = DataValidation(type="list", formula1=formula, allow_blank=True, showErrorMessage=False)
        ws.add_data_validation(dv)
        dv.add(f"{c}2:{c}{last}")
    nb = wb.create_sheet("How to use")
    for line in ["Edit the green columns. A blank cell leaves the portal's value as it is.",
                 "Unit and Service / support belong to the employee: use the same value on all of the employee's rows (the value used most is applied).",
                 "The theme belongs to the category: every activity of a category gets the same theme (the theme used most is applied).",
                 f"Volume type: {vf} (for example the rows of an uploaded file) or {vt}.",
                 "To delete an activity, write Yes in the red Delete activity column.",
                 "To add an activity, add a row with the Employee code and the details, and leave the Activity ID empty.",
                 "Do not change the Activity ID. Sorting and filtering the rows is fine.",
                 "Upload the file in Admin, Activity Categories, Review in Excel. You see a preview before anything is changed, and Undo Last Upload puts everything back."]:
        nb.append([line])
    nb.column_dimensions["A"].width = 130
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    tag = "all_functions" if not fids else (_safe(fnames.get(next(iter(fids)), "function")) if len(fids) == 1 else f"{len(fids)}_functions")
    name = f"activity_review_{tag}_{datetime.now():%Y%m%d_%H%M}.xlsx"
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{name}"'})


def _read(content: bytes):
    """The sheet with the activities: its header (lower case) and its rows."""
    from openpyxl import load_workbook
    try:
        wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    except Exception:
        raise HTTPException(400, "This is not an Excel file (.xlsx).")
    order = sorted(wb.sheetnames, key=lambda n: (n.lower() not in ("activity review", "employee activities"), n))
    for name in order:
        ws = wb[name]
        it = ws.iter_rows(values_only=True)
        head = [str(h or "").strip().rstrip("*").strip().lower() for h in next(it, [])]
        if "employee code" in head and any(h in head for h in ("activity category", "category")):
            return name, head, [r for r in it if any(v not in (None, "") for v in r)]
    raise HTTPException(400, "No sheet with an Employee code and an Activity category column was found.")


def _col(head: List[str], *names) -> Optional[int]:
    for n in names:
        if n in head:
            return head.index(n)
    return None


def _num(v):
    try:
        return round(float(str(v).replace(",", "").strip()), 2) if v not in (None, "") else None
    except Exception:
        return None


TEXT_FIELDS = {"product": 200, "process": 250, "channel": 200}
NUM_FIELDS = ("volume", "peak_som", "peak_eom", "minutes")
# the activity fields a full review sheet can change, with the words used in the preview
FIELD_WORDS = {"description": "descriptions", "category": "categories", "frequency": "frequencies", "volume": "volumes",
               "handling": "natures", "product": "products", "process": "processes", "channel": "channels",
               "volume_type": "volume types", "peak_som": "peaks (start of month)", "peak_eom": "peaks (end of month)",
               "minutes": "processing times", "automation": "automation"}


def _plan(db: Session, content: bytes):
    sheet, head, rows = _read(content)
    nh = nature_label().lower()
    ci = {"id": _col(head, "activity id"), "code": _col(head, "employee code"),
          "desc": _col(head, "activity description", "description"), "cat": _col(head, "activity category", "category"),
          "theme": _col(head, "activity theme", "theme", "activity themes", "themes"),
          "product": _col(head, "product", "products"), "process": _col(head, "process name", "process"),
          "channel": _col(head, "channel"), "freq": _col(head, "frequency"),
          "vol": _col(head, "avg volume (per frequency)", "avg volume", "average volume", "volume"),
          "min": _col(head, "employee processing time (min)", "staff processing time (min)", "processing time (min)"),
          "unit": _col(head, "unit"), "svc": _col(head, "service / support", "employee: service / support", "service or support"),
          "vtype": _col(head, "volume type"), "som": _col(head, "peak volume start of month (avg per day)"),
          "eom": _col(head, "peak volume end of month (avg per day)"), "nat": _col(head, nh, "nature of work", "activity handling"),
          "auto": _col(head, "automation opportunity", "automation"), "delete": _col(head, DELETE_HEAD.lower(), "delete"),
          # "Revised ..." columns: the new values, while the original columns stay as exported (to find each activity)
          "rdesc": _col(head, "revised description", "revised activity description"),
          "rcat": _col(head, "revised category", "revised activity category"),
          "rtheme": _col(head, "revised theme", "revised activity theme"),
          "rfreq": _col(head, "revised frequency"),
          "rvol": _col(head, "revised volume", "revised avg volume", "revised average volume", "revised avg volume (per frequency)"),
          "rnat": _col(head, "revised nature", "revised nature of work", "revised activity handling", "revised handling",
                       "revised " + nh)}
    # the full review sheet (downloaded here from version 2.12): every column is a value to apply, rows can be
    # deleted and added. Other files: only description, category, theme, volume and the Revised columns.
    full = ci["delete"] is not None and ci["id"] is not None
    get = lambda r, k: r[ci[k]] if ci[k] is not None and ci[k] < len(r) else None
    items = {w.id: w for w in db.query(models.WorkItem)}
    emps = {e.code: e for e in db.query(models.Employee)}
    per_emp: Dict[str, List[models.WorkItem]] = {}
    for w in sorted(items.values(), key=lambda w: w.id):
        per_emp.setdefault(w.employee_code, []).append(w)
    num = _num

    # what identifies an activity besides the columns being edited: product, process, channel, frequency, volume, time
    def sig_row(r):
        return tuple(x for x in ([_norm(get(r, f)).lower() for f in ("product", "process", "channel", "freq") if ci[f] is not None]
                                 + [num(get(r, f)) for f in ("vol", "min") if ci[f] is not None]))
    def loose_row(r):
        return tuple(_norm(get(r, f)).lower() for f in ("product", "process", "channel", "freq") if ci[f] is not None)
    def loose_item(w):
        return tuple(_norm(getattr(w, a)).lower() for f, a in (("product", "product"), ("process", "process"), ("channel", "channel"), ("freq", "frequency")) if ci[f] is not None)
    def sig_item(w):
        return tuple(x for x in ([_norm(getattr(w, a)).lower() for f, a in (("product", "product"), ("process", "process"), ("channel", "channel"), ("freq", "frequency")) if ci[f] is not None]
                                 + [num(getattr(w, a)) for f, a in (("vol", "volume"), ("min", "minutes")) if ci[f] is not None]))
    def like(r, w):
        from difflib import SequenceMatcher
        a = (_norm(get(r, "desc")) + " | " + _norm(get(r, "cat"))).lower()
        b = (_norm(w.description) + " | " + _norm(w.category)).lower()
        return SequenceMatcher(None, a, b).ratio()
    is_yes = lambda v: _norm(v).lower() in ("yes", "y", "delete", "x", "true", "1")

    unmatched, matched, used, adds_raw, dels = [], [], set(), [], []
    stale_ids = 0
    by_code: Dict[str, list] = {}
    for n, r in enumerate(rows, 2):
        code = code_text(get(r, "code"))
        rid = get(r, "id")
        if rid not in (None, ""):
            try:
                w = items.get(int(float(rid)))
            except Exception:
                w = None
            if w is None or (code and w.employee_code != code) or w.id in used:
                if full and code:   # an out-of-date or shifted Activity ID: find the activity by its details instead
                    by_code.setdefault(code, []).append((n, r))
                    stale_ids += 1
                else:
                    unmatched.append(f"Row {n}: activity {rid} not found for employee {code}.")
                continue
            used.add(w.id)
            if full and is_yes(get(r, "delete")):
                dels.append(w)
            else:
                matched.append((n, r, w))
        elif full:
            if is_yes(get(r, "delete")):
                continue
            e = emps.get(code)
            if not code:
                unmatched.append(f"Row {n}: no employee code; row left out.")
            elif not e or e.resigned:
                unmatched.append(f"Row {n}: employee {code} {'has resigned' if e else 'is not in the portal'}; new activity not added.")
            elif not (_norm(get(r, "rdesc") or get(r, "desc")) or _norm(get(r, "rcat") or get(r, "cat")) or _norm(get(r, "process"))):
                unmatched.append(f"Row {n}: employee {code}: a new row needs at least a description, category or process; not added.")
            else:
                adds_raw.append((n, r, code))
        else:
            by_code.setdefault(code, []).append((n, r))
    by_content = 0
    by_details = 0   # rows whose Activity ID did not match, found by employee and details
    for code, lst in by_code.items():
        its = per_emp.get(code, [])
        if not its:
            for n, _ in lst:
                unmatched.append(f"Row {n}: employee {code} has no activities in the portal.")
            continue
        # every row against every activity of the employee with the same details (product, process, channel,
        # frequency, volume, time; or, if the volume or time was changed, the first four). Pairs are taken best
        # first: same details, then the closest original description and category, then the same position. An
        # activity whose description is unchanged in the file is therefore always found, even among look-alikes.
        pairs = []
        for k, (n, r) in enumerate(lst):
            sr, lr = sig_row(r), loose_row(r)
            for p_, w in enumerate(its):
                if w.id in used:
                    continue
                tier = 0 if sig_item(w) == sr else (1 if loose_item(w) == lr else None)
                if tier is None:
                    continue
                pairs.append((tier, -round(like(r, w), 4), 0 if p_ == k else 1, k, w.id, n, r, w))
        pairs.sort(key=lambda x: x[:5])
        done_rows = set()
        for tier, _, samepos, k, wid, n, r, w in pairs:
            if k in done_rows or wid in used:
                continue
            done_rows.add(k)
            used.add(wid)
            if full and is_yes(get(r, "delete")):
                dels.append(w)
            else:
                matched.append((n, r, w))
            by_content += samepos
            by_details += 1 if (full and get(r, "id") not in (None, "")) else 0
        for k, (n, r) in enumerate(lst):
            if k not in done_rows:
                rid = get(r, "id")
                unmatched.append(f"Row {n}: activity {rid} not found for employee {code}, and no activity of theirs with the same product, process, channel and frequency." if rid not in (None, "")
                                 else f"Row {n}: employee {code}: no activity in the portal with the same product, process, channel and frequency.")
    codes_in_file = {w.employee_code for _, _, w in matched} | {w.employee_code for w in dels} | {c for _, _, c in adds_raw}
    missing = [w for w in items.values() if w.employee_code in codes_in_file and w.id not in used]
    tm = theme_map(db)
    fq = {f.lower(): f for f in freq_names()}
    hd = {h.lower(): h for h in HANDLING}
    problems: List[str] = []
    pick = lambda *ks: next((k for k in ks if ci[k] is not None), None)   # the first of these columns in the file

    def values(n, r):
        """The values a row brings, by activity field ({} for what it leaves as it is)."""
        out = {}
        dk, ck = pick("rdesc", "desc"), pick("rcat", "cat")
        if dk and _norm(get(r, dk)):
            out["description"] = str(get(r, dk)).strip()[:5000]   # line breaks typed in Excel are kept
        if ck and _norm(get(r, ck)):
            out["category"] = _norm(get(r, ck))[:200]
        # volume: the revised column, or the volume column itself (for example two activities merged into one)
        vk = pick("rvol", "vol")
        if vk and get(r, vk) not in (None, ""):
            nv = num(get(r, vk))
            if nv is None or nv < 0:
                problems.append(f"Row {n}: volume '{get(r, vk)}' is not a number; left as it is.")
            else:
                out["volume"] = nv
        fk = pick("rfreq", "freq") if full else pick("rfreq")
        if fk and _norm(get(r, fk)):
            v = _norm(get(r, fk))
            if v.lower() in fq:
                out["frequency"] = fq[v.lower()]
            else:
                problems.append(f"Row {n}: frequency '{v}' is not one of {', '.join(fq.values())}; left as it is.")
        nk = pick("rnat", "nat") if full else pick("rnat")
        if nk and _norm(get(r, nk)):
            v = _norm(get(r, nk))
            v2 = nature_value(v if v.lower() in hd else NATURE_LEGACY.get(v.lower(), v))
            if v2.lower() in hd:
                out["handling"] = hd[v2.lower()]
            else:
                problems.append(f"Row {n}: {nature_label()} '{v}' is not one of {', '.join(HANDLING)}; left as it is.")
        if not full:
            return out
        from .staffadmin import clean_products
        for k, ln in TEXT_FIELDS.items():
            if _norm(get(r, k)):
                out[k] = clean_products(get(r, k)) if k == "product" else _norm(get(r, k))[:ln]
        for k, f in (("som", "peak_som"), ("eom", "peak_eom"), ("min", "minutes")):
            if get(r, k) not in (None, ""):
                nv = num(get(r, k))
                if nv is None or nv < 0:
                    problems.append(f"Row {n}: {f.replace('_', ' ')} '{get(r, k)}' is not a number; left as it is.")
                else:
                    out[f] = nv
        if _norm(get(r, "vtype")):
            v = vol_type_value(get(r, "vtype"))
            if v is None:
                problems.append(f"Row {n}: volume type '{_norm(get(r, 'vtype'))}' is not {' or '.join(vol_labels())}; left as it is.")
            else:
                out["volume_type"] = v
        if _norm(get(r, "auto")):
            v = _norm(get(r, "auto")).capitalize()
            if v in ("Yes", "No"):
                out["automation"] = v
            else:
                problems.append(f"Row {n}: automation '{_norm(get(r, 'auto'))}' is not Yes or No; left as it is.")
        return out

    def same(f, old, new):
        if f in NUM_FIELDS:
            return num(old) == new
        if f in ("description", "category"):
            return _norm(old) == _norm(new)
        return _norm(old).lower() == _norm(new).lower()

    chg: Dict[str, list] = {f: [] for f in FIELD_WORDS}
    rowvals = []
    for n, r, w in matched:
        vals = values(n, r)
        rowvals.append((n, r, w.employee_code, vals.get("category") or _norm(w.category)))
        for f, v in vals.items():
            if not same(f, getattr(w, f), v):
                chg[f].append((w, v))
    adds = []
    for n, r, code in adds_raw:
        vals = values(n, r)
        rowvals.append((n, r, code, vals.get("category", "")))
        adds.append((n, code, vals))
    # employee fields (full sheet): the value used most on the employee's rows
    emp_set: Dict[str, Dict[str, str]] = {"unit": {}, "role": {}}
    emp_conf = []
    if full:
        heads = set()
        for f in ({emps[c].function_id for c in codes_in_file if c in emps} - {None}):
            heads |= function_heads(db, f)
        for key, colk in (("unit", "unit"), ("role", "svc")):
            votes: Dict[str, Dict[str, int]] = {}
            for n, r, code, _ in rowvals:
                v = _norm(get(r, colk))
                if not v:
                    continue
                if key == "role":
                    v = next((t for t in SERVICE_TYPES if t.lower() == v.lower()), None)
                    if not v:
                        problems.append(f"Row {n}: service / support '{_norm(get(r, colk))}' is not Service or Support; left as it is.")
                        continue
                elif v.lower() == "all units" or code in heads:
                    continue
                votes.setdefault(code, {}).setdefault(v, 0)
                votes[code][v] += 1
            for code, vs in votes.items():
                e = emps.get(code)
                if not e:
                    continue
                best = max(vs.items(), key=lambda kv: kv[1])[0]
                if len(vs) > 1:
                    emp_conf.append(f"{code} {e.name}: {key} " + ", ".join(f"{t} ({c})" for t, c in sorted(vs.items(), key=lambda kv: -kv[1])) + f" - {best} used")
                cur = (e.unit_name if key == "unit" else e.service_role) or ""
                if _norm(cur).lower() != best.lower():
                    emp_set[key][code] = best
    # themes: voted per category (the final category of each row)
    votes: Dict[str, Dict[str, int]] = {}
    tk = pick("rtheme", "theme")
    for n, r, code, final_cat in rowvals:
        nt = _norm(get(r, tk)) if tk else ""
        if nt and final_cat and nt.lower() != NO_THEME.lower():
            votes.setdefault(final_cat.lower(), {}).setdefault(nt, 0)
            votes[final_cat.lower()][nt] += 1
    themes = theme_list(db)
    tl = {t.lower(): t for t in themes}
    new_themes, theme_set, conflicts = [], {}, []
    for k, vs in votes.items():
        best = max(vs.items(), key=lambda kv: kv[1])[0]
        if len(vs) > 1:
            conflicts.append(f"{k}: " + ", ".join(f"{t} ({c})" for t, c in sorted(vs.items(), key=lambda kv: -kv[1])) + f" - {best} used")
        name = tl.get(best.lower(), best)
        if best.lower() not in tl and name not in new_themes:
            new_themes.append(name)
        if tm.get(k) != name:
            theme_set[k] = name
    # completeness: activities that would still have no theme after this upload
    after_map = dict(tm)
    after_map.update(theme_set)
    new_cat = {w.id: v for w, v in chg["category"]}
    gone = {w.id for w in dels}
    left = [w for w in items.values() if w.id not in gone]
    no_theme: Dict[str, int] = {}
    for c in [_norm(new_cat.get(w.id, w.category)) for w in left] + [_norm(v.get("category")) for _, _, v in adds]:
        if c and not after_map.get(c.lower()):
            no_theme[c] = no_theme.get(c, 0) + 1
    return {"sheet": sheet, "rows": len(rows), "matched": len(matched) + len(dels), "unmatched": unmatched, "chg": chg,
            "desc": chg["description"], "cat": chg["category"], "vols": chg["volume"], "freqs": chg["frequency"], "nats": chg["handling"],
            "by_content": by_content, "by_details": by_details, "missing": missing, "portal_total": len(items), "problems": problems,
            "revised": [k[1:] for k in ("rdesc", "rcat", "rtheme", "rfreq", "rvol", "rnat") if ci[k] is not None],
            "no_theme": sorted(no_theme.items(), key=lambda kv: -kv[1]),
            "no_category": sum(1 for w in left if not _norm(new_cat.get(w.id, w.category))) + sum(1 for _, _, v in adds if not v.get("category")),
            "theme_set": theme_set, "new_themes": new_themes, "conflicts": conflicts, "has_theme": tk is not None,
            "by_id": ci["id"] is not None, "full": full, "adds": adds, "dels": dels, "emp_set": emp_set, "emp_conflicts": emp_conf, "emps": emps}


def _changes(p) -> int:
    return sum(len(v) for v in p["chg"].values()) + len(p["theme_set"]) + len(p["adds"]) + len(p["dels"]) + sum(len(v) for v in p["emp_set"].values())


@router.post("/upload")
async def upload(file: UploadFile = File(...), dry_run: bool = Form(True), remove_missing: bool = Form(False),
                 user=Depends(require_admin), db: Session = Depends(get_db)):
    """remove_missing: also remove the activities of the employees in the file that are not in it (rows deleted or
    merged in Excel). Everything is kept for Undo Last Upload."""
    content = await file.read()
    p = _plan(db, content)
    emps = p["emps"]
    ename = lambda c: emps[c].name if c in emps else c
    out = {"sheet": p["sheet"], "rows": p["rows"], "matched": p["matched"], "unmatched": p["unmatched"][:50], "unmatched_count": len(p["unmatched"]),
           "descriptions": len(p["desc"]), "categories": len(p["cat"]), "themes_set": len(p["theme_set"]), "new_themes": p["new_themes"],
           "conflicts": p["conflicts"][:30], "has_theme": p["has_theme"], "by_id": p["by_id"], "full": p["full"],
           "frequencies": len(p["freqs"]), "natures": len(p["nats"]), "problems": p["problems"][:40], "problem_count": len(p["problems"]), "revised": p["revised"],
           "by_content": p["by_content"], "by_details": p["by_details"], "missing": len(p["missing"]), "portal_total": p["portal_total"], "volumes": len(p["vols"]),
           "fields": {f: len(v) for f, v in p["chg"].items()},
           "adds": len(p["adds"]), "deletes": len(p["dels"]), "units": len(p["emp_set"]["unit"]), "roles": len(p["emp_set"]["role"]),
           "emp_conflicts": p["emp_conflicts"][:30],
           "add_samples": [{"employee": f"{c} {ename(c)}", "category": v.get("category", ""), "description": (v.get("description") or "")[:90]} for _, c, v in p["adds"][:6]],
           "delete_samples": [{"employee": f"{w.employee_code} {ename(w.employee_code)}", "category": w.category or "", "description": (w.description or "")[:90]} for w in p["dels"][:6]],
           "emp_samples": [{"employee": f"{c} {ename(c)}", "what": "Unit" if k == "unit" else "Service / support",
                            "from": ((emps[c].unit_name if k == "unit" else emps[c].service_role) or "") if c in emps else "", "to": v}
                           for k in ("unit", "role") for c, v in list(p["emp_set"][k].items())[:4]],
           "missing_samples": [{"employee": w.employee_code, "category": w.category or "", "description": (w.description or "")[:90]} for w in p["missing"][:8]],
           "removing": len(p["missing"]) if remove_missing else 0,
           "no_theme_activities": sum(v for _, v in p["no_theme"]), "no_theme_categories": len(p["no_theme"]),
           "no_theme_top": [{"name": k, "activities": v} for k, v in p["no_theme"][:12]], "no_category": p["no_category"],
           "samples": [{"employee": w.employee_code, "from": w.category or "", "to": v} for w, v in p["cat"][:8]]
                      + [{"employee": w.employee_code, "from": (w.description or "")[:80], "to": v[:80], "description": True} for w, v in p["desc"][:4]],
           "dry_run": dry_run}
    if dry_run:
        return out
    if not (_changes(p) or (remove_missing and p["missing"])):
        raise HTTPException(400, "Nothing to change: the file matches the portal.")
    changes: Dict[int, dict] = {}
    for f, lst in p["chg"].items():
        for w, v in lst:
            changes.setdefault(w.id, {}).setdefault(f, getattr(w, f))
            setattr(w, f, v)
            w.updated_at = datetime.utcnow()
    emp_before = {}
    for key, d in p["emp_set"].items():
        for code, v in d.items():
            e = emps.get(code)
            if not e:
                continue
            emp_before.setdefault(code, {"unit_name": e.unit_name, "unit_name_source": e.unit_name_source,
                                         "service_role": e.service_role, "service_role_source": e.service_role_source})
            if key == "unit":
                e.unit_name, e.unit_name_source = v, "manual"
            else:
                e.service_role, e.service_role_source = v, "manual"
    cols = [c.name for c in models.WorkItem.__table__.columns]
    removed = []
    for w in p["dels"] + (p["missing"] if remove_missing else []):
        removed.append({k: (getattr(w, k).isoformat() if isinstance(getattr(w, k), datetime) else getattr(w, k)) for k in cols})
        db.delete(w)
    new_items = []
    sorts = {}
    for n, code, vals in p["adds"]:
        if code not in sorts:
            sorts[code] = db.query(models.WorkItem).filter(models.WorkItem.employee_code == code).count()
        sorts[code] += 1
        w = models.WorkItem(employee_code=code, frequency=vals.get("frequency") or freq_names()[0], sort=sorts[code], created_by=user.username,
                            **{k: v for k, v in vals.items() if k != "frequency"})
        db.add(w)
        new_items.append(w)
    db.flush()
    before_map, before_list = theme_map(db), theme_list(db)
    if p["new_themes"]:
        set_setting(db, "themes", before_list + p["new_themes"])
    if p["theme_set"]:
        tm = dict(before_map)
        tm.update(p["theme_set"])
        set_setting(db, "category_themes", tm)
    # the new category names join the admin's category list
    have = {c.name.lower() for c in db.query(models.Category)}
    added = []
    for v in [v for _, v in p["cat"]] + [x.get("category") for _, _, x in p["adds"] if x.get("category")]:
        if v.lower() not in have:
            db.add(models.Category(name=v, sort=99))
            have.add(v.lower())
            added.append(v)
    counts = [len(p["desc"]), len(p["cat"]), len(p["theme_set"]), len(p["vols"]), len(removed), len(p["freqs"]), len(p["nats"])]
    set_setting(db, "last_activity_upload", {"changes": [dict(old, id=i) for i, old in changes.items()], "removed": removed, "themes_before": before_list,
                                              "map_before": before_map, "categories_added": added, "added": [w.id for w in new_items],
                                              "employees": [dict(v, code=k) for k, v in emp_before.items()],
                                              "at": datetime.now().strftime("%d %b %Y %H:%M"), "by": user.username, "counts": counts})
    words = [f"{len(v)} {FIELD_WORDS[f]}" for f, v in p["chg"].items() if v]
    audit(db, user, "activity_review_upload", ", ".join(words + [f"{len(p['theme_set'])} category themes", f"{len(new_items)} activities added",
                                                                 f"{len(removed)} activities removed", f"{len(emp_before)} employees changed"]))
    db.commit()
    out["dry_run"] = False
    out["removing"] = len(removed) - len(p["dels"])
    return out


@router.get("/last")
def last(user=Depends(require_admin), db: Session = Depends(get_db)):
    x = get_setting(db, "last_activity_upload")
    return {"at": x["at"], "by": x["by"], "counts": x.get("counts")} if x else None


@router.post("/undo")
def undo(user=Depends(require_admin), db: Session = Depends(get_db)):
    x = get_setting(db, "last_activity_upload")
    if not x:
        raise HTTPException(400, "There is no upload to undo.")
    def as_old(ch):   # an earlier upload kept [id, description, category, volume]; now a dict of the fields
        if isinstance(ch, dict):
            return int(ch["id"]), {k: v for k, v in ch.items() if k != "id"}
        old = {"description": ch[1], "category": ch[2]}
        if len(ch) > 3:
            old["volume"] = ch[3]
        return int(ch[0]), old
    back = dict(as_old(ch) for ch in x["changes"])
    n = 0
    ids = list(back)
    for i in range(0, len(ids), 500):
        for w in db.query(models.WorkItem).filter(models.WorkItem.id.in_(ids[i:i + 500])):
            for k, v in back[w.id].items():
                setattr(w, k, v)
            n += 1
    added = x.get("added") or []
    for i in range(0, len(added), 500):   # activities the upload added are taken out again
        for w in db.query(models.WorkItem).filter(models.WorkItem.id.in_(added[i:i + 500])):
            db.delete(w)
            n += 1
    db.flush()
    for row in x.get("removed") or []:   # activities removed by the upload come back as they were
        if db.get(models.WorkItem, row["id"]) is None:
            vals = {k: (datetime.fromisoformat(v) if k in ("created_at", "updated_at") and isinstance(v, str) else v) for k, v in row.items()}
            db.add(models.WorkItem(**vals))
            n += 1
    for row in x.get("employees") or []:
        e = db.get(models.Employee, row["code"])
        if e:
            for k in ("unit_name", "unit_name_source", "service_role", "service_role_source"):
                setattr(e, k, row.get(k))
    set_setting(db, "themes", x.get("themes_before") or [])
    set_setting(db, "category_themes", x.get("map_before") or {})
    for name in x.get("categories_added") or []:
        for c in db.query(models.Category).filter(models.Category.name == name):
            db.delete(c)
    set_setting(db, "last_activity_upload", None)
    audit(db, user, "activity_review_undo", f"{n} activities restored, {len(x.get('employees') or [])} employees")
    db.commit()
    return {"ok": True, "activities": n, "employees": len(x.get("employees") or [])}
