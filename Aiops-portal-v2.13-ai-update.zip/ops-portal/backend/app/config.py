"""Settings. Override any of these with environment variables (see README)."""
import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("OPS_DATA_DIR", BASE_DIR / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

# SQLite by default (good for testing on Windows).
# PostgreSQL example: postgresql+psycopg2://opsportal:password@localhost/opsportal
DATABASE_URL = os.getenv("OPS_DB_URL", f"sqlite:///{(DATA_DIR / 'portal.db').as_posix()}")

STATIC_DIR = Path(os.getenv("OPS_STATIC_DIR", BASE_DIR / "static"))
TOKEN_HOURS = int(os.getenv("OPS_TOKEN_HOURS", "12"))

# Text in the grade column that marks contract / outsourced staff (FTC)
OUTSOURCED_GRADE_TEXT = os.getenv("OPS_OUTSOURCED_GRADE", "Outsourced Staff").strip().lower()


def _secret() -> str:
    env = os.getenv("OPS_SECRET_KEY")
    if env:
        return env
    f = DATA_DIR / "secret.key"
    if not f.exists():
        f.write_text(secrets.token_hex(32))
    return f.read_text().strip()


SECRET_KEY = _secret()
