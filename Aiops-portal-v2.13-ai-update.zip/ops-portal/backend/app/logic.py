"""Shared business logic: function heads, activity time calculations and serialisation.

Activity time (the data capture template, one row per employee per activity):
  Total staff processing time (min) = processing time per item (min) x average volume
  Daily equivalent (min)            = total / working days in the frequency period
                                      (Daily 1, Weekly 5, Fortnightly 10, Monthly 22 by default)
  Daily man-hours                   = daily equivalent / 60
  Peak day man-hours                = processing time x peak volume per day / 60
                                      (start of month and end of month; the normal daily figure is
                                      used for activities without a peak volume)
  Utilisation                       = daily man-hours / productive hours per day (7.5 by default)
"""
from typing import Dict, Iterable, List, Optional, Set

from sqlalchemy.orm import Session

from . import models

_WI_COLS = tuple(c.name for c in models.WorkItem.__table__.columns)


class ItemRow:
    """A read-only copy of a work item for the dashboards: read straight from the table, many times faster than
    full ORM objects for thousands of activities. dh: its daily hours, worked out once."""
    __slots__ = _WI_COLS + ("dh",)

    # __init__ is written out below (one assignment of all fields), much faster than setting them one by one


_ns: dict = {}
exec("def __init__(self, v):\n    " + ", ".join("self." + k for k in _WI_COLS) + " = v\n    self.dh = None\n", _ns)
ItemRow.__init__ = _ns["__init__"]


_EMP_COLS = tuple(c.name for c in models.Employee.__table__.columns)


class EmpRow:
    """A read-only copy of an employee for the dashboards (see ItemRow)."""
    __slots__ = _EMP_COLS


exec("def __init__(self, v):\n    " + ", ".join("self." + k for k in _EMP_COLS) + " = v\n", _ns)
EmpRow.__init__ = _ns["__init__"]

_snap = {"ver": None, "data": None}


def snapshot(db: Session):
    """Every employee and activity as read-only copies, read once and shared until anything in the database
    changes (see cache.data_version). Returns (employees by code, activities)."""
    from sqlalchemy import select
    from .cache import data_version
    ver = data_version()
    if _snap["ver"] == ver and _snap["data"] is not None:
        return _snap["data"]
    t = models.Employee.__table__
    emps = {r[0]: EmpRow(r) for r in db.execute(select(*[t.c[k] for k in _EMP_COLS]))}
    data = (emps, fast_items(db))
    _snap["ver"], _snap["data"] = ver, data
    return data


def fast_items(db: Session, where=None) -> list:
    from sqlalchemy import select
    t = models.WorkItem.__table__
    q = select(*[t.c[k] for k in _WI_COLS]).order_by(t.c.id)
    if where is not None:
        q = q.where(where)
    return [ItemRow(r) for r in db.execute(q)]
from .security import get_setting

FREQUENCIES = ["Daily", "Weekly", "Fortnightly", "Monthly"]   # defaults; the admin manages the list
# Nature of work: the options are managed by the admin (Admin, Lists). HANDLING is updated in place so every
# module that imported it sees the current list. The old names (before version 2.11) map to the new ones.
NATURE_DEFAULT = ["Core Physical", "System Based", "Straight Through Processing (STP)"]
NATURE_LEGACY = {"manual": "Core Physical", "file based": "System Based", "system based": "Straight Through Processing (STP)"}
HANDLING = list(NATURE_DEFAULT)
_NATURE_LABEL = ["Nature of Work"]
# earlier headings and option names the admin renamed or removed, so that templates downloaded before still import
_NATURE_HIST = {"labels": [], "aliases": {}}


def nature_label() -> str:
    return _NATURE_LABEL[0]


def nature_headings() -> set:
    """Column headings (lower case) read as nature of work: the current one, the default and earlier ones."""
    return {_NATURE_LABEL[0].lower(), "nature of work"} | {x.lower() for x in _NATURE_HIST.get("labels", [])}


def nature_value(v) -> str:
    """An option name as written in a template or form, with earlier (renamed or removed) names mapped on."""
    s = str(v or "").strip()
    if not s or s in HANDLING:
        return s
    return (_NATURE_HIST.get("aliases") or {}).get(s.lower(), s)
SERVICE_TYPES = ["Service", "Support"]
# volume type: "File" = file based volume (e.g. the rows of an uploaded file), "" = transaction based (the default)
VOL_FILE = "File"
_VOL_LABELS = ["File Based", "Activity Based"]


def vol_labels():
    """The admin's names for the two volume types (Admin, Labels)."""
    return tuple(_VOL_LABELS)


def vol_type_value(v):
    """A volume type as written in a template or form: "File", "" (activity based), or None if not understood."""
    s = " ".join(str(v or "").split()).lower()
    if not s:
        return ""
    if s in ("file", "file based", "file-based", _VOL_LABELS[0].lower()) or s.startswith("file"):
        return VOL_FILE
    if s in ("txn", "transaction", "transaction based", "transaction-based", "activity", "activity based", "activity-based", "other", _VOL_LABELS[1].lower()) or s.startswith(("transaction", "activity")):
        return ""
    return None
# Data capture fields the admin can set as required, optional or hidden (Admin, Settings)
CAPTURE_FIELDS = [("product", "product"), ("process", "process name"), ("channel", "channel"),
                  ("description", "activity description"), ("category", "activity category"),
                  ("frequency", "frequency"), ("volume", "average volume"),
                  ("peak", "peak volumes"), ("handling", "nature of work"), ("minutes", "processing time"),
                  ("automation", "automation opportunity")]
# every field is shown and optional by default: an employee's activities differ, so unneeded fields are left blank
FIELD_DEFAULTS = {f: "optional" for f, _ in CAPTURE_FIELDS}
_REQ = []          # required fields, default for all functions
_REQ_FN = {}       # function id -> required fields, where the admin set the function differently
_FREQS = list(FREQUENCIES)


def freq_names():
    return _FREQS


def field_config(db: Session) -> dict:
    cfg = dict(FIELD_DEFAULTS)
    cfg.update({k: v for k, v in (get_setting(db, "capture_fields") or {}).items() if k in cfg and v in ("required", "optional", "hidden")})
    return cfg


def function_fields(db: Session, fid: Optional[int]) -> dict:
    """Field settings for one function: its own settings if the admin set any, otherwise the default."""
    cfg = field_config(db)
    if fid:
        own = get_setting(db, f"capture_fields:{fid}") or {}
        cfg.update({k: v for k, v in own.items() if k in cfg and v in ("required", "optional", "hidden")})
    return cfg


def has_own_fields(db: Session, fid: int) -> bool:
    return bool(get_setting(db, f"capture_fields:{fid}"))


def load_required(db: Session):
    """Refresh the required-field list (at start-up and when the admin changes it)."""
    global _REQ, _REQ_FN, _FREQS, _TOP_HIDDEN, _HIDE_RESIGNED
    HANDLING[:] = [x for x in (get_setting(db, "nature_options") or NATURE_DEFAULT) if x] or list(NATURE_DEFAULT)
    _NATURE_LABEL[0] = (get_setting(db, "nature_label") or "Nature of Work").strip() or "Nature of Work"
    h = get_setting(db, "nature_history") or {}
    _NATURE_HIST["labels"] = list(h.get("labels") or [])
    _NATURE_HIST["aliases"] = dict(h.get("aliases") or {})
    lb = get_setting(db, "labels") or {}
    _VOL_LABELS[:] = [lb.get("vol.file") or "File Based", lb.get("vol.txn") or "Activity Based"]
    v = get_setting(db, "hide_resigned")
    _HIDE_RESIGNED = True if v is None else bool(v)   # resigned employees hidden everywhere (default on)
    # the grade of the top of the organisation is hidden (shown as "-") unless the admin shows it
    _TOP_HIDDEN = None if get_setting(db, "show_top_grade") else get_setting(db, "root_code")
    _FREQS = [n for n, _ in frequency_list(db)] or list(FREQUENCIES)
    req = lambda cfg: [(f, l) for f, l in CAPTURE_FIELDS if cfg[f] == "required" and f != "peak"]
    _REQ = req(field_config(db))
    _REQ_FN = {f.id: req(function_fields(db, f.id)) for f in db.query(models.Function) if has_own_fields(db, f.id)}


# ---------------------------------------------------------------- settings
def frequency_list(db: Session):
    return [(f.name, float(f.days or 1)) for f in db.query(models.Frequency).order_by(models.Frequency.sort, models.Frequency.id)]


class Calc:
    """Settings used by every calculation, read once per request. fid: the function, for its required fields."""

    def __init__(self, db: Session, fid: Optional[int] = None):
        self.ph = float(get_setting(db, "productive_hours") or 7.5)
        self.days = {n: d for n, d in frequency_list(db)} or {"Daily": 1.0}
        self.wk = self.days.get("Weekly", 5.0)
        self.mo = self.days.get("Monthly", 22.0)
        self.fid = fid

    def total_minutes(self, w: models.WorkItem) -> float:
        return float(w.minutes or 0) * float(w.volume or 0)

    def daily_hours(self, w: models.WorkItem) -> float:
        dh = getattr(w, "dh", None)   # worked out once for a dashboard copy (ItemRow)
        if dh is not None:
            return dh
        d = self.days.get(w.frequency or "Daily", 1.0) or 1.0
        h = self.total_minutes(w) / d / 60.0
        if isinstance(w, ItemRow):
            w.dh = h
        return h

    def peak_hours(self, w: models.WorkItem, which: str) -> float:
        v = w.peak_som if which == "som" else w.peak_eom
        if v is None:
            return self.daily_hours(w)
        return float(w.minutes or 0) * float(v) / 60.0

    def settings(self) -> dict:
        return {"productive_hours": self.ph, "working_days_week": self.wk, "working_days_month": self.mo,
                "days": self.days, "frequencies": list(self.days)}


def missing_fields(w: models.WorkItem, fid: Optional[int] = None) -> List[str]:
    out = []
    for f, label in _REQ_FN.get(fid, _REQ):
        v = getattr(w, f)
        if f in ("volume", "minutes"):
            if v is None or v <= 0:
                out.append(label)
        elif not (v or "").strip():
            out.append(label)
    return out


def ser_item(w: models.WorkItem, c: Calc, linked: int = 0) -> dict:
    return {"id": w.id, "employee_code": w.employee_code, "unit": w.unit or "", "product": w.product or "",
            "process": w.process or "", "channel": w.channel or "", "description": w.description or "",
            "category": w.category or "", "service_type": w.service_type or "", "frequency": w.frequency or "Daily",
            "volume": w.volume, "volume_type": w.volume_type or "", "peak_som": w.peak_som, "peak_eom": w.peak_eom, "handling": w.handling or "",
            "minutes": w.minutes, "automation": w.automation or "", "link_id": w.link_id, "linked": linked,
            "total_minutes": round(c.total_minutes(w), 2), "daily_hours": round(c.daily_hours(w), 3),
            "peak_som_hours": round(c.peak_hours(w, "som"), 3), "peak_eom_hours": round(c.peak_hours(w, "eom"), 3),
            "missing": missing_fields(w, c.fid)}


def classify(types: Iterable[str]) -> str:
    s = {t for t in types if t in SERVICE_TYPES}
    if not s:
        return ""
    return "Both" if len(s) == 2 else s.pop()


def summarise(items: List[models.WorkItem], c: Calc, role: str = "") -> dict:
    """Totals for one employee. Service or support is the employee's role, not the activity's;
    """
    h = sum(c.daily_hours(w) for w in items)
    share = {"Service": (1, 0), "Support": (0, 1)}.get(role, (0, 0))
    som = sum(c.peak_hours(w, "som") for w in items)
    eom = sum(c.peak_hours(w, "eom") for w in items)
    return {"activities": len(items), "incomplete": sum(1 for w in items if missing_fields(w, c.fid)),
            "daily_hours": round(h, 3), "utilisation": round(h / c.ph * 100, 1) if c.ph else 0,
            "peak_som_hours": round(som, 3), "peak_eom_hours": round(eom, 3),
            "peak_utilisation": round(max(som, eom) / c.ph * 100, 1) if c.ph else 0,
            "service_type": role or "",
            "service_hours": round(h * share[0], 3), "support_hours": round(h * share[1], 3)}


def items_by_employee(db: Session, function_id: Optional[int] = None, codes: Optional[Set[str]] = None) -> Dict[str, List[models.WorkItem]]:
    q = db.query(models.WorkItem)
    if function_id is not None:
        q = q.join(models.Employee, models.Employee.code == models.WorkItem.employee_code).filter(models.Employee.function_id == function_id)
    out: Dict[str, List[models.WorkItem]] = {}
    for w in q.order_by(models.WorkItem.employee_code, models.WorkItem.sort, models.WorkItem.id):
        if codes is None or w.employee_code in codes:
            out.setdefault(w.employee_code, []).append(w)
    return out


def link_counts(db: Session, link_ids: Iterable[str]) -> Dict[str, int]:
    ids = [x for x in set(link_ids) if x]
    if not ids:
        return {}
    from sqlalchemy import func
    out = {}
    for i in range(0, len(ids), 500):
        for lid, n in (db.query(models.WorkItem.link_id, func.count(models.WorkItem.id))
                       .filter(models.WorkItem.link_id.in_(ids[i:i + 500])).group_by(models.WorkItem.link_id)):
            out[lid] = n
    return out


def active_staff(db: Session, fid: int):
    """Employees of a function, without those marked as resigned."""
    return [e for e in db.query(models.Employee).filter(models.Employee.function_id == fid) if not e.resigned]


def service_types(db: Session) -> Dict[str, str]:
    """Employee code -> Service or Support, from the activities they recorded before the type moved to
    the employee: the kind most of their activities had. An even split is left for the POC to decide."""
    seen: Dict[str, Dict[str, int]] = {}
    for code, t in db.query(models.WorkItem.employee_code, models.WorkItem.service_type):
        if t in SERVICE_TYPES:
            d = seen.setdefault(code, {"Service": 0, "Support": 0})
            d[t] += 1
    return {k: ("Service" if v["Service"] > v["Support"] else "Support") for k, v in seen.items() if v["Service"] != v["Support"]}


# ---------------------------------------------------------------- function heads
def function_heads(db: Session, fn_id: int, staff: List[models.Employee] = None) -> Set[str]:
    """The head of a function is the person in it who reports directly to the top of the organisation
    (or the top person, if they belong to this function). Fallback: the most senior person whose
    manager is outside the function."""
    root = get_setting(db, "root_code")
    if staff is None:
        staff = db.query(models.Employee).filter(models.Employee.function_id == fn_id).all()
    master = [e for e in staff if e.source != "added"]
    codes = {e.code for e in master}
    if root in codes:
        return {root}
    direct = [e for e in master if e.manager_code == root]
    if direct:
        # several people of a function can report to the top (a secretary, an adviser): the head is the
        # most senior of them, preferring those who lead a team
        mgrs = {mc for (mc,) in db.query(models.Employee.manager_code).filter(models.Employee.manager_code.in_([e.code for e in direct]))}
        pool = [e for e in direct if e.code in mgrs] or direct
        top = max(e.grade_rank or 0 for e in pool)
        return {e.code for e in pool if (e.grade_rank or 0) == top}
    outside = [e for e in master if e.manager_code not in codes]
    if not outside:
        return set()
    top = max(e.grade_rank or 0 for e in outside)
    return {e.code for e in outside if (e.grade_rank or 0) == top}


def depth_map(db: Session) -> Dict[str, int]:
    root = get_setting(db, "root_code")
    kids: Dict[str, List[str]] = {}
    for code, mc in db.query(models.Employee.code, models.Employee.manager_code):
        if mc:
            kids.setdefault(mc, []).append(code)
    depth = {root: 0}
    order = [root]
    for x in order:
        for k in kids.get(x, []):
            if k not in depth:
                depth[k] = depth[x] + 1
                order.append(k)
    return depth


def staff_sort_key(heads: Set[str], depth: Dict[str, int]):
    # function head first, then by grade (most senior first), then higher in the hierarchy, then name
    return lambda e: (0 if e.code in heads else 1, -(e.grade_rank or 0), depth.get(e.code, 99), e.name)


_TOP_HIDDEN = None
_HIDE_RESIGNED = True


def hide_resigned() -> bool:
    return _HIDE_RESIGNED


def reassign_resigned_teams(db: Session, only=None) -> int:
    """Whoever reports to a resigned employee reports to that employee's line manager instead (the next manager
    up who has not resigned). The change is kept at master sheet imports. only: limit to these resigned codes."""
    emps = {e.code: e for e in db.query(models.Employee)}
    moved = 0
    for e in emps.values():
        m = emps.get(e.manager_code) if e.manager_code else None
        if not m or not m.resigned or e.resigned or (only is not None and m.code not in only):
            continue
        up, n = m, 0
        while up and up.resigned and n < 40:
            up, n = emps.get(up.manager_code) if up.manager_code else None, n + 1
        if up and up.code != e.code:
            e.manager_code = up.code
            e.overrides = sorted(set(e.overrides or []) | {"manager"})
            moved += 1
    return moved


def shown_grade(e) -> str:
    return "-" if _TOP_HIDDEN and e.code == _TOP_HIDDEN else e.grade


def ser_employee(e: models.Employee, heads: Set[str] = frozenset(), names: Dict[str, str] = None) -> dict:
    return {"code": e.code, "name": e.name, "grade": shown_grade(e), "grade_rank": e.grade_rank, "position": e.position or "",
            "emp_type": e.emp_type, "region": e.region, "region_source": e.region_source,
            "service_role": e.service_role or "", "service_role_source": e.service_role_source, "resigned": bool(e.resigned),
            "unit": e.unit_name or "", "unit_source": e.unit_name_source, "source": e.source,
            "verified": e.verified, "manager_code": e.manager_code, "manager_name": (names or {}).get(e.manager_code),
            "external": e.external, "exclude": e.exclude, "is_head": e.code in heads}


# ---------------------------------------------------------------- payloads
def suggestions(db: Session, fn_id: int) -> dict:
    """Values already used in this function, offered as you type (plus the admin's standard categories)."""
    q = (db.query(models.WorkItem).join(models.Employee, models.Employee.code == models.WorkItem.employee_code)
         .filter(models.Employee.function_id == fn_id))
    vals = {"units": set(), "products": set(), "processes": set(), "channels": set(), "categories": set()}
    for w in q:
        for k, f in (("units", w.unit), ("processes", w.process), ("channels", w.channel), ("categories", w.category)):
            if f and f.strip():
                vals[k].add(f.strip())
        for p in (w.product or "").split(";"):
            if p.strip():
                vals["products"].add(p.strip())
    for (u,) in db.query(models.Employee.unit_name).filter(models.Employee.function_id == fn_id):
        if u and u.strip():
            vals["units"].add(u.strip())
    std = [c.name for c in db.query(models.Category).order_by(models.Category.sort, models.Category.name)]
    out = {k: sorted(v, key=str.lower) for k, v in vals.items()}
    # activity categories: every category used in any function, plus the admin's list, so all functions
    # describe the same work the same way (one spelling each, ignoring capitals)
    cats = {}
    for name in std + [c for (c,) in db.query(models.WorkItem.category).distinct() if c and c.strip()]:
        cats.setdefault(" ".join(name.split()).lower(), " ".join(name.split()))
    out["categories"] = sorted(cats.values(), key=str.lower)
    # products, likewise: every product used in any function
    prods = {}
    for (pv,) in db.query(models.WorkItem.product).distinct():
        for x in (pv or "").split(";"):
            x = " ".join(x.split())
            if x:
                prods.setdefault(x.lower(), x)
    out["products"] = sorted(prods.values(), key=str.lower)
    return out


def function_payload(db: Session, fn: models.Function) -> dict:
    c = Calc(db, fn.id)
    staff = active_staff(db, fn.id)
    heads = function_heads(db, fn.id, staff)
    depth = depth_map(db)
    names = {e.code: e.name for e in db.query(models.Employee.code, models.Employee.name)}
    work = items_by_employee(db, fn.id)
    rows = []
    for e in sorted(staff, key=staff_sort_key(heads, depth)):
        r = ser_employee(e, heads, names)
        r.update(summarise(work.get(e.code, []), c, e.service_role or ""))
        rows.append(r)
    reqs = db.query(models.RetagRequest).filter(models.RetagRequest.to_function_id == fn.id,
                                                  models.RetagRequest.status == "Pending").all()
    return {
        "function": {"id": fn.id, "name": fn.name, "status": capture_status(db, fn, [w for ws in work.values() for w in ws])},
        "settings": c.settings(),
        "heads": sorted(heads),
        "staff": rows,
        "requests": [{"id": r.id, "code": r.code, "name": names.get(r.code, r.code), "status": r.status, "kind": r.kind or "function",
                      "to_manager": r.to_manager, "to_manager_name": names.get(r.to_manager)} for r in reqs],
        "suggestions": suggestions(db, fn.id),
        "fields": function_fields(db, fn.id),
        "pocs_hidden": [f for f in (get_setting(db, f"hidden_fields:{fn.id}") or [])],
    }


def function_summary(db: Session) -> list:
    c = Calc(db)
    out = []
    by_fn: Dict[int, List[models.WorkItem]] = {}
    emp_fn = {code: fid for code, fid in db.query(models.Employee.code, models.Employee.function_id)}
    resigned = {code for (code,) in db.query(models.Employee.code).filter(models.Employee.resigned == True)}  # noqa
    role = {code: r or "" for code, r in db.query(models.Employee.code, models.Employee.service_role)}
    share = {"Service": (1, 0), "Support": (0, 1)}
    for w in snapshot(db)[1]:
        f = emp_fn.get(w.employee_code)
        if f:
            by_fn.setdefault(f, []).append(w)
    staff_of: Dict[int, list] = {}
    for e in snapshot(db)[0].values():   # read-only copies, shared until the data changes
        if not e.resigned:
            staff_of.setdefault(e.function_id, []).append(e)
    for fn in db.query(models.Function).order_by(models.Function.name).all():
        hc = len(staff_of.get(fn.id, []))
        items = [w for w in by_fn.get(fn.id, []) if w.employee_code not in resigned]
        h = sum(c.daily_hours(w) for w in items)
        out.append({"id": fn.id, "name": fn.name, "hr_name": fn.hr_name or fn.name, "status": capture_status(db, fn, items, staff_of.get(fn.id, [])), "headcount": hc,
                    "staff_with_work": len({w.employee_code for w in items}), "activities": len(items),
                    "incomplete": sum(1 for w in items if missing_fields(w, fn.id)),
                    "daily_hours": round(h, 2), "fte_equivalent": round(h / c.ph, 2) if c.ph else 0,
                    "service_hours": round(sum(c.daily_hours(w) * share.get(role.get(w.employee_code), (0, 0))[0] for w in items), 2),
                    "support_hours": round(sum(c.daily_hours(w) * share.get(role.get(w.employee_code), (0, 0))[1] for w in items), 2),
                    "status_at": fn.status_at.isoformat(timespec="minutes") if fn.status_at else None})
    return out


def capture_status(db: Session, fn: models.Function, items=None, staff=None) -> str:
    """Not started / In progress / Complete: every employee has a region, everyone except the function
    head has at least one activity (units are optional), and nothing required is missing."""
    if items is None:
        items = [w for ws in items_by_employee(db, fn.id).values() for w in ws]
    if staff is None:
        staff = active_staff(db, fn.id)
    if not items and not any(e.region_source == "manual" or e.unit_name for e in staff):
        return "Not started"
    heads = function_heads(db, fn.id, staff)
    have = {w.employee_code for w in items}
    done = all(e.region and (e.code in heads or e.code in have) for e in staff) and not any(missing_fields(w, fn.id) for w in items)
    return "Complete" if done and staff else "In progress"


def employee_work(db: Session, fn: models.Function) -> dict:
    """Every person in one function with their recorded activities."""
    c = Calc(db, fn.id)
    staff = active_staff(db, fn.id)
    heads = function_heads(db, fn.id, staff)
    depth = depth_map(db)
    names = {e.code: e.name for e in db.query(models.Employee.code, models.Employee.name)}
    work = items_by_employee(db, fn.id)
    links = link_counts(db, [w.link_id for ws in work.values() for w in ws])
    out = []
    for e in sorted(staff, key=staff_sort_key(heads, depth)):
        items = work.get(e.code, [])
        row = ser_employee(e, heads, names)
        row.update(summarise(items, c, e.service_role or ""))
        row["items"] = [ser_item(w, c, links.get(w.link_id, 1) - 1 if w.link_id else 0) for w in items]
        out.append(row)
    return {"function": {"id": fn.id, "name": fn.name, "status": capture_status(db, fn, [w for ws in work.values() for w in ws])}, "settings": c.settings(), "fields": function_fields(db, fn.id), "employees": out}
