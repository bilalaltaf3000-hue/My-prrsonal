@echo off
REM ---- Operations Services Workforce Portal: run on Windows for testing ----
cd /d "%~dp0backend"
if not exist .venv (
  echo Creating Python virtual environment...
  py -3.12 -m venv .venv 2>nul || python -m venv .venv
)
call .venv\Scripts\activate.bat
if not exist .venv\installed.flag (
  echo Installing packages...
  python -m pip install --upgrade pip
  pip install -r requirements.txt && echo ok> .venv\installed.flag
)
echo.
echo Portal starting at http://127.0.0.1:8000  (press Ctrl+C to stop)
echo First admin password is shown below on the first run and saved in backend\data\FIRST_ADMIN_PASSWORD.txt
echo.
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
pause
