import React, { useEffect, useMemo, useRef, useState } from 'react'
import { api, download } from '../api.js'
import { fmt, hrs, short, TYPE_COL, num2 } from '../org.js'
import { Dot, EditField, Modal } from '../ui.jsx'
import { utilTone } from './EmployeeDetails.jsx'
import { prefs, L, VOL_FILE } from '../prefs.js'

const STEPS = ['Employees, units and regions', 'Activities', 'Review']
const ROLES = ['Service', 'Support']
// frequencies come from the admin's list (Admin, Categories and lists)
let FREQ = ['Daily', 'Weekly', 'Fortnightly', 'Monthly']
const PER = new Proxy({ Daily: 'day', Weekly: 'week', Fortnightly: 'fortnight', Monthly: 'month', Quarterly: 'quarter', 'Half yearly': 'half year', 'Half-yearly': 'half year', Yearly: 'year', Annually: 'year', Annual: 'year' },
  { get: (t, k) => t[k] || (typeof k === 'string' ? `${k.toLowerCase()} period` : undefined) })

export default function Capture({ user, lookups, notify, showLine }) {
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState(null)
  const [data, setData] = useState(null)
  const [step, setStep] = useState(1)
  const [busy, setBusy] = useState(false)
  const [current, setCurrent] = useState(null)   // employee code open in step 2

  useEffect(() => {
    api('/api/capture/functions').then(r => { const ed = r.filter(x => x.can_edit).sort((a, b) => a.name.localeCompare(b.name)); setFns(ed); if (!fid && ed.length) setFid(ed[0].id) }).catch(e => notify(e.message, true))
  }, [])
  const reload = () => api(`/api/capture/${fid}`).then(setData).catch(e => notify(e.message, true))
  useEffect(() => { if (fid) { setData(null); setCurrent(null); reload() } }, [fid])

  const call = async (path, method = 'POST', body) => {
    setBusy(true)
    try { const d = await api(path, { method, body }); if (d && d.staff && d.function) setData(d); return d }
    catch (e) { notify(e.message, true); return null } finally { setBusy(false) }
  }

  if (!fns.length) return <section className="view on"><h1>Data Capture</h1><div className="empty">No functions are assigned to you for data capture.</div></section>
  if (!data) return <section className="view on"><h1>Data Capture</h1><div className="loading">Loading…</div></section>

  const locked = false
  if (data.settings?.frequencies?.length) FREQ = data.settings.frequencies
  const props = { data, setData, call, lookups, notify, fid, user, busy, reload, current, setCurrent, locked, setStep, showLine }
  const noRegion = data.staff.filter(s => !s.region).length, noUnit = data.staff.some(s => s.unit) ? data.staff.filter(s => !s.unit && !s.is_head).length : 0
  const withWork = data.staff.filter(s => s.activities).length

  return <section className="view on">
    <h1>Data Capture</h1>
    <p className="lede">Record each employee's unit and region, then whether they are service or support employees and the activities they perform, one entry per activity as in the data capture template. Changes save automatically when you leave a field.</p>
    <div className="cap-top">
      <div className="who">{fns.length <= 1 ? <>Function: <b style={{ color: 'var(--ink)' }}>{data.function.name}</b></> :
        <>Function <select value={fid} onChange={e => { setFid(+e.target.value); setStep(1) }}>{fns.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select></>}</div>
      <div className="who">Status <span className={'pill ' + (data.function.status === 'Complete' ? 'p-ok' : 'p-warn')}>{data.function.status}</span></div>
    </div>
    <div className="steps">{STEPS.map((s, i) => <button key={i} aria-current={step === i + 1} onClick={() => setStep(i + 1)}><b>{i + 1}</b>{s}
      <small>{i === 0 ? (noRegion || noUnit ? [noUnit && `${fmt(noUnit)} without a unit`, noRegion && `${fmt(noRegion)} without a region`].filter(Boolean).join(', ') : 'All units and regions set') : i === 1 ? `${fmt(withWork)} of ${fmt(data.staff.length)} employees` : ''}</small></button>)}</div>
    <fieldset disabled={locked} style={{ border: 0, padding: 0, margin: 0, minWidth: 0 }}>
      {step === 1 && <Staff {...props} />}
      {step === 2 && <Activities {...props} />}
      {step === 3 && <Review {...props} />}
    </fieldset>
  </section>
}

// ================================================================== step 1: staff and regions
function Staff({ data, call, fid, notify, lookups }) {
  const [mode, setMode] = useState('managers')
  const [lineFor, setLineFor] = useState(null)
  const regions = lookups?.regions || []
  const reqs = data.requests || []
  return <>
    <p className="sub" style={{ margin: '0 0 14px' }}>Set the unit and region of each employee. Their activities then carry the unit automatically, and the dashboard's geographical spread uses the region. Service or support is set at the top of each employee's activities in step 2; to set it, the unit, region or FTE / FTC for many employees at once, use <b>Everyone</b>. Regions from the employee master sheet are already filled in where available. If someone reports to a different manager than shown, request a reporting line change; the admin approves it.</p>
    <datalist id="dl-unit">{(data.suggestions.units || []).map(v => <option key={v} value={v} />)}</datalist>
    <div className="kvline" style={{ marginBottom: 14 }}><span className="seg" role="group" aria-label="How to set units and regions">
      <button type="button" aria-pressed={mode === 'managers'} onClick={() => setMode('managers')}>By manager (fastest)</button>
      <button type="button" aria-pressed={mode === 'all'} onClick={() => setMode('all')}>Everyone</button>
      <button type="button" aria-pressed={mode === 'add'} onClick={() => setMode('add')}>Add a missing employee</button></span></div>
    {reqs.length > 0 && <div className="msg warn" style={{ marginBottom: 14 }}><b>Waiting for the admin's approval:</b>
      <ul style={{ margin: '4px 0 0 18px', padding: 0 }}>{reqs.map(r => <li key={r.id}>{r.kind === 'manager' ? <>{r.name} ({r.code}): reporting line to <b>{r.to_manager_name || r.to_manager}</b></> : <>{r.name} ({r.code}): re-tagging to this function</>}{r.note ? <span className="formula"> · {r.note}</span> : null}</li>)}</ul></div>}
    {mode === 'managers' && <ManagersView data={data} call={call} fid={fid} notify={notify} regions={regions} onLine={setLineFor} />}
    {mode === 'all' && <Everyone data={data} call={call} fid={fid} notify={notify} regions={regions} onLine={setLineFor} />}
    {lineFor && <ManagerRequest emp={lineFor} data={data} call={call} fid={fid} notify={notify} close={() => setLineFor(null)} />}
    {mode === 'add' && <AddEmployee data={data} call={call} fid={fid} regions={regions} />}
  </>
}

function ManagersView({ data, call, fid, notify, regions, onLine }) {
  const [cascade, setCascade] = useState(true)
  const [q, setQ] = useState('')
  const rows = useMemo(() => {
    const inFn = new Map(data.staff.map(s => [s.code, s]))
    const kids = new Map()
    data.staff.forEach(s => { if (s.manager_code && inFn.has(s.manager_code)) { if (!kids.has(s.manager_code)) kids.set(s.manager_code, []); kids.get(s.manager_code).push(s) } })
    const team = code => { let n = 0; const st = [...(kids.get(code) || [])]; while (st.length) { const x = st.pop(); n++; st.push(...(kids.get(x.code) || [])) } return n }
    const tops = data.staff.filter(s => !inFn.has(s.manager_code))
    const out = []
    const walk = (s, depth) => {
      const k = kids.get(s.code) || []
      if (depth === 0 || k.length) out.push({ s, depth, team: team(s.code) })
      k.slice().sort((a, b) => (b.grade_rank || 0) - (a.grade_rank || 0) || a.name.localeCompare(b.name)).forEach(c => walk(c, depth + 1))
    }
    tops.slice().sort((a, b) => b.is_head - a.is_head || (b.grade_rank || 0) - (a.grade_rank || 0)).forEach(s => walk(s, 0))
    return out
  }, [data])
  const ql = q.trim().toLowerCase()
  const shown = ql ? rows.filter(r => (r.s.name + ' ' + r.s.code + ' ' + r.s.position).toLowerCase().includes(ql)) : rows
  const set = async (code, body) => {
    const d = await call(`/api/capture/${fid}/staff/${encodeURIComponent(code)}`, 'PATCH', { ...body, cascade })
    if (d && cascade && d.followed) notify(`${d.followed} ${d.followed === 1 ? 'person' : 'people'} in their team followed.`)
  }
  const nReg = data.staff.filter(s => s.region).length, nUnit = data.staff.filter(s => s.unit || s.is_head).length, nRole = data.staff.filter(s => s.service_role).length
  const src = s => ({ inherited: 'from their manager', import: 'from the master sheet', manual: 'set individually' })[s]
  return <>
    <div className="msg ok" style={{ marginTop: 0, marginBottom: 12 }}>Set the unit and region for a manager and their whole team follows. Anyone you set individually keeps their own, and their team follows them instead. <b>{fmt(nUnit)}</b> of {fmt(data.staff.length)} employees have a unit and <b>{fmt(nReg)}</b> have a region.</div>
    <div className="kvline">
      <label className="formula" style={{ display: 'flex', gap: 6, alignItems: 'center' }}><input type="checkbox" checked={cascade} onChange={e => setCascade(e.target.checked)} />Apply to their whole team</label>
      <input className="inp" placeholder="Find a manager" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 240, marginLeft: 'auto' }} />
    </div>
    <div className="panel" style={{ padding: '8px 12px' }}><div className="tw scroll" style={{ maxHeight: 560 }}><table>
      <thead><tr><th>Manager</th><th>Grade</th><th className="num">Team Below</th><th style={{ minWidth: 200 }}>Unit</th><th>Region</th></tr></thead>
      <tbody>{shown.map(({ s, depth, team }) => <tr key={s.code}>
        <td style={{ paddingLeft: 10 + (ql ? 0 : depth * 22) }}>{depth > 0 && !ql && <span style={{ color: 'var(--ink-3)', marginRight: 6 }}>└</span>}<b>{s.name}</b>{s.is_head && <span className="pill p-ok" style={{ marginLeft: 6 }}>Function head</span>}<div className="formula" style={{ paddingLeft: depth > 0 && !ql ? 16 : 0 }}>{s.position}</div></td>
        <td style={{ whiteSpace: 'nowrap' }}>{s.grade}</td><td className="num">{team ? fmt(team) : ''}</td>
        <td>{s.is_head ? <span className="formula">All units (function head)</span> : <><EditField value={s.unit} list="dl-unit" onCommit={v => set(s.code, { unit: v })} style={{ width: '100%' }} />{s.unit_source && <div className="formula">{src(s.unit_source)}</div>}</>}</td>
        <td><RegionSelect value={s.region} regions={regions} onChange={v => set(s.code, { region: v })} />{s.region_source && <div className="formula">{src(s.region_source)}</div>}</td>
      </tr>)}
        {!shown.length && <tr><td colSpan={5} className="formula">No managers found.</td></tr>}</tbody></table></div></div>
  </>
}

const RoleSelect = ({ value, onChange }) => <select value={value || ''} onChange={e => onChange(e.target.value)} style={value ? { color: TYPE_COL[value], fontWeight: 650 } : null}>
  {!value && <option value="">Select</option>}{ROLES.map(r => <option key={r} value={r}>{r}</option>)}</select>

const RegionSelect = ({ value, regions, onChange }) => <select value={value || ''} onChange={e => onChange(e.target.value)}>
  {!value && <option value="">Select a region</option>}{regions.map(r => <option key={r}>{r}</option>)}{value && !regions.includes(value) && <option>{value}</option>}</select>

function Everyone({ data, call, fid, notify, regions, onLine }) {
  const [q, setQ] = useState('')
  const [show, setShow] = useState('')
  const [et, setEt] = useState('')
  const [bulkRole, setBulkRole] = useState('Service')
  const [bulkType, setBulkType] = useState('FTE')
  const [picked, setPicked] = useState(() => new Set())
  const [bulk, setBulk] = useState(regions[0] || '')
  const [bulkUnit, setBulkUnit] = useState('')
  const ql = q.trim().toLowerCase()
  const rows = data.staff.filter(s => (show === '' || (show === 'none' ? !s.region : show === 'nounit' ? !s.unit && !s.is_head : show === 'norole' ? !s.service_role : s.region === show)) && (!et || s.emp_type === et) && (!ql || (s.name + ' ' + s.code + ' ' + s.position).toLowerCase().includes(ql)))
  const counts = {}; data.staff.forEach(s => { const k = s.region || ''; counts[k] = (counts[k] || 0) + 1 })
  const VAL = { unit: () => bulkUnit.trim(), region: () => bulk, role: () => bulkRole, type: () => bulkType }
  const KEY = { unit: 'unit', region: 'region', role: 'service_role', type: 'emp_type' }
  const NAME = { unit: 'unit', region: 'region', role: 'service or support', type: 'type' }
  // who: 'ticked', 'shown' (the filtered list), 'empty' (not yet set) or 'all'
  const apply = async (what, who) => {
    const v = VAL[what]()
    const codes = who === 'ticked' ? [...picked] : who === 'shown' ? rows.map(s => s.code) : []
    const n = who === 'ticked' ? picked.size : who === 'shown' ? rows.length : who === 'empty' ? empty[what] : data.staff.length
    if ((who === 'all' || who === 'shown') && !confirm(`Set the ${NAME[what]} of ${fmt(n)} employees to ${v}? Values already set for them are replaced.`)) return
    const d = await call(`/api/capture/${fid}/regions`, 'POST', { [KEY[what]]: v, codes, only_empty: who === 'empty' })
    if (d) { notify(`${fmt(d.updated)} ${d.updated === 1 ? 'employee' : 'employees'} set to ${v}.`); setPicked(new Set()) }
  }
  const noUnit = data.staff.filter(s => !s.unit && !s.is_head).length, noRole = data.staff.filter(s => !s.service_role).length
  const empty = { unit: noUnit, region: counts[''] || 0, role: noRole }
  const nF = data.staff.filter(s => s.emp_type === 'FTE').length
  const vis = rows.slice(0, 400)
  const filtered = rows.length !== data.staff.length
  const row = ({ what, label, control, emptyLabel }) => { const ok = !!VAL[what]()
    return <div className="bulkrow" key={what}><b>{label}</b>{control}
      <button type="button" className="btn pri" onClick={() => apply(what, 'ticked')} disabled={!ok || !picked.size}>Ticked ({fmt(picked.size)})</button>
      {filtered && <button type="button" className="btn" onClick={() => apply(what, 'shown')} disabled={!ok || !rows.length}>Shown in the list ({fmt(rows.length)})</button>}
      {emptyLabel && <button type="button" className="btn" onClick={() => apply(what, 'empty')} disabled={!ok || !empty[what]}>{emptyLabel} ({fmt(empty[what])})</button>}
      <button type="button" className="btn" onClick={() => apply(what, 'all')} disabled={!ok}>Everyone ({fmt(data.staff.length)})</button></div> }
  return <>
    <div className="panel bulkpanel" style={{ marginBottom: 12 }}>
      <div className="rhead" style={{ marginBottom: 6 }}><div><h3>Set for Several Employees at Once</h3><p className="sub" style={{ margin: 0 }}>Choose a value, then who it applies to: the employees ticked in the list, everyone shown by the filters below, everyone not yet set, or the whole function. Anyone can still be changed individually afterwards.</p></div></div>
      {row({ what: 'unit', label: 'Unit', emptyLabel: 'Without a unit', control: <input className="inp" list="dl-unit" value={bulkUnit} onChange={e => setBulkUnit(e.target.value)} placeholder="Type or pick a unit" /> })}
      {row({ what: 'region', label: 'Region', emptyLabel: 'Without a region', control: <select value={bulk} onChange={e => setBulk(e.target.value)}>{regions.map(x => <option key={x}>{x}</option>)}</select> })}
      {row({ what: 'role', label: 'Service / Support', emptyLabel: 'Not yet marked', control: <span className="seg sm">{ROLES.map(r => <button key={r} type="button" aria-pressed={bulkRole === r} onClick={() => setBulkRole(r)}>{r}</button>)}</span> })}
      {row({ what: 'type', label: 'Type', control: <span className="seg sm">{['FTE', 'FTC'].map(r => <button key={r} type="button" aria-pressed={bulkType === r} onClick={() => setBulkType(r)}>{r}</button>)}</span> })}
      <div className="formula" style={{ marginTop: 8 }}>{Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k || 'Region not set'}: ${fmt(v)}`).join(' · ')} · Service {fmt(data.staff.filter(s => s.service_role === 'Service').length)} · Support {fmt(data.staff.filter(s => s.service_role === 'Support').length)} · not marked {fmt(noRole)}</div>
    </div>
    <div className="kvline">
      <select value={show} onChange={e => setShow(e.target.value)}><option value="">All employees ({fmt(data.staff.length)})</option><option value="nounit">Without a unit ({fmt(noUnit)})</option><option value="none">Without a region ({fmt(counts[''] || 0)})</option><option value="norole">Not marked service / support ({fmt(noRole)})</option>
        {Object.keys(counts).filter(Boolean).sort().map(r => <option key={r} value={r}>{r} ({fmt(counts[r])})</option>)}</select>
      <span className="seg" role="group" aria-label="FTE or FTC"><button type="button" aria-pressed={!et} onClick={() => setEt('')}>All</button><button type="button" aria-pressed={et === 'FTE'} onClick={() => setEt('FTE')}>FTE ({fmt(nF)})</button><button type="button" aria-pressed={et === 'FTC'} onClick={() => setEt('FTC')}>FTC ({fmt(data.staff.length - nF)})</button></span>
      <input className="inp" placeholder="Filter by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 260 }} />
    </div>
    <div className="panel" style={{ padding: '8px 12px' }}><div className="tw scroll" style={{ maxHeight: 520 }}><table>
      <thead><tr><th><input type="checkbox" aria-label="Select all shown" checked={vis.length > 0 && vis.every(s => picked.has(s.code))} onChange={e => setPicked(e.target.checked ? new Set(vis.map(s => s.code)) : new Set())} /></th>
        <th>Name</th><th>Code</th><th>Grade</th><th>Type</th><th>Manager</th><th style={{ minWidth: 190 }}>Unit</th><th>Region</th><th>Service / Support</th></tr></thead>
      <tbody>{vis.map(s => <tr key={s.code}>
        <td><input type="checkbox" checked={picked.has(s.code)} onChange={() => setPicked(p => { const n = new Set(p); n.has(s.code) ? n.delete(s.code) : n.add(s.code); return n })} aria-label={`Select ${s.name}`} /></td>
        <td>{s.name} {!s.verified && <span className="pill p-warn">Pending verification</span>}<div className="formula">{s.position}</div></td><td>{s.code}</td><td>{s.grade}</td>
        <td style={{ whiteSpace: 'nowrap' }}><Dot fte={s.emp_type === 'FTE'} />{s.emp_type}</td>
        <td>{s.manager_name}{!s.is_head && <div><button type="button" className="linkbtn" onClick={() => onLine(s)}>{(data.requests || []).some(r => r.kind === 'manager' && r.code === s.code) ? 'Change requested' : 'Request change'}</button></div>}</td>
        <td>{s.is_head ? <span className="formula">All units (function head)</span> : <EditField value={s.unit} list="dl-unit" onCommit={v => call(`/api/capture/${fid}/staff/${encodeURIComponent(s.code)}`, 'PATCH', { unit: v })} style={{ width: '100%' }} />}</td>
        <td><RegionSelect value={s.region} regions={regions} onChange={v => call(`/api/capture/${fid}/staff/${encodeURIComponent(s.code)}`, 'PATCH', { region: v })} /></td>
        <td><RoleSelect value={s.service_role} onChange={v => call(`/api/capture/${fid}/staff/${encodeURIComponent(s.code)}`, 'PATCH', { service_role: v })} /></td>
      </tr>)}
        {rows.length > 400 && <tr><td colSpan={9} className="formula">Showing 400 of {fmt(rows.length)}. Use the filter to find someone.</td></tr>}
        {!rows.length && <tr><td colSpan={9} className="formula">No one matches.</td></tr>}</tbody></table></div></div>
  </>
}

// A POC asks for an employee's reporting line to change; the admin approves it in Admin, Requests.
function ManagerRequest({ emp, data, call, fid, notify, close }) {
  const [q, setQ] = useState('')
  const [code, setCode] = useState('')
  const [note, setNote] = useState('')
  const ql = q.trim().toLowerCase()
  const below = useMemo(() => {   // the employee's own team cannot become their manager
    const kids = new Map(); data.staff.forEach(s => { if (s.manager_code) { if (!kids.has(s.manager_code)) kids.set(s.manager_code, []); kids.get(s.manager_code).push(s.code) } })
    const out = new Set([emp.code]); const st = [emp.code]; while (st.length) (kids.get(st.pop()) || []).forEach(k => { if (!out.has(k)) { out.add(k); st.push(k) } })
    return out
  }, [data, emp.code])
  const pool = data.staff.filter(s => !below.has(s.code) && s.code !== emp.manager_code && (!ql || (s.name + ' ' + s.code + ' ' + s.position).toLowerCase().includes(ql)))
    .sort((a, b) => (b.grade_rank || 0) - (a.grade_rank || 0) || a.name.localeCompare(b.name))
  const picked = data.staff.find(s => s.code === code)
  const send = async () => {
    const d = await call(`/api/capture/${fid}/manager-request`, 'POST', { code: emp.code, manager_code: code.trim(), note })
    if (d) { notify('Request sent to the admin for approval.'); close() }
  }
  return <Modal title={`Change ${emp.name}'s reporting line`} sub={`Reports to ${emp.manager_name || 'no one'} today. The change takes effect when the admin approves it.`} onClose={close}>
    <b className="fl">New manager</b>
    {picked ? <div className="chosen" style={{ margin: '6px 0 12px' }}><span><b>{picked.name}</b><small>{[picked.position, picked.grade, picked.code].filter(Boolean).join(' · ')}</small></span><button className="linkbtn" onClick={() => setCode('')}>Change</button></div> : <>
      <input className="inp" placeholder="Find by name, code or position" value={q} onChange={e => setQ(e.target.value)} style={{ width: '100%', margin: '6px 0' }} autoFocus />
      <div className="pick" style={{ maxHeight: 260 }}>{pool.slice(0, 150).map(s => <button key={s.code} type="button" onClick={() => setCode(s.code)}><span><b>{s.name}</b><small>{[s.position, s.grade, s.code].filter(Boolean).join(' · ')}</small></span></button>)}
        {!pool.length && <div className="formula" style={{ padding: 8 }}>No one in this function matches. For a manager in another function, enter their employee code below.</div>}</div>
      <div className="kvline" style={{ margin: '10px 0 12px' }}><span className="formula">Manager in another function: employee code</span><input className="inp" style={{ width: 150 }} value={code} onChange={e => setCode(e.target.value)} /></div></>}
    <b className="fl">Reason (optional)</b>
    <input className="inp" value={note} onChange={e => setNote(e.target.value)} maxLength={300} style={{ width: '100%', marginTop: 6 }} />
    <div className="row-actions" style={{ marginTop: 16 }}><button type="button" className="btn pri" disabled={!code.trim()} onClick={send}>Send for approval</button><button type="button" className="btn" onClick={close}>Cancel</button></div>
  </Modal>
}

function AddEmployee({ call, fid, regions }) {
  const blank = { code: '', name: '', emp_type: 'FTE', position: '', grade: '', region: '', unit: '', manager_code: '' }
  const [f, setF] = useState(blank)
  const [res, setRes] = useState(null)
  const set = (k, v) => { setF(s => ({ ...s, [k]: v })); setRes(null) }
  const add = async () => { const d = await call(`/api/capture/${fid}/employees`, 'POST', { ...f, region: f.region || null, manager_code: f.manager_code || null }); if (d) { setRes({ result: 'added' }); setF(blank) } }
  const check = async () => {
    if (!f.code.trim()) { setRes({ result: 'error', msg: 'Enter the employee code. It is the key used to avoid duplicates.' }); return }
    const r = await call(`/api/capture/${fid}/check-employee`, 'POST', { code: f.code, name: f.name })
    if (!r) return
    if (r.result === 'new') { if (!f.name.trim()) { setRes({ result: 'error', msg: 'Code not found anywhere. Enter the full name to add them for verification.' }); return } await add() }
    else setRes(r)
  }
  return <div className="addbox">
    <h2 style={{ fontSize: 15 }}>Add an Employee Missing from your List</h2>
    <p className="formula" style={{ margin: '2px 0 10px' }}>The code is checked against every function first, so no one is counted twice. New employees are marked for verification by the admin.</p>
    <div className="fields">
      <input className="inp" placeholder="Employee code" style={{ width: 150 }} value={f.code} onChange={e => set('code', e.target.value)} />
      <input className="inp" placeholder="Full name" style={{ flex: 1, minWidth: 180 }} value={f.name} onChange={e => set('name', e.target.value)} />
      <input className="inp" placeholder="Position (optional)" style={{ flex: 1, minWidth: 160 }} value={f.position} onChange={e => set('position', e.target.value)} />
      <input className="inp" placeholder="Grade (optional)" style={{ width: 130 }} value={f.grade} onChange={e => set('grade', e.target.value)} />
      <input className="inp" placeholder="Manager's code (optional)" style={{ width: 190 }} value={f.manager_code} onChange={e => set('manager_code', e.target.value)} />
      <input className="inp" placeholder="Unit" list="dl-unit" style={{ width: 180 }} value={f.unit} onChange={e => set('unit', e.target.value)} />
      <select value={f.region} onChange={e => set('region', e.target.value)}><option value="">Region</option>{regions.map(r => <option key={r}>{r}</option>)}</select>
      <select value={f.emp_type} onChange={e => set('emp_type', e.target.value)}><option value="FTE">FTE</option><option value="FTC">FTC</option></select>
      <button type="button" className="btn pri" onClick={check}>Check and add</button>
    </div>
    {res?.result === 'error' && <div className="msg bad">{res.msg}</div>}
    {res?.result === 'added' && <div className="msg ok">Added and marked as pending verification.</div>}
    {res?.result === 'same_function' && <div className="msg ok"><b>{res.employee.name} ({res.employee.code})</b> is already in your function.</div>}
    {res?.result === 'other_function' && <div className="msg bad"><b>Not added: this would duplicate the employee.</b> {res.employee.name} ({res.employee.code}, {res.employee.grade}) is tagged to <b>{res.employee.function}</b>{res.employee.manager ? `, reporting to ${res.employee.manager}` : ''}.
      {res.pending ? <div style={{ marginTop: 8 }}>A re-tagging request is already waiting for the admin.</div> :
        <div className="acts"><button type="button" className="btn pri" onClick={async () => { const d = await call(`/api/capture/${fid}/retag`, 'POST', { code: res.employee.code }); if (d) setRes({ ...res, pending: true }) }}>Request re-tagging to my function</button>
          <button type="button" className="btn" onClick={() => setRes(null)}>They belong there, cancel</button></div>}</div>}
    {res?.result === 'similar' && <div className="msg warn"><b>Code {f.code} is new, but similar names already exist:</b> {res.similar.map(s => `${s.name} (${s.code}, ${s.function})`).join('; ')}. Check that the code is not a typo.
      <div className="acts"><button type="button" className="btn pri" onClick={add}>It is a different person, add</button></div></div>}
  </div>
}

// ================================================================== step 2: activities
function Activities({ data, setData, call, notify, fid, current, setCurrent, locked, reload, lookups, showLine }) {
  const [q, setQ] = useState('')
  const [show, setShow] = useState('')
  const [et, setEt] = useState('')
  const [items, setItems] = useState(null)
  const [dialog, setDialog] = useState(null)
  const [view, setView] = useState(() => { try { return localStorage.getItem('ops_capture_view') || 'cards' } catch { return 'cards' } })
  useEffect(() => { try { localStorage.setItem('ops_capture_view', view) } catch {} }, [view])
  const listRef = useRef(null)
  const staff = data.staff
  const emp = staff.find(s => s.code === current) || null
  useEffect(() => { if (!current && staff.length) setCurrent((staff.find(s => !s.is_head) || staff[0]).code) }, [])
  const loadItems = code => { setItems(null); api(`/api/capture/${fid}/staff/${encodeURIComponent(code)}/items`).then(r => setItems(r.items)).catch(e => notify(e.message, true)) }
  useEffect(() => { if (current) loadItems(current) }, [current])

  const ql = q.trim().toLowerCase()
  const list = staff.filter(s => (show === '' || (show === 'none' ? !s.activities : show === 'incomplete' ? s.incomplete > 0 : show === 'done' ? s.activities && !s.incomplete : show === 'norole' ? !s.service_role : s.region === show)) && (!et || s.emp_type === et) &&
    (!ql || (s.name + ' ' + s.code + ' ' + s.position).toLowerCase().includes(ql)))
  const regions = [...new Set(staff.map(s => s.region).filter(Boolean))].sort()

  const updEmp = e => setData(d => ({ ...d, staff: d.staff.map(s => s.code === e.code ? { ...s, ...e } : s) }))
  const addSug = (item) => setData(d => {
    const s = { ...d.suggestions }
    ;[['units', 'unit'], ['products', 'product'], ['processes', 'process'], ['channels', 'channel'], ['categories', 'category']].forEach(([k, f]) => {
      const v = (item[f] || '').trim(); if (v && !s[k].includes(v)) s[k] = [...s[k], v].sort((a, b) => a.localeCompare(b)) })
    return { ...d, suggestions: s }
  })
  const save = async (id, body) => {
    try {
      const r = await api(`/api/capture/items/${id}`, { method: 'PATCH', body })
      setItems(xs => xs.map(x => x.id === id ? r.item : x)); updEmp(r.employee); addSug(r.item)
      if (data.function.status === 'Not started') setData(d => ({ ...d, function: { ...d.function, status: 'In progress' } }))
      return r
    } catch (e) { notify(e.message, true) }
  }
  const add = async (body = {}) => {
    try {
      const r = await api(`/api/capture/${fid}/staff/${encodeURIComponent(current)}/items`, { method: 'POST', body })
      setItems(xs => [...xs, r.item]); updEmp(r.employee)
      setTimeout(() => document.getElementById('act-' + r.item.id)?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 60)
    } catch (e) { notify(e.message, true) }
  }
  const remove = async id => {
    if (!confirm('Remove this activity?')) return
    try { const r = await api(`/api/capture/items/${id}`, { method: 'DELETE' }); setItems(xs => xs.filter(x => x.id !== id)); updEmp(r.employee) } catch (e) { notify(e.message, true) }
  }
  const duplicate = async id => {
    try { const r = await api(`/api/capture/items/${id}/duplicate`, { method: 'POST' }); setItems(xs => [...xs, r.item]); updEmp(r.employee); notify('Activity duplicated. Change the product, channel or volume as needed.') } catch (e) { notify(e.message, true) }
  }
  const sync = async it => {
    if (!confirm(`Apply this activity's details (everything except volumes) to the ${it.linked} colleague${it.linked === 1 ? '' : 's'} with the same activity?`)) return
    try { const r = await api(`/api/capture/items/${it.id}/sync`, { method: 'POST' }); notify(`Updated ${r.updated} colleague${r.updated === 1 ? '' : 's'}.`); reload() } catch (e) { notify(e.message, true) }
  }
  const after = () => { reload(); if (current) loadItems(current) }
  const setRole = async v => { const d = await call(`/api/capture/${fid}/staff/${encodeURIComponent(current)}`, 'PATCH', { service_role: v }); if (d) notify(`${emp.name} marked as ${v.toLowerCase()} employee.`) }
  const ph = data.settings.productive_hours

  return <div className="capgrid">
    <div className="stafflist">
      <input className="inp" placeholder="Find an employee" value={q} onChange={e => setQ(e.target.value)} style={{ width: '100%' }} />
      <span className="seg full" role="group" aria-label="FTE or FTC" style={{ marginTop: 8 }}><button type="button" aria-pressed={!et} onClick={() => setEt('')}>All</button><button type="button" aria-pressed={et === 'FTE'} onClick={() => setEt('FTE')}>FTE</button><button type="button" aria-pressed={et === 'FTC'} onClick={() => setEt('FTC')}>FTC</button></span>
      <select value={show} onChange={e => setShow(e.target.value)} style={{ width: '100%', margin: '8px 0' }}>
        <option value="">All employees ({fmt(staff.length)})</option>
        <option value="none">No activities yet ({fmt(staff.filter(s => !s.activities).length)})</option>
        <option value="incomplete">Missing details ({fmt(staff.filter(s => s.incomplete).length)})</option>
        <option value="done">Complete ({fmt(staff.filter(s => s.activities && !s.incomplete).length)})</option>
        <option value="norole">Service / support not set ({fmt(staff.filter(s => !s.service_role).length)})</option>
        {regions.map(r => <option key={r} value={r}>{r}</option>)}
      </select>
      <div className="slist" ref={listRef}>{list.slice(0, 600).map(s => <button key={s.code} aria-current={s.code === current} onClick={() => setCurrent(s.code)}>
        <span className="sn"><b>{s.name}</b><small>{s.is_head ? 'Function head · ' : ''}{s.grade} · {s.emp_type} · {[s.is_head ? 'All units' : s.unit, s.region || 'No region'].filter(Boolean).join(' · ')}</small></span>
        <span className="sb">{s.activities ? <><em className={s.incomplete ? 'warn' : ''}>{s.activities}</em>{prefs.showTime && <small>{s.daily_hours.toFixed(1)} h</small>}</> : null}</span></button>)}
        {list.length > 600 && <div className="formula" style={{ padding: 8 }}>Showing 600 of {fmt(list.length)}. Search to narrow down.</div>}
        {!list.length && <div className="formula" style={{ padding: 8 }}>No one matches.</div>}</div>
    </div>
    <div className="editor">
      {!emp ? <div className="empty">Select an employee on the left.</div> : <>
        <div className="emphead">
          <div><h2>{emp.name}</h2><div className="formula">{[emp.position, emp.grade, emp.code].filter(Boolean).join(' · ')} · <Dot fte={emp.emp_type === 'FTE'} />{emp.emp_type}{emp.is_head ? ' · All units' : emp.unit ? ` · Unit: ${emp.unit}` : ''} · Region: {emp.region || <b style={{ color: 'var(--amber)' }}>not set (step 1)</b>}{emp.is_head ? ' · Function head (activities optional)' : ''}</div>
            <div className="rolepick"><span>Type of work<em>*</em></span><Seg value={emp.service_role || ''} options={ROLES} onChange={v => setRole(v)} tone={o => TYPE_COL[o]} />
              {!emp.service_role && <span className="formula">Select service or support for {emp.name.split(' ')[0]}</span>}</div>
            {showLine && <button type="button" className="linkbtn" style={{ marginTop: 4 }} onClick={() => showLine(emp.code)}>View reporting line</button>}</div>
          {!prefs.showTime ? <div className="kv"><div><b>{emp.activities}</b><span>Activities</span></div>
            <div><b>{new Set((items || []).map(w => w.category || '')).size}</b><span>Categories</span></div></div> : <div className="kv">
            <div><b>{emp.activities}</b><span>Activities</span></div>
            <div><b>{emp.daily_hours.toFixed(1)}</b><span>Man-hours a day</span></div>
            <div><b style={{ color: emp.activities ? utilTone(emp.utilisation) : undefined }}>{Math.round(emp.utilisation)}%</b><span>Utilisation at {ph} h</span></div>
            <div><b>{Math.round(emp.peak_utilisation)}%</b><span>Peak day</span></div>
          </div>}
        </div>
        {!locked && <div className="kvline toolbar">
          <span className="seg" role="group" aria-label="View"><button type="button" aria-pressed={view === 'cards'} onClick={() => setView('cards')}>Form</button><button type="button" aria-pressed={view === 'table'} onClick={() => setView('table')}>Table</button></span>
          <button type="button" className="btn pri" onClick={() => add()}>Add activity</button>
          <button type="button" className="btn" disabled={!items?.length} onClick={() => setDialog({ kind: 'to' })}>Copy these activities to colleagues</button>
          <button type="button" className="btn" onClick={() => setDialog({ kind: 'from' })}>Copy activities from a colleague</button>
          <button type="button" className="btn" onClick={() => setDialog({ kind: 'clear' })}>Remove activities</button>
          <span style={{ marginLeft: 'auto' }} className="row-actions">
            <button type="button" className="btn" onClick={() => download(`/api/capture/${fid}/template`, 'template.xlsx').catch(e => notify(e.message, true))} title="All employees of the function with their activities, to fill in Excel">Excel template</button>
            <button type="button" className="btn" onClick={() => setDialog({ kind: 'upload' })}>Upload filled template</button></span>
        </div>}
        <Datalists s={data.suggestions} />
        {!items ? <div className="loading">Loading…</div> : !items.length ? <div className="empty"><b>No activities recorded for {emp.name} yet.</b><br />Add the first activity, or copy the activities of a colleague who does the same work.
          {!locked && <div className="row-actions" style={{ justifyContent: 'center', marginTop: 12 }}><button className="btn pri" onClick={() => add()}>Add activity</button><button className="btn" onClick={() => setDialog({ kind: 'from' })}>Copy from a colleague</button></div>}</div>
          : view === 'table' ? <ActivityGrid items={items} save={save} remove={remove} duplicate={duplicate} cfg={data.fields} locked={locked} />
          : items.map((it, i) => <ActivityCard key={it.id} n={i + 1} it={it} save={save} remove={remove} duplicate={duplicate} sync={sync} settings={data.settings} cfg={data.fields}
            openLinked={() => setDialog({ kind: 'linked', item: it })} locked={locked} />)}
        {!locked && items?.length > 0 && <button type="button" className="btn pri" style={{ marginTop: 4 }} onClick={() => add()}>Add another activity</button>}
      </>}
    </div>
    {dialog?.kind === 'to' && <CopyDialog mode="to" data={data} fid={fid} source={emp} items={items} notify={notify} lookups={lookups} close={() => setDialog(null)} done={after} />}
    {dialog?.kind === 'from' && <CopyDialog mode="from" data={data} fid={fid} target={emp} notify={notify} lookups={lookups} close={() => setDialog(null)} done={after} />}
    {dialog?.kind === 'clear' && <ClearDialog data={data} fid={fid} current={emp} notify={notify} close={() => setDialog(null)} done={after} />}
    {dialog?.kind === 'upload' && <UploadDialog fid={fid} data={data} notify={notify} close={() => setDialog(null)} done={after} />}
    {dialog?.kind === 'linked' && <LinkedDialog item={dialog.item} notify={notify} locked={locked} close={() => setDialog(null)} done={after} />}
  </div>
}

const Datalists = ({ s }) => <>{[['products', 'dl-product'], ['processes', 'dl-process'], ['channels', 'dl-channel'], ['categories', 'dl-category']].map(([k, id]) =>
  <datalist key={id} id={id}>{(s[k] || []).map(v => <option key={v} value={v} />)}</datalist>)}</>

// number field: empty means "not entered"
function NumField({ value, onCommit, ...rest }) {
  const [v, setV] = useState(value ?? '')
  useEffect(() => { setV(value ?? '') }, [value])
  const commit = () => { const s = String(v).trim(); const nv = s === '' ? null : Number(s); if (nv !== null && (isNaN(nv) || nv < 0)) { setV(value ?? ''); return } if (nv !== (value ?? null)) onCommit(nv) }
  return <input className="inp" type="number" min="0" step="any" inputMode="decimal" value={v} onChange={e => setV(e.target.value)} onBlur={commit} onKeyDown={e => { if (e.key === 'Enter') e.target.blur() }} {...rest} />
}

const Field = ({ label, req, hint, span, children, miss }) => <label className={'fld' + (miss ? ' miss' : '')} style={{ gridColumn: `span ${span}` }}>
  <span className="fl" title={label}>{label}{req && <em>*</em>}</span>{children}{hint && <span className="fh">{hint}</span>}</label>

function Seg({ value, options, onChange, tone }) {
  return <span className="toggle wide" role="group">{options.map(o => <button key={o} type="button" aria-pressed={value === o} onClick={() => value !== o && onChange(o)}
    style={value === o && tone ? { background: tone(o) } : null}>{o}</button>)}</span>
}

// several products on one activity, stored as "LC; Guarantee"
function ProductTags({ value, onCommit, disabled }) {
  const tags = (value || '').split(';').map(x => x.trim()).filter(Boolean)
  const [t, setT] = useState('')
  const add = () => { const v = t.trim().replace(/[;,]+$/, ''); setT(''); if (v && !tags.some(x => x.toLowerCase() === v.toLowerCase())) onCommit([...tags, v].join('; ')) }
  return <div className="tags-in">
    {tags.map(x => <span key={x} className="tagchip">{x}{!disabled && <button type="button" aria-label={`Remove ${x}`} onClick={() => onCommit(tags.filter(y => y !== x).join('; '))}>×</button>}</span>)}
    {!disabled && <input list="dl-product" value={t} onChange={e => { const v = e.target.value; if (/[;,]$/.test(v)) { setT(v); setTimeout(add, 0) } else setT(v) }}
      onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); add() } if (e.key === 'Backspace' && !t && tags.length) onCommit(tags.slice(0, -1).join('; ')) }}
      onBlur={add} placeholder={tags.length ? 'Add another' : 'Type and press Enter'} />}
  </div>
}

const spans = (keys, total = 12) => { const n = keys.length; if (!n) return {}; const base = Math.floor(total / n); const out = {}; keys.forEach((k, i) => { out[k] = base + (i < total - base * n ? 1 : 0) }); return out }

function ActivityCard({ n, it, save, remove, duplicate, sync, settings, openLinked, locked, cfg }) {
  const num = (f, v) => save(it.id, v === null ? { clear: [f] } : { [f]: v })
  const txt = f => v => save(it.id, { [f]: v })
  const days = settings.days[it.frequency] || 1
  const show = f => cfg[f] !== 'hidden', req = f => cfg[f] === 'required'
  const rowA = ['product', 'process', 'channel'].filter(show), sa = spans(rowA)
  const rowC = ['frequency', 'volume', ...(show('volume') ? ['vtype'] : []), ...(show('peak') ? ['peak_som', 'peak_eom'] : [])].filter(f => f.startsWith('peak') || f === 'vtype' || show(f))
  const sc = !rowC.includes('vtype') ? spans(rowC) : rowC.length === 5 ? { frequency: 2, volume: 3, vtype: 3, peak_som: 2, peak_eom: 2 } : { ...spans(rowC.filter(f => f !== 'vtype'), 8), vtype: 4 }
  const vtOpts = [L('vol.txn'), L('vol.file')]
  const calc = show('volume') && show('minutes')
  const rowD = ['handling', 'minutes', ...(calc ? ['total'] : []), 'automation'].filter(f => f === 'total' || show(f)), sd = spans(rowD)
  const descSpan = show('category') ? 8 : 12, catSpan = show('description') ? 4 : 12
  return <article className="actcard" id={'act-' + it.id}>
    <header>
      <span className="an">{n}</span>
      <b className="at">{it.category || it.process || <span className="formula">New activity: add the details below</span>}</b>
      {prefs.showTime && <span className="ah"><b>{it.daily_hours.toFixed(2)}</b> man-hours a day</span>}
      {!locked && <span className="row-actions"><button type="button" className="btn" onClick={() => duplicate(it.id)} title="Add a copy of this activity for the same employee">Duplicate</button>
        <button type="button" className="btn" onClick={() => remove(it.id)} aria-label="Remove activity">Remove</button></span>}
    </header>
    <div className="fgrid">
      {show('product') && <Field label="Products" req={req('product')} span={sa.product} hint="One or more; press Enter after each"><ProductTags value={it.product} onCommit={txt('product')} disabled={locked} /></Field>}
      {show('process') && <Field label="Process name" req={req('process')} span={sa.process}><EditField value={it.process} list="dl-process" onCommit={txt('process')} /></Field>}
      {show('channel') && <Field label="Channel" req={req('channel')} span={sa.channel}><EditField value={it.channel} list="dl-channel" onCommit={txt('channel')} /></Field>}
      {show('description') && <Field label="Activity description" req={req('description')} span={descSpan}><EditField multiline value={it.description} onCommit={txt('description')} rows={3} /></Field>}
      {show('category') && <Field label="Activity category" req={req('category')} span={catSpan} hint="A one-line summary of the description. Earlier entries are suggested as you type.">
        <EditField value={it.category} list="dl-category" onCommit={txt('category')} /></Field>}
      {show('frequency') && <Field label="Frequency" req={req('frequency')} span={sc.frequency}><select value={it.frequency} onChange={e => save(it.id, { frequency: e.target.value })}>{FREQ.map(f => <option key={f}>{f}</option>)}</select></Field>}
      {show('volume') && <Field label={`Avg volume per ${PER[it.frequency]}`} req={req('volume')} span={sc.volume}><NumField value={it.volume} onCommit={v => num('volume', v)} /></Field>}
      {show('volume') && <Field label="Volume type" span={sc.vtype}>
        <Seg value={it.volume_type === VOL_FILE ? vtOpts[1] : it.volume != null ? vtOpts[0] : ''} options={vtOpts} onChange={v => save(it.id, { volume_type: v === vtOpts[1] ? VOL_FILE : '' })} /></Field>}
      {show('peak') && <Field label="Peak: start of month" span={sc.peak_som} hint="Avg per day"><NumField value={it.peak_som} onCommit={v => num('peak_som', v)} /></Field>}
      {show('peak') && <Field label="Peak: end of month" span={sc.peak_eom} hint="Avg per day"><NumField value={it.peak_eom} onCommit={v => num('peak_eom', v)} /></Field>}
      {show('handling') && <Field label={prefs.nature.label} req={req('handling')} span={sd.handling}><Seg value={it.handling} options={prefs.nature.options} onChange={v => save(it.id, { handling: v })} /></Field>}
      {show('minutes') && <Field label="Employee processing time (min)" req={req('minutes')} span={sd.minutes} hint="Per item"><NumField value={it.minutes} onCommit={v => num('minutes', v)} /></Field>}
      {calc && <Field label="Total employee processing time (min)" span={sd.total} hint={`Processing time × volume, per ${PER[it.frequency]}`}><output className="calc">{fmt(it.total_minutes)}</output></Field>}
      {show('automation') && <Field label="Automation opportunity" req={req('automation')} span={sd.automation}><Seg value={it.automation} options={['Yes', 'No']} onChange={v => save(it.id, { automation: v })} /></Field>}
    </div>
    <footer>
      {prefs.showTime && <span className="formula">{it.minutes && it.volume ? <>{fmt(it.minutes)} min × {num2(it.volume)} = {fmt(it.total_minutes)} min per {PER[it.frequency]}{days > 1 ? ` ÷ ${days} working days` : ''} = <b>{it.daily_hours.toFixed(2)} man-hours a day</b>
        {(it.peak_som !== null || it.peak_eom !== null) && <> · peak day {it.peak_som_hours.toFixed(1)} h (start) / {it.peak_eom_hours.toFixed(1)} h (end of month)</>}</> : calc ? 'Man-hours are calculated when the processing time and volume are entered; leave them blank if they do not apply.' : 'Man-hours are not calculated: volume or processing time is not used by this function.'}</span>}
      {it.missing?.length > 0 && <span className="pill p-warn">Missing: {it.missing.join(', ')}</span>}
      {it.linked > 0 && <span className="linked">Same activity recorded for {it.linked} colleague{it.linked === 1 ? '' : 's'}
        <button type="button" className="linkbtn" onClick={openLinked}>Compare and set volumes</button>
        {!locked && <button type="button" className="linkbtn" onClick={() => sync(it)}>Apply these details to all</button>}</span>}
    </footer>
  </article>
}

// Excel-like table of the employee's activities, edited in place
const COLS = [['product', 'Products', 160], ['process', 'Process name', 150], ['channel', 'Channel', 120], ['description', 'Activity description', 260],
  ['category', 'Activity category', 190], ['frequency', 'Frequency', 110], ['volume', 'Avg volume', 90], ['volume_type', 'Volume type', 120],
  ['peak_som', 'Peak start of month', 90], ['peak_eom', 'Peak end of month', 90], ['handling', prefs.nature.label, 150], ['minutes', 'Time (min)', 80], ['automation', 'Automation', 90]]

function ActivityGrid({ items, save, remove, duplicate, cfg, locked }) {
  const vis = COLS.filter(([f]) => cfg[f.startsWith('peak') ? 'peak' : f === 'volume_type' ? 'volume' : f] !== 'hidden')
  const num = (it, f, v) => save(it.id, v === null ? { clear: [f] } : { [f]: v })
  const cell = (it, f) => {
    if (f === 'frequency') return <select value={it.frequency} onChange={e => save(it.id, { frequency: e.target.value })}>{FREQ.map(x => <option key={x}>{x}</option>)}</select>
    if (f === 'handling') return <select value={it.handling} onChange={e => save(it.id, { handling: e.target.value })}><option value="">-</option>{prefs.nature.options.map(x => <option key={x}>{x}</option>)}</select>
    if (f === 'volume_type') return <select value={it.volume_type || ''} onChange={e => save(it.id, { volume_type: e.target.value })}><option value="">{L('vol.txn')}</option><option value={VOL_FILE}>{L('vol.file')}</option></select>
    if (f === 'automation') return <select value={it.automation} onChange={e => save(it.id, { automation: e.target.value })}><option value="">-</option><option>Yes</option><option>No</option></select>
    if (['volume', 'peak_som', 'peak_eom', 'minutes'].includes(f)) return <NumField value={it[f]} onCommit={v => num(it, f, v)} />
    if (f === 'description') return <EditField multiline value={it.description} onCommit={v => save(it.id, { description: v })} rows={2} />
    const list = { product: 'dl-product', process: 'dl-process', channel: 'dl-channel', category: 'dl-category' }[f]
    return <EditField value={it[f]} list={list} onCommit={v => save(it.id, { [f]: v })} title={f === 'product' ? 'Separate several products with a semicolon' : undefined} />
  }
  return <div className="panel" style={{ padding: 0 }}><div className="tw"><table className="grid-t">
    <thead><tr><th>#</th>{vis.map(([f, l, w]) => <th key={f} style={{ minWidth: w }}>{l}{f !== 'volume_type' && cfg[f.startsWith('peak') ? 'peak' : f] === 'required' && <em className="star">*</em>}</th>)}{prefs.showTime && <th className="num">Daily H</th>}<th></th></tr></thead>
    <tbody>{items.map((it, i) => <tr key={it.id} className={it.missing?.length ? 'miss' : ''} title={it.missing?.length ? 'Missing: ' + it.missing.join(', ') : ''}>
      <td className="formula">{i + 1}</td>{vis.map(([f]) => <td key={f}>{cell(it, f)}</td>)}
      {prefs.showTime && <td className="num"><b>{it.daily_hours.toFixed(2)}</b></td>}
      <td>{!locked && <span className="row-actions" style={{ flexWrap: 'nowrap' }}><button type="button" className="btn" title="Duplicate" onClick={() => duplicate(it.id)}>⧉</button><button type="button" className="btn" title="Remove" onClick={() => remove(it.id)}>✕</button></span>}</td></tr>)}</tbody>
  </table></div></div>
}

function UploadDialog({ fid, data, notify, close, done }) {
  const [file, setFile] = useState(null)
  const [rep, setRep] = useState(null)
  const [busy, setBusy] = useState(false)
  const run = async dry => {
    setBusy(true)
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false')
      const r = await api(`/api/capture/${fid}/upload`, { method: 'POST', form: fd }); setRep(r)
      if (!dry) { notify(`Imported ${fmt(r.activities)} activities for ${fmt(r.employees_replaced)} employees.`); done(); close() }
    } catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  return <Modal title="Upload the filled template" sub={`${data.function.name}: activities and units from the Excel template`} onClose={close}>
    <ol className="formula" style={{ margin: '0 0 12px 18px', lineHeight: 1.7 }}>
      <li>Download the template from the Activities step and fill it in, in Excel.</li>
      <li>Choose the file here and check it. Nothing changes until you import.</li>
      <li>On import, the activities of each employee with rows in the file replace their current activities. Employees without rows are left as they are.</li></ol>
    <label className="btn" style={{ display: 'inline-block' }}>{file ? file.name : 'Choose the filled template'}<input type="file" accept=".xlsx,.xlsm" style={{ display: 'none' }} onChange={e => { setFile(e.target.files[0] || null); setRep(null); e.target.value = '' }} /></label>
    {rep && <div className="checks" style={{ marginTop: 14 }}>
      <b>Check result: nothing has been changed yet</b>
      <div className="check"><i style={{ background: 'var(--teal)' }}>✓</i><span>{fmt(rep.activities)} activities for {fmt(rep.employees_replaced)} employees will be saved.</span></div>
      <div className="check"><i style={{ background: 'var(--teal)' }}>✓</i><span>{fmt(rep.staff_updated)} employees get a new unit or region.</span></div>
      {rep.other_function.length > 0 && <div className="check"><i style={{ background: 'var(--amber)' }}>i</i><span>{rep.other_function.length} employee codes belong to another function and will be skipped: {rep.other_function.slice(0, 15).join(', ')}</span></div>}
      {rep.not_found.length > 0 && <div className="check"><i style={{ background: 'var(--amber)' }}>i</i><span>{rep.not_found.length} employee codes are not in the portal and will be skipped: {rep.not_found.slice(0, 15).join(', ')}. Add missing employees in step 1 first.</span></div>}
      {rep.problems.map((t, i) => <div key={i} className="check"><i style={{ background: 'var(--amber)' }}>i</i><span>{t}</span></div>)}
    </div>}
    <div className="row-actions" style={{ marginTop: 16 }}>
      <button className="btn" disabled={!file || busy} onClick={() => run(true)}>Check the file</button>
      <button className="btn pri" disabled={!file || busy || !rep} onClick={() => confirm('Import now? Activities of the employees in the file will be replaced.') && run(false)}>{busy ? 'Working…' : 'Import'}</button>
      <button className="btn" onClick={close}>Cancel</button></div>
  </Modal>
}

// ------------------------------------------------------------------ copy to / from colleagues
function CopyDialog({ mode, data, fid, source, target, items: srcItems, notify, close, done }) {
  const [src, setSrc] = useState(mode === 'to' ? source.code : '')
  const [items, setItems] = useState(mode === 'to' ? srcItems : null)
  const [acts, setActs] = useState(() => new Set((srcItems || []).map(a => a.id)))
  const [tg, setTg] = useState(() => new Set(mode === 'from' ? [target.code] : []))
  const [q, setQ] = useState('')
  const [fRegion, setFRegion] = useState('')
  const [fMgr, setFMgr] = useState(false)
  const [fPos, setFPos] = useState(false)
  const [fEmpty, setFEmpty] = useState(false)
  const [fType, setFType] = useState('')
  const [vmode, setVmode] = useState('same')
  const [rv, setRv] = useState({})
  const [busy, setBusy] = useState(false)
  const [ask, setAsk] = useState(null)   // colleagues who already have activities: overwrite or append?
  const staff = data.staff
  const srcEmp = staff.find(s => s.code === src)
  useEffect(() => {
    if (mode !== 'from' || !src) return
    setItems(null); api(`/api/capture/${fid}/staff/${encodeURIComponent(src)}/items`).then(r => { setItems(r.items); setActs(new Set(r.items.map(a => a.id))) }).catch(e => notify(e.message, true))
  }, [src])
  const ql = q.trim().toLowerCase()
  const pool = mode === 'to' ? staff.filter(s => s.code !== src && (!fRegion || s.region === fRegion) && (!fMgr || s.manager_code === srcEmp?.manager_code) &&
    (!fPos || s.position === srcEmp?.position) && (!fEmpty || !s.activities) && (!fType || s.emp_type === fType) && (!ql || (s.name + ' ' + s.code + ' ' + s.position).toLowerCase().includes(ql))) : []
  const sources = mode === 'from' ? staff.filter(s => s.activities && s.code !== target.code && (!ql || (s.name + ' ' + s.code + ' ' + s.position).toLowerCase().includes(ql))) : []
  const tRegions = [...new Set(staff.filter(s => tg.has(s.code)).map(s => s.region || ''))].sort()
  const chosen = (items || []).filter(a => acts.has(a.id))
  const regionsAll = [...new Set(staff.map(s => s.region).filter(Boolean))].sort()
  const start = () => {
    const have = mode === 'to' ? staff.filter(s => tg.has(s.code) && s.activities) : (target.activities ? [staff.find(s => s.code === target.code) || target] : [])
    if (have.length) setAsk(have); else go('append')
  }
  const go = async (how) => {
    setAsk(null)
    setBusy(true)
    try {
      const region_volumes = {}
      if (vmode === 'region') tRegions.forEach(r => { region_volumes[r] = {}; chosen.forEach(a => { const v = rv[r + '|' + a.id]; region_volumes[r][a.id] = v === undefined || v === '' ? (a.volume ?? null) : Number(v) }) })
      const r = await api(`/api/capture/${fid}/copy`, { method: 'POST', body: { source: src, targets: [...tg], item_ids: [...acts], volume_mode: vmode, region_volumes, mode: how } })
      notify(`Copied ${r.activities} activit${r.activities === 1 ? 'y' : 'ies'} to ${r.people} ${r.people === 1 ? 'employee' : 'employees'}${r.replaced ? `, replacing ${r.replaced} earlier activities` : ''}${r.skipped ? `; ${r.skipped} already had the activity and were left unchanged` : ''}.`)
      done(); close()
    } catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const toggle = (set, v) => set(s => { const n = new Set(s); n.has(v) ? n.delete(v) : n.add(v); return n })
  return <Modal title={mode === 'to' ? `Copy ${source.name}'s activities to colleagues` : `Copy a colleague's activities to ${target.name}`} wide onClose={close}
    sub={mode === 'to' ? 'For employees who perform the same work. The copies stay linked, so you can later compare their volumes or apply detail changes to all.' : 'Pick the colleague whose activities match, then choose which to copy.'}>
    <div className="grid g2" style={{ gap: 18 }}>
      <div>
        {mode === 'from' && <><b className="fl">1. Copy from</b>
          {!src ? <><input className="inp" placeholder="Find a colleague with activities" value={q} onChange={e => setQ(e.target.value)} style={{ width: '100%', margin: '6px 0' }} />
            <div className="pick">{sources.slice(0, 200).map(s => <button key={s.code} onClick={() => { setSrc(s.code); setQ('') }}><span><b>{s.name}</b><small>{s.position} · {s.grade} · {s.region || 'No region'}</small></span><em>{s.activities}</em></button>)}
              {!sources.length && <div className="formula" style={{ padding: 8 }}>No colleagues with activities yet.</div>}</div></>
            : <div className="chosen"><span><b>{srcEmp?.name}</b><small>{srcEmp?.position} · {srcEmp?.region || 'No region'}</small></span><button className="linkbtn" onClick={() => { setSrc(''); setItems(null) }}>Change</button></div>}</>}
        {(mode === 'to' || src) && <>
          <b className="fl" style={{ display: 'block', marginTop: mode === 'from' ? 14 : 0 }}>{mode === 'from' ? '2. ' : '1. '}Activities to copy</b>
          {!items ? <div className="loading">Loading…</div> : <>
            <label className="chk"><input type="checkbox" checked={items.length > 0 && items.every(a => acts.has(a.id))} onChange={e => setActs(e.target.checked ? new Set(items.map(a => a.id)) : new Set())} /><b>All {items.length} activities</b></label>
            <div className="pick">{items.map(a => <label key={a.id} className="chk"><input type="checkbox" checked={acts.has(a.id)} onChange={() => toggle(setActs, a.id)} />
              <span><b>{a.category || 'No category yet'}</b><small>{[a.process, a.product, a.channel].filter(Boolean).join(' · ') || '-'} · {a.volume != null ? num2(a.volume) : '-'} per {PER[a.frequency]}</small></span></label>)}</div></>}
        </>}
      </div>
      <div>
        {mode === 'to' ? <>
          <b className="fl">2. Colleagues who perform the same work</b>
          <div className="kvline" style={{ margin: '6px 0' }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} />
            <select value={fRegion} onChange={e => setFRegion(e.target.value)}><option value="">All regions</option>{regionsAll.map(r => <option key={r}>{r}</option>)}</select>
            <select value={fType} onChange={e => setFType(e.target.value)}><option value="">FTE and FTC</option><option value="FTE">FTE only</option><option value="FTC">FTC only</option></select></div>
          <div className="kvline" style={{ margin: '0 0 6px', gap: 14 }}>
            <label className="formula chk"><input type="checkbox" checked={fMgr} onChange={e => setFMgr(e.target.checked)} />Same manager</label>
            <label className="formula chk"><input type="checkbox" checked={fPos} onChange={e => setFPos(e.target.checked)} />Same position</label>
            <label className="formula chk"><input type="checkbox" checked={fEmpty} onChange={e => setFEmpty(e.target.checked)} />No activities yet</label></div>
          <div className="kvline" style={{ margin: '0 0 6px' }}><button type="button" className="btn" onClick={() => setTg(s => new Set([...s, ...pool.slice(0, 400).map(p => p.code)]))}>Tick all shown ({Math.min(pool.length, 400)})</button>
            <button type="button" className="btn" onClick={() => setTg(new Set())}>Clear</button><span className="formula">{tg.size} selected</span></div>
          <div className="pick tall">{pool.slice(0, 400).map(s => <label key={s.code} className="chk"><input type="checkbox" checked={tg.has(s.code)} onChange={() => toggle(setTg, s.code)} />
            <span><b>{s.name}</b><small>{[s.position, s.grade, s.emp_type, s.region || 'No region'].filter(Boolean).join(' · ')}{s.activities ? ` · has ${s.activities}` : ''}</small></span></label>)}
            {!pool.length && <div className="formula" style={{ padding: 8 }}>No one matches.</div>}</div>
        </> : <div className="msg ok" style={{ marginTop: 0 }}>The activities will be added to <b>{target.name}</b> ({target.region || 'no region'}). Activities they already have from this colleague are skipped.</div>}
        <div style={{ marginTop: 14 }}><b className="fl">{mode === 'to' ? '3. ' : '3. '}Volumes for the copies</b>
          <label className="chk"><input type="radio" checked={vmode === 'same'} onChange={() => setVmode('same')} />Same volumes as {srcEmp?.name || 'the colleague'}</label>
          {mode === 'to' && <label className="chk"><input type="radio" checked={vmode === 'region'} onChange={() => setVmode('region')} />Enter a volume for each region (same activity, different volume by region)</label>}
          <label className="chk"><input type="radio" checked={vmode === 'blank'} onChange={() => setVmode('blank')} />Leave volumes empty and enter them for each employee</label>
        </div>
      </div>
    </div>
    {vmode === 'region' && mode === 'to' && <div className="panel" style={{ marginTop: 14, padding: 12 }}>
      <b className="fl">Volume per {chosen.length === 1 ? PER[chosen[0].frequency] : 'frequency period'} for each region</b>
      {!tg.size ? <p className="formula">Select colleagues first; their regions appear here.</p> : <div className="tw"><table>
        <thead><tr><th>Activity</th><th className="num">{srcEmp?.region || 'Source'} (source)</th>{tRegions.map(r => <th key={r} className="num">{r || 'No region'} <span className="formula">({staff.filter(s => tg.has(s.code) && (s.region || '') === r).length})</span></th>)}</tr></thead>
        <tbody>{chosen.map(a => <tr key={a.id}><td><b>{short(a.category || a.process || 'Activity', 40)}</b><div className="formula">per {PER[a.frequency]}</div></td><td className="num">{a.volume != null ? num2(a.volume) : '-'}</td>
          {tRegions.map(r => <td key={r} className="num"><input className="inp sm" type="number" min="0" placeholder={a.volume ?? ''} value={rv[r + '|' + a.id] ?? ''} onChange={e => setRv(v => ({ ...v, [r + '|' + a.id]: e.target.value }))} /></td>)}</tr>)}</tbody></table></div>}
      <p className="formula" style={{ margin: '6px 0 0' }}>Empty cells use the source volume. Each employee's volume can still be changed afterwards.</p></div>}
    {ask && <div className="msg warn askbox" style={{ marginTop: 16 }} role="alertdialog" aria-label="Employees who already have activities">
      <b>{mode === 'to' ? `${ask.length} of the ${tg.size} selected ${tg.size === 1 ? 'colleague already has' : 'colleagues already have'} activities.` : `${target.name} already has ${target.activities} activit${target.activities === 1 ? 'y' : 'ies'}.`}</b>
      {mode === 'to' && <div className="formula" style={{ margin: '4px 0 0' }}>{ask.slice(0, 8).map(x => `${x.name} (${x.activities})`).join(', ')}{ask.length > 8 ? ` and ${ask.length - 8} more` : ''}</div>}
      <div style={{ margin: '8px 0 10px' }}>Overwrite all removes their current activities and gives them these instead. Append adds these to what they already have; activities they already share with {srcEmp?.name || 'the colleague'} are not copied twice.</div>
      <div className="row-actions"><button type="button" className="btn danger" onClick={() => go('replace')}>Overwrite all</button>
        <button type="button" className="btn pri" onClick={() => go('append')}>Append</button>
        <button type="button" className="btn" onClick={() => setAsk(null)}>Cancel</button></div></div>}
    <div className="row-actions" style={{ marginTop: 16 }}>
      <button type="button" className="btn pri" disabled={busy || !src || !acts.size || !tg.size || !!ask} onClick={start}>{busy ? 'Copying…' : `Copy ${acts.size} activit${acts.size === 1 ? 'y' : 'ies'}${mode === 'to' ? ` to ${tg.size} ${tg.size === 1 ? 'colleague' : 'colleagues'}` : ''}`}</button>
      <button type="button" className="btn" onClick={close}>Cancel</button></div>
  </Modal>
}

// ------------------------------------------------------------------ remove activities in one step
function ClearDialog({ data, fid, current, notify, close, done }) {
  const [tg, setTg] = useState(() => new Set(current?.activities ? [current.code] : []))
  const [q, setQ] = useState('')
  const [et, setEt] = useState('')
  const [busy, setBusy] = useState(false)
  const ql = q.trim().toLowerCase()
  const withActs = data.staff.filter(s => s.activities)
  const pool = withActs.filter(s => (!et || s.emp_type === et) && (!ql || (s.name + ' ' + s.code + ' ' + s.position + ' ' + (s.unit || '') + ' ' + (s.region || '')).toLowerCase().includes(ql)))
  const n = withActs.filter(s => tg.has(s.code)).reduce((a, s) => a + s.activities, 0)
  const toggle = c => setTg(s => { const x = new Set(s); x.has(c) ? x.delete(c) : x.add(c); return x })
  const run = async () => {
    if (!confirm(`Remove ${n} activit${n === 1 ? 'y' : 'ies'} of ${tg.size} employee${tg.size === 1 ? '' : 's'}? This cannot be undone.`)) return
    setBusy(true)
    try { const r = await api(`/api/capture/${fid}/clear`, { method: 'POST', body: { codes: [...tg] } }); notify(`Removed ${r.removed} activities.`); done(); close() }
    catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  return <Modal title="Remove activities" sub="Remove every activity of the employees you tick, in one step. Units, regions and service or support are kept." onClose={close}>
    <div className="kvline" style={{ margin: '0 0 6px' }}><input className="inp" placeholder="Search" value={q} onChange={e => setQ(e.target.value)} style={{ flex: 1 }} />
      <select value={et} onChange={e => setEt(e.target.value)}><option value="">FTE and FTC</option><option value="FTE">FTE only</option><option value="FTC">FTC only</option></select></div>
    <div className="kvline" style={{ margin: '0 0 6px' }}><button type="button" className="btn" onClick={() => setTg(s => new Set([...s, ...pool.map(p => p.code)]))}>Tick all shown ({pool.length})</button>
      <button type="button" className="btn" onClick={() => setTg(new Set())}>Clear</button><span className="formula">{tg.size} ticked · {n} activities</span></div>
    <div className="pick tall">{pool.map(s => <label key={s.code} className="chk"><input type="checkbox" checked={tg.has(s.code)} onChange={() => toggle(s.code)} />
      <span><b>{s.name}</b><small>{[s.position, s.grade, s.emp_type, s.region].filter(Boolean).join(' · ')}</small></span><em>{s.activities}</em></label>)}
      {!pool.length && <div className="formula" style={{ padding: 8 }}>No employees with activities match.</div>}</div>
    <div className="row-actions" style={{ marginTop: 16 }}><button type="button" className="btn danger" disabled={busy || !tg.size} onClick={run}>{busy ? 'Removing…' : `Remove ${n} activit${n === 1 ? 'y' : 'ies'}`}</button>
      <button type="button" className="btn" onClick={close}>Cancel</button></div>
  </Modal>
}

// ------------------------------------------------------------------ same activity across colleagues
function LinkedDialog({ item, notify, close, done, locked }) {
  const [d, setD] = useState(null)
  const [vals, setVals] = useState({})
  const [fill, setFill] = useState({})
  const [busy, setBusy] = useState(false)
  useEffect(() => { api(`/api/capture/items/${item.id}/linked`).then(r => { setD(r); setVals(Object.fromEntries(r.rows.map(x => [x.id, { volume: x.volume ?? '', peak_som: x.peak_som ?? '', peak_eom: x.peak_eom ?? '' }]))) }).catch(e => notify(e.message, true)) }, [])
  if (!d) return <Modal title="Same activity across colleagues" onClose={close}><div className="loading">Loading…</div></Modal>
  const regions = [...new Set(d.rows.map(r => r.region))]
  const set = (id, f, v) => setVals(s => ({ ...s, [id]: { ...s[id], [f]: v } }))
  const applyRegion = r => { const v = fill[r]; if (v === undefined || v === '') return; setVals(s => { const n = { ...s }; d.rows.filter(x => x.region === r).forEach(x => { n[x.id] = { ...n[x.id], volume: v } }); return n }) }
  const save = async () => {
    setBusy(true)
    const toNum = v => v === '' || v === null ? null : Number(v)
    try {
      const r = await api(`/api/capture/items/${item.id}/linked`, { method: 'PUT', body: { rows: d.rows.map(x => ({ id: x.id, volume: toNum(vals[x.id].volume), peak_som: toNum(vals[x.id].peak_som), peak_eom: toNum(vals[x.id].peak_eom) })) } })
      setD(r); notify('Volumes saved.'); done(); close()
    } catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const it = d.item
  return <Modal title={`${it.category || it.process || 'Activity'}: volumes across colleagues`} wide onClose={close}
    sub={`${d.rows.length} employees record this activity. Volumes are per ${PER[it.frequency]}; peaks are averages per day. Set a volume for a whole region, then adjust individuals.`}>
    {!locked && <div className="regfill">{regions.map(r => <div key={r}><span>{r || 'No region'} <small>({d.rows.filter(x => x.region === r).length})</small></span>
      <input className="inp sm" type="number" min="0" placeholder="Volume" value={fill[r] ?? ''} onChange={e => setFill(f => ({ ...f, [r]: e.target.value }))} />
      <button type="button" className="btn" onClick={() => applyRegion(r)} disabled={fill[r] === undefined || fill[r] === ''}>Apply to region</button></div>)}</div>}
    <div className="tw scroll" style={{ maxHeight: 420 }}><table>
      <thead><tr><th>Employee</th><th>Region</th><th className="num">Avg Volume per {PER[it.frequency]}</th><th className="num">Peak Start of Month</th><th className="num">Peak End of Month</th><th></th></tr></thead>
      <tbody>{d.rows.map(x => <tr key={x.id}><td><b>{x.name}</b><div className="formula">{x.grade} · {x.code}</div></td><td>{x.region || '-'}</td>
        {['volume', 'peak_som', 'peak_eom'].map(f => <td key={f} className="num"><input className="inp sm" type="number" min="0" disabled={locked} value={vals[x.id]?.[f] ?? ''} onChange={e => set(x.id, f, e.target.value)} /></td>)}
        <td>{!x.same_details && <span className="pill p-warn" title="Details differ from this activity">Details differ</span>}</td></tr>)}</tbody></table></div>
    {!locked && <div className="row-actions" style={{ marginTop: 14 }}><button className="btn pri" onClick={save} disabled={busy}>{busy ? 'Saving…' : 'Save volumes'}</button><button className="btn" onClick={close}>Cancel</button></div>}
  </Modal>
}

// ================================================================== step 3: review
function Review({ data, fid, setStep, setCurrent }) {
  const [rv, setRv] = useState(null)
  useEffect(() => { api(`/api/capture/${fid}/review`).then(setRv).catch(() => setRv({ blocking: [], warnings: [] })) }, [data])
  const s = data.staff
  const tot = s.reduce((a, x) => a + x.daily_hours, 0)
  const ph = data.settings.productive_hours
  const svc = s.reduce((a, x) => a + x.service_hours, 0), sup = s.reduce((a, x) => a + x.support_hours, 0)
  const over = prefs.showTime ? s.filter(x => x.activities && x.utilisation > 125) : [], under = prefs.showTime ? s.filter(x => x.activities && x.utilisation < 50 && !x.is_head) : []
  const open = code => { setCurrent(code); setStep(2) }
  const List = ({ title, rows, note }) => rows.length ? <div className="panel"><h3>{title} ({rows.length})</h3><p className="sub">{note}</p><div className="tw scroll" style={{ maxHeight: 260 }}><table><tbody>
    {rows.map(x => <tr key={x.code} className="click" onClick={() => open(x.code)}><td><b>{x.name}</b><div className="formula">{x.grade} · {x.region || 'No region'}</div></td><td className="num">{x.activities || '-'} {x.activities === 1 ? 'activity' : 'activities'}</td>{prefs.showTime && <td className="num">{Math.round(x.utilisation)}%</td>}</tr>)}</tbody></table></div></div> : null
  return <>
    <div className="sumbar"><div><b>{fmt(s.length)}</b><span>Employees</span></div><div><b>{fmt(s.filter(x => x.activities).length)}</b><span>With activities</span></div>
      <div><b>{fmt(s.reduce((a, x) => a + x.activities, 0))}</b><span>Activities</span></div>
      {prefs.showTime && <><div><b>{hrs(tot)}</b><span>Man-hours a day</span></div>
      <div><b>{(tot / ph).toFixed(1)}</b><span>FTE equivalent</span></div><div><b>{hrs(svc)} / {hrs(sup)}</b><span>Service / support hours</span></div></>}</div>
    <div className="grid g2">
      <div className="panel"><h2>Checks</h2><p className="sub">Data capture is complete when every employee has a unit, a region and their activities.</p><div className="checks">
        {!rv ? <div className="loading">Checking…</div> : <>
          {rv.blocking.map((t, k) => <div key={'b' + k} className="check"><i style={{ background: 'var(--coral)' }}>!</i><span>{t}</span></div>)}
          {rv.warnings.map((t, k) => <div key={'w' + k} className="check"><i style={{ background: 'var(--amber)' }}>i</i><span>{t}</span></div>)}
          {over.length > 0 && <div className="check"><i style={{ background: 'var(--amber)' }}>i</i><span>{over.length} employees are above 125% utilisation. Please confirm their volumes and times.</span></div>}
          {!rv.blocking.length && !rv.warnings.length && <div className="check"><i style={{ background: 'var(--teal)' }}>✓</i><span>Everything required is filled in.</span></div>}</>}</div></div>
      <List title="Missing details" rows={s.filter(x => x.incomplete)} note="Select an employee to complete their activities." />
      <List title="Above 125% utilisation" rows={over} note="Usually a volume entered per month as per day, or minutes entered as hours." />
      <List title="Below 50% utilisation" rows={under} note="Some activities may not have been recorded yet." />
      <List title="No activities yet" rows={s.filter(x => !x.activities && !x.is_head)} note="Add activities or copy them from a colleague." />
    </div>
  </>
}
