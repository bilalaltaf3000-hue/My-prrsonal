import React, { useEffect, useMemo, useState } from 'react'
import { api, download } from '../api.js'
import { fmt, hrs, TYPE_COL, vfmt } from '../org.js'
import { Dot, Expand, Modal } from '../ui.jsx'
import { canDash } from '../rights.js'
import { prefs, themeOf, catHidden, L, VOL_FILE } from '../prefs.js'

export function utilTone(u) { return u > 110 ? 'var(--coral)' : u < 60 ? 'var(--amber)' : 'var(--teal)' }
const num = v => v === null || v === undefined || v === '' ? '' : Number(v).toLocaleString('en-US', { maximumFractionDigits: 2 })
const per = { Daily: 'day', Weekly: 'week', Fortnightly: 'fortnight', Monthly: 'month' }

export function WorkSummary({ e }) {
  const hide = catHidden()
  const cats = hide ? new Set((e.items || []).map(w => themeOf(w.category)).filter(Boolean)).size : new Set((e.items || []).map(w => w.category || '')).size
  if (!prefs.showTime) return <div className="kv"><div><b>{e.activities ?? e.items?.length}</b><span>Activities</span></div><div><b>{cats}</b><span>{hide ? 'Themes' : 'Categories'}</span></div></div>
  return <div className="kv">
    <div><b>{e.activities ?? e.items?.length}</b><span>Activities</span></div>
    <div><b>{e.daily_hours.toFixed(1)}</b><span>Man-hours a day</span></div>
    <div><b style={{ color: utilTone(e.utilisation) }}>{Math.round(e.utilisation)}%</b><span>Utilisation</span></div>
    <div><b>{Math.round(e.peak_utilisation)}%</b><span>Peak day</span></div>
  </div>
}

// The employee's activities in the data capture template layout. The category is shown; the full
// description opens with a button so long paragraphs do not crowd the table.
export function WorkTable({ items, cfg }) {
  const has = f => !cfg || cfg[f] !== 'hidden'
  const hm = has('handling') || has('automation')
  return <div className="tw"><table className="acttab">
    <thead><tr><th style={{ minWidth: 240 }}>Activity</th>{has('product') && <th>Product</th>}{(has('process') || has('channel')) && <th>{has('process') ? 'Process' : 'Channel'}{has('process') && has('channel') ? ' / Channel' : ''}</th>}
      {(has('volume') || has('frequency')) && <th className="num">{has('volume') ? 'Avg Volume' : 'Frequency'}</th>}{has('peak') && <th className="num" title="Peak volume per day: start of month / end of month">Peak SOM / EOM</th>}{hm && <th>{has('handling') ? prefs.nature.label : 'Automation'}</th>}{has('minutes') && <th className="num">Min / Item</th>}{prefs.showTime && <><th className="num">Total Min</th><th className="num">Daily H</th></>}</tr></thead>
    <tbody>{items.map(w => <tr key={w.id}>
      <td>{has('category') && (catHidden() ? <b style={{ fontWeight: 650 }}>{themeOf(w.category) || 'No theme'}</b>
        : <>{themeOf(w.category) && <div className="formula">{themeOf(w.category)}</div>}<b style={{ fontWeight: 650 }}>{w.category || 'Category not set'}</b></>)}{has('description') && <Expand text={w.description} />}
        {w.missing?.length > 0 && <span className="pill p-warn" title={'Missing: ' + w.missing.join(', ')}>Incomplete</span>}</td>
      {has('product') && <td>{w.product}</td>}
      {(has('process') || has('channel')) && <td>{has('process') && w.process}<div className="formula">{has('channel') && w.channel}</div></td>}
      {(has('volume') || has('frequency')) && <td className="num" style={{ whiteSpace: 'nowrap' }}>{has('volume') && <span title={num(w.volume)}>{w.volume != null ? vfmt(w.volume) : ''}</span>}<div className="formula">{[has('frequency') && w.frequency, has('volume') && w.volume_type === VOL_FILE && L('vol.file')].filter(Boolean).join(' · ')}</div></td>}
      {has('peak') && <td className="num">{w.peak_som == null && w.peak_eom == null ? '' : `${num(w.peak_som) || '–'} / ${num(w.peak_eom) || '–'}`}</td>}
      {hm && <td style={{ whiteSpace: 'nowrap' }}>{has('handling') && w.handling}{has('automation') && (w.automation === 'Yes' ? <div><span className="pill p-ok" title="Marked as an automation opportunity">Automation</span></div> : w.automation === 'No' ? <div className="formula">No automation</div> : null)}</td>}
      {has('minutes') && <td className="num">{num(w.minutes)}</td>}{prefs.showTime && <><td className="num">{fmt(w.total_minutes)}</td>
      <td className="num"><b>{w.daily_hours.toFixed(2)}</b></td></>}
    </tr>)}</tbody>
  </table></div>
}

// Employee activities as a PDF: each employee's organogram, then their activities (several: with contents)
export function PdfButton({ fid, codes, label = 'Export PDF', notify, primary }) {
  const [busy, setBusy] = useState(false)
  const run = () => {
    setBusy(true)
    download(`/api/capture/${fid}/activities-pdf`, 'employee_activities.pdf', 'POST', { codes })
      .then(() => notify && notify('PDF ready. Check your downloads.'))
      .catch(e => notify ? notify(e.message, true) : alert(e.message)).finally(() => setBusy(false))
  }
  return <button type="button" className={'btn' + (primary ? ' pri' : '')} disabled={busy || !codes.length} onClick={run}
    title="Organogram and activities of each employee, with a table of contents">{busy ? 'Preparing PDF…' : label}</button>
}

export default function EmployeeDetails({ user, notify, go, sel, units: fUnits, showLine }) {
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState(null)
  const [d, setD] = useState(null)
  const [q, setQ] = useState('')
  const [region, setRegion] = useState('')
  const [unit, setUnit] = useState('')
  const [type, setType] = useState('')
  const [et, setEt] = useState('')
  const [only, setOnly] = useState(false)
  const [open, setOpen] = useState(null)
  const [sort, setSort] = useState('grade')

  useEffect(() => {
    api('/api/capture/functions').then(r => {
      const s = [...r].sort((a, b) => a.name.localeCompare(b.name)); setFns(s)
    }).catch(e => notify(e.message, true))
  }, [])
  const choices = useMemo(() => sel?.length ? fns.filter(f => sel.includes(f.id)) : fns, [fns, (sel || []).join()])
  useEffect(() => {
    if (!choices.length) return
    if ((fid !== 0 || choices.length <= 1) && !choices.some(f => f.id === fid)) setFid((choices.find(x => x.activities) || choices[0]).id)
  }, [choices])
  useEffect(() => {
    if (fid === null) return
    setD(null); setOpen(null); setRegion(''); setUnit('')
    if (fid) { api(`/api/capture/${fid}/employees`).then(setD).catch(e => notify(e.message, true)); return }
    // All functions: every function's employees, one function after another, each with its own field settings
    Promise.all(choices.map(f => api(`/api/capture/${f.id}/employees`))).then(rs => setD({
      function: { id: 0, name: 'All functions', status: '' }, settings: rs[0]?.settings || {}, fields: null, all: true,
      employees: rs.flatMap(r => r.employees.map(e => ({ ...e, fn: r.function.name, fields: r.fields }))) }))
      .catch(e => notify(e.message, true))
  }, [fid, fid === 0 ? choices.map(f => f.id).join() : ''])

  const rows = useMemo(() => {
    if (!d) return []
    const ql = q.trim().toLowerCase()
    let r = d.employees.filter(e => (!fUnits?.length || fUnits.includes(e.unit)) && (!region || (e.region || '') === region) && (!unit || (e.unit || '') === unit) && (!only || e.items.length) && (!type || (e.service_type || 'none') === type) && (!et || e.emp_type === et) &&
      (!ql || (e.name + ' ' + e.code + ' ' + e.position + ' ' + e.items.map(a => a.category + ' ' + themeOf(a.category) + ' ' + a.process + ' ' + a.description).join(' ')).toLowerCase().includes(ql)))
    const head = (a, b) => (b.is_head ? 1 : 0) - (a.is_head ? 1 : 0)   // function head always on top
    if (sort === 'mh') r = [...r].sort((a, b) => head(a, b) || b.daily_hours - a.daily_hours)
    if (sort === 'acts') r = [...r].sort((a, b) => head(a, b) || b.items.length - a.items.length)
    if (sort === 'util_low') r = [...r].filter(e => e.items.length || e.is_head).sort((a, b) => head(a, b) || a.utilisation - b.utilisation)
    if (sort === 'name') r = [...r].sort((a, b) => head(a, b) || a.name.localeCompare(b.name))
    return r
  }, [d, q, region, unit, only, sort, type, et, (fUnits || []).join('|')])

  const regions = d ? [...new Set(d.employees.map(e => e.region || ''))].sort() : []
  // the function head covers all units, so a head without a unit does not make a "Unit not set" option
  const units = d ? [...new Set(d.employees.filter(e => e.unit || !e.is_head).map(e => e.unit || ''))].sort() : []
  const useUnits = units.some(Boolean)   // units are optional: no Unit column or filter when the function has none
  const withWork = d ? d.employees.filter(e => e.items.length).length : 0
  const totMh = d ? d.employees.reduce((s, e) => s + e.daily_hours, 0) : 0
  const ph = d?.settings.productive_hours ?? 7.5

  return <section className="view on">
    <h1>Employee Activities</h1>
    <div className="cap-top">
      <div className="who">{choices.length <= 1 ? <b style={{ color: 'var(--ink)' }}>{choices[0]?.name}</b> :
        <>Function <select value={fid ?? ''} onChange={e => setFid(+e.target.value)}><option value={0}>All functions ({fmt(choices.reduce((a, f) => a + (f.headcount || 0), 0))})</option>{choices.map(f => <option key={f.id} value={f.id}>{f.name} ({fmt(f.headcount)})</option>)}</select></>}</div>
      {d && !d.all && <span className={'pill ' + (d.function.status === 'Complete' ? 'p-ok' : 'p-warn')}>Data capture: {d.function.status}</span>}
      {d && !d.all && <span style={{ marginLeft: 'auto' }}><PdfButton primary fid={fid} codes={rows.map(e => e.code)} notify={notify}
        label={`Export PDF · ${fmt(rows.length)} ${rows.length === 1 ? 'employee' : 'employees'}`} /></span>}
    </div>
    {!d ? <div className="loading">Loading…</div> : <>
      <div className="sumbar">
        <div><b>{fmt(d.employees.length)}</b><span>Employees</span></div>
        <div><b>{fmt(withWork)}</b><span>With activities recorded</span></div>
        <div><b>{fmt(d.employees.reduce((s, e) => s + e.items.length, 0))}</b><span>Activities</span></div>
        {(() => { // service and support employees, as a share of the employees marked (as on the dashboard)
          const sv = d.employees.filter(e => e.service_type === 'Service').length, sp = d.employees.filter(e => e.service_type === 'Support').length, n = sv + sp
          const pc = v => n ? Math.round(v / n * 100) + '%' : '-'
          return n > 0 && <div className="sb-role">
            <div className="sb-role-n"><span><i style={{ background: TYPE_COL.Service }} />Service</span><b>{fmt(sv)}</b><em>{pc(sv)}</em></div>
            <div className="sb-role-n"><span><i style={{ background: TYPE_COL.Support }} />Support</span><b>{fmt(sp)}</b><em>{pc(sp)}</em></div>
            <span className="sb-role-bar" title={`Of ${fmt(n)} employees marked as service or support`}><i style={{ width: sv / n * 100 + '%', background: TYPE_COL.Service }} /><i style={{ width: sp / n * 100 + '%', background: TYPE_COL.Support }} /></span>
          </div> })()}
        {prefs.showTime && <><div><b>{hrs(totMh)}</b><span>Man-hours a day</span></div>
        <div><b>{(totMh / ph).toFixed(1)}</b><span>FTE equivalent</span></div>
        <div><b>{withWork && Math.round(totMh / withWork / ph * 100) ? Math.round(totMh / withWork / ph * 100) + '%' : '-'}</b><span>Average utilisation (employees with activities)</span></div></>}
      </div>
      <div className="kvline">
        <input className="inp" placeholder="Search name, code, process, category or description" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 300 }} />
        {useUnits && <select value={unit} onChange={e => setUnit(e.target.value)}><option value="">All units</option>{units.map(u => <option key={u} value={u}>{u || 'Unit not set'}</option>)}</select>}
        <select value={region} onChange={e => setRegion(e.target.value)}><option value="">All regions</option>{regions.map(r => <option key={r} value={r}>{r || 'Region not set'}</option>)}</select>
        <select value={type} onChange={e => setType(e.target.value)}><option value="">Service and support</option><option value="Service">Service only</option><option value="Support">Support only</option><option value="none">Not yet marked</option></select>
        <select value={et} onChange={e => setEt(e.target.value)}><option value="">FTE and FTC</option><option value="FTE">FTE only</option><option value="FTC">FTC only</option></select>
        <select value={sort} onChange={e => setSort(e.target.value)}><option value="grade">Most senior first</option><option value="name">By name</option><option value="acts">Most activities first</option>{prefs.showTime && <><option value="mh">Most man-hours first</option><option value="util_low">Lowest utilisation first</option></>}</select>
        <label className="formula"><input type="checkbox" checked={only} onChange={e => setOnly(e.target.checked)} /> Only employees with activities</label>
      </div>
      <div className="panel" style={{ padding: '8px 12px' }}><div className="tw"><table>
        <thead><tr><th>Name</th>{d.all && <th>Function</th>}<th>Grade</th><th>Type</th>{useUnits && <th>Unit</th>}<th>Region</th><th>Service / Support</th><th>Manager</th><th className="num">Activities</th>{prefs.showTime ? <><th className="num">Daily H</th><th style={{ minWidth: 150 }}>Utilisation</th></> : <th className="num">{catHidden() ? 'Themes' : 'Categories'}</th>}</tr></thead>
        <tbody>{rows.slice(0, 500).map(e => <React.Fragment key={e.code}>
          <tr className="click" onClick={() => setOpen(e.code)} style={open === e.code ? { background: 'var(--teal-soft)' } : null}>
            <td><b>{e.name}</b><div className="formula">{[e.position, e.code].filter(Boolean).join(' · ')}</div>{showLine && <button className="linkbtn" onClick={ev => { ev.stopPropagation(); showLine(e.code) }}>Reporting Line</button>}</td>{d.all && <td>{e.fn}</td>}<td style={{ whiteSpace: 'nowrap' }}>{e.grade}</td><td style={{ whiteSpace: 'nowrap' }}><Dot fte={e.emp_type === 'FTE'} />{e.emp_type}</td>
            {useUnits && <td>{e.is_head ? 'All units' : e.unit}</td>}
            <td>{e.region}</td>
            <td>{e.service_type ? <span className="tpill" style={{ '--tc': TYPE_COL[e.service_type] }}>{e.service_type}</span> : null}</td>
            <td>{e.manager_name}</td>
            <td className="num">{e.items.length || ''}{e.incomplete > 0 && <span className="pill p-warn" style={{ marginLeft: 4 }} title="Activities missing required details">{e.incomplete}</span>}</td>
            {!prefs.showTime && <td className="num">{e.items.length ? (catHidden() ? new Set(e.items.map(w => themeOf(w.category)).filter(Boolean)).size || '-' : new Set(e.items.map(w => w.category || '')).size) : ''}</td>}
            {prefs.showTime && <td className="num">{e.daily_hours ? e.daily_hours.toFixed(2) : ''}</td>}
            {prefs.showTime && <td>{e.items.length ? <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div className="bar" style={{ minWidth: 80, flex: 1 }}><i style={{ width: Math.min(100, e.utilisation) + '%', background: utilTone(e.utilisation) }} /></div><b style={{ minWidth: 44, textAlign: 'right' }}>{Math.round(e.utilisation)}%</b></div> : <span className="formula">{e.is_head ? 'Optional' : 'No activities yet'}</span>}</td>}
          </tr>
        </React.Fragment>)}
          {rows.length > 500 && <tr><td colSpan={10} className="formula">Showing 500 of {fmt(rows.length)}. Use the filters to narrow down.</td></tr>}
          {!rows.length && <tr><td colSpan={10} className="formula">No one matches.</td></tr>}</tbody>
      </table></div></div>
    </>}
    {d && open && rows.some(e => e.code === open) && <EmployeeModal key={open} fid={fid} notify={notify} e={rows.find(x => x.code === open)} list={rows} useUnits={useUnits} cfg={d.all ? rows.find(x => x.code === open)?.fields : d.fields} fn={d.all ? rows.find(x => x.code === open)?.fn : d.function.name}
      onPick={setOpen} onClose={() => setOpen(null)} showLine={showLine} />}
  </section>
}

// The same employee popup from anywhere (for example an activity list on Activity Insights): loads the function's
// employees, then previous / next go through the employees of that list
export function EmployeePopup({ code, fid, codes, notify, showLine, onClose }) {
  const [d, setD] = useState(null)
  const [cur, setCur] = useState(code)
  useEffect(() => { api(`/api/capture/${fid}/employees`).then(setD).catch(e => { notify ? notify(e.message, true) : alert(e.message); onClose() }) }, [fid])
  if (!d) return <Modal wide title="Loading…" onClose={onClose}><div className="loading">Loading…</div></Modal>
  const byCode = new Map(d.employees.map(e => [e.code, e]))
  const e = byCode.get(cur)
  if (!e) return <Modal title="Employee" onClose={onClose}><div className="empty">This employee is not in the list you can see.</div></Modal>
  const list = [...new Set(codes || [code])].map(c => byCode.get(c)).filter(Boolean)
  return <EmployeeModal key={cur} fid={fid} notify={notify} e={e} list={list.length ? list : [e]} useUnits={d.employees.some(x => x.unit)} cfg={d.fields}
    fn={d.function.name} onPick={setCur} onClose={onClose} showLine={showLine} />
}

// One employee's activities in a popup, with filters, and previous / next through the list
function EmployeeModal({ e, fid, notify, list, cfg, fn, useUnits, onPick, onClose, showLine }) {
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('')
  const [th, setTh] = useState('')
  const [hand, setHand] = useState('')
  const [auto, setAuto] = useState('')
  const [freq, setFreq] = useState('')
  const has = f => !cfg || cfg[f] !== 'hidden'
  const i = list.findIndex(x => x.code === e.code)
  const prev = list[i - 1], next = list[i + 1]
  const uniq = f => [...new Set(e.items.map(w => w[f] || ''))].sort((a, b) => a.localeCompare(b))
  const ql = q.trim().toLowerCase()
  const items = e.items.filter(w => (!th || themeOf(w.category) === th) && (!cat || (w.category || '') === cat) && (!hand || (w.handling || '') === hand) && (!auto || (w.automation || '') === auto) && (!freq || w.frequency === freq) &&
    (!ql || [w.category, themeOf(w.category), w.description, w.process, w.product, w.channel].join(' ').toLowerCase().includes(ql)))
  const filtered = th || cat || hand || auto || freq || ql
  const themes = [...new Set(e.items.map(w => themeOf(w.category)).filter(Boolean))].sort((a, b) => a.localeCompare(b))
  useEffect(() => {
    const k = ev => { if (ev.target.tagName === 'INPUT' || ev.target.tagName === 'SELECT') return; if (ev.key === 'ArrowLeft' && prev) onPick(prev.code); if (ev.key === 'ArrowRight' && next) onPick(next.code) }
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k)
  }, [e.code])
  const Sel = ({ v, set, all, opts }) => <select value={v} onChange={x => set(x.target.value)}><option value="">{all}</option>{opts.map(o => <option key={o} value={o}>{o || 'Not set'}</option>)}</select>
  return <Modal wide onClose={onClose} title={e.name} sub={[e.position, e.grade, e.code, fn].filter(Boolean).join(' · ')}>
    <div className="facts">
      {e.grade && e.grade !== '-' && <div><span>Grade</span><b>{e.grade}</b></div>}
      <div><span>Type</span><b><Dot fte={e.emp_type === 'FTE'} />{e.emp_type}</b></div>
      {e.service_type && <div><span>Service / Support</span><b>{e.service_type}</b></div>}
      {useUnits && (e.unit || e.is_head) && <div><span>Unit</span><b>{e.is_head ? 'All units' : e.unit}</b></div>}
      {e.region && <div><span>Region</span><b>{e.region}</b></div>}
      {e.manager_name && <div><span>Reports To</span><b>{e.manager_name}</b></div>}
    </div>
    <div className="emodal-bar">
      <WorkSummary e={e} />
      <div className="row-actions">{showLine && <button className="btn" onClick={() => showLine(e.code)}>Reporting Line</button>}
        <PdfButton fid={fid} codes={[e.code]} notify={notify} />
        <button className="btn" disabled={!prev} onClick={() => onPick(prev.code)} title="Previous employee (←)">‹ Previous</button>
        <button className="btn" disabled={!next} onClick={() => onPick(next.code)} title="Next employee (→)">Next ›</button>
        <span className="formula">{i + 1} of {fmt(list.length)}</span></div>
    </div>
    {!e.items.length ? <div className="empty">No activities recorded for {e.name} yet.</div> : <>
      <div className="kvline" style={{ margin: '4px 0 10px' }}>
        <input className="inp" placeholder="Search these activities" value={q} onChange={x => setQ(x.target.value)} style={{ minWidth: 240, flex: 1 }} />
        {has('category') && themes.length > 0 && <Sel v={th} set={v => { setTh(v); setCat('') }} all="All themes" opts={themes} />}
        {has('category') && !catHidden() && <Sel v={cat} set={setCat} all="All categories" opts={uniq('category').filter(c => !th || themeOf(c) === th)} />}
        {has('frequency') && <Sel v={freq} set={setFreq} all="All frequencies" opts={uniq('frequency')} />}
        {has('handling') && <Sel v={hand} set={setHand} all={`All: ${prefs.nature.label}`} opts={uniq('handling')} />}
        {has('automation') && <Sel v={auto} set={setAuto} all="Automation: all" opts={uniq('automation')} />}
        {filtered && <button className="linkbtn" onClick={() => { setQ(''); setTh(''); setCat(''); setHand(''); setAuto(''); setFreq('') }}>Clear filters</button>}
        <span className="formula">{filtered ? `${items.length} of ${e.items.length} activities` : `${e.items.length} activities`}</span>
      </div>
      {items.length ? <WorkTable items={items} cfg={cfg} /> : <div className="formula">No activities match the filters.</div>}
    </>}
  </Modal>
}
