import React, { useState } from 'react'
import { api, setToken } from '../api.js'
import { Logo } from '../ui.jsx'

export default function Login({ onLogin }) {
  const [u, setU] = useState(''); const [p, setP] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  const submit = async e => {
    e.preventDefault(); setErr(''); setBusy(true)
    try { const r = await api('/api/auth/login', { method: 'POST', body: { username: u, password: p } }); setToken(r.token); onLogin(r.user) }
    catch (ex) { setErr(ex.message) } finally { setBusy(false) }
  }
  return (
    <div className="login">
      <form onSubmit={submit}>
        <div className="brand logo-brand"><Logo /><b style={{ color: "var(--ink)" }}>Operations Services</b></div>
        <h1>Sign in</h1>
        <label>Username<input className="inp" value={u} onChange={e => setU(e.target.value)} autoComplete="username" autoFocus /></label>
        <label>Password<input className="inp" type="password" value={p} onChange={e => setP(e.target.value)} autoComplete="current-password" /></label>
        {err && <div className="err">{err}</div>}
        <button className="btn pri" style={{ textAlign: 'center', padding: '11px' }} disabled={busy || !u || !p}>{busy ? 'Signing In…' : 'Sign In'}</button>
      </form>
    </div>
  )
}
