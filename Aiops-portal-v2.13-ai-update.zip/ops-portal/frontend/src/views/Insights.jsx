import React, { useEffect, useMemo, useState } from 'react'
import { api, unitQS, filterScope } from '../api.js'
import { fmt, hrs, pct, TYPE_COL, pcs, num2, vfmt } from '../org.js'
import { ChartBox, css, Expand, Modal, Kpi, Ring, Split, useLive } from '../ui.jsx'
import { EmployeePopup } from './EmployeeDetails.jsx'
import { prefs, natVar, natCol, L, themeOf, themeColor, catHidden, VOL_FILE, VOL_COL } from '../prefs.js'

// Activity insights: what the workforce does, from the activities recorded in data capture.
export default function Insights({ sel, units, includeFlagged, showLine, theme }) {
  const T0 = prefs.showTime
  const [et, setEt] = useState('')
  const [role, setRole] = useState('')
  const [modal, setModal] = useState(null)
  const selKey = (sel || []).join(',')
  const [work, wBusy] = useLive(() => api(`/api/dashboard/work?functions=${selKey}&include_flagged=${includeFlagged}&emp_type=${et}&role=${role}${unitQS()}`).catch(() => ({ error: true })),
    [selKey, includeFlagged, et, role, (units || []).join('|')])
  const w = work && !work.error ? work : null
  const has = f => !!w && w.fields.includes(f)
  const flt = { emp_type: et, role }
  const acts = (title, filter) => setModal({ kind: 'acts', title, filter: { ...flt, ...filter } })
  const cats = w ? w.categories.filter(c => c.name !== 'Not categorised') : []
  const uncat = w ? w.categories.find(c => c.name === 'Not categorised') : null
  const handled = w ? w.handling.reduce((s, h) => s + h.activities, 0) : 0
  const manual = w ? (w.handling[0] || { name: '', activities: 0 }) : null   // the first nature of work option (Core Physical)
  const autoPct = w ? pct(w.automation.activities, w.activities) : 0
  const ranked = T0 ? [...cats].sort((a, b) => b.hours - a.hours) : cats
  const side = !!w && (has('handling') || has('automation') || (has('frequency') && w.frequency?.length > 0))
  const scope = [et, role && `${role.toLowerCase()} employees`].filter(Boolean).join(' · ')
  // the admin decides whether themes and categories are shown (Admin, Settings); themes come first
  const showTh = !!w && prefs.showThemes && w.themes?.some(t => t.name !== 'No Theme')
  const showCat = prefs.showCategories

  return <section className={'view on insights' + (wBusy && work ? ' stale' : '')}>
    <header className="pghead">
      <h1>{L('ins.title')}</h1>
      <div className="pg-side">
        <span className="seg sm" role="group" aria-label="Filter by employee type">{[['', 'All Employees'], ['FTE', 'FTE'], ['FTC', 'FTC']].map(([v, l]) => <button key={v} type="button" aria-pressed={et === v} onClick={() => setEt(v)}>{l}</button>)}</span>
        <span className="seg sm" role="group" aria-label="Service or support">{[['Service', 'Service'], ['Support', 'Support'], ['', 'All']].map(([v, l]) => <button key={v} type="button" aria-pressed={role === v} onClick={() => setRole(v)}>{l}</button>)}</span>
      </div>
    </header>
    {w && w.activities > 0 && <div className="kpis six fit">
      <Kpi icon="people" label={L('ins.employees')} value={fmt(w.staff_with_work)} />
      {has('volume') ? <>
        <Kpi icon="list" label={L('ins.volbased')} value={fmt(w.volume?.activities || 0)} onClick={() => setModal({ kind: 'browse', vol: 'with' })} />
        <Kpi icon="list" label={L('ins.nonvol')} value={fmt(w.activities - (w.volume?.activities || 0))} onClick={() => setModal({ kind: 'browse', vol: 'without' })} /></>
        : <Kpi icon="list" label={L('ins.activities')} value={fmt(w.activities)} onClick={() => setModal({ kind: 'browse', vol: '' })} />}
      {showTh && <Kpi icon="layers" label={L('ins.themes')} value={fmt(w.themes.filter(t => t.name !== 'No Theme').length)} />}
      {showCat && <Kpi icon="tag" label={L('ins.categories')} value={fmt(cats.length)} />}
      {has('volume') && w.volume?.activities > 0 && <Kpi icon="volume" label={L('ins.volume')} onClick={() => setModal({ kind: 'browse', vol: 'with' })}
        foot={<VolPair total={w.volume.per_day} file={w.volume.file_per_day || 0} />} />}
      {T0 && <Kpi icon="list" label="Daily Workload" value={`${w.fte.toFixed(1)} FTE`} sub={`${hrs(w.hours)} Man-Hours a Day`} />}
      {has('automation') && <Kpi icon="bolt" tone="amber" label={L('ins.auto')} value={fmt(w.automation.activities)} sub={`${fmt(w.automation.staff)} Employees`}
        viz={<Ring value={autoPct} color="var(--amber)" track="var(--amber-soft)" />} disabled={!w.automation.activities} onClick={() => acts('Candidates for Automation', { automation: 'Yes' })} />}
    </div>}

    {!w ? <div className="loading">{work?.error ? 'Could not load activity figures.' : 'Loading activity figures…'}</div>
      : !w.activities ? <div className="empty"><b>No activities recorded yet for this selection.</b><br />Figures appear here as function POCs complete data capture.</div> : <>
      <div className={'grid ins-grid' + (side && (showTh || showCat) ? '' : ' one')}>
        {(showTh || showCat) && <div className="ins-main">
        {showTh && <ThemePanel w={w} acts={acts} />}
        {showCat && <div className="panel">
          <div className="rhead"><div><h3>{L('ins.catpanel')}</h3></div></div>
          {!cats.length && <p className="formula">No activity categories recorded yet.</p>}
          <CatList cats={ranked.slice(0, 10)} base={w.staff_with_work} onPick={c => acts(c.name, { category: c.name })} />
          {cats.length > 10 && <div className="pfoot">{cats.length > 10 ? <button className="linkbtn" onClick={() => setModal({ kind: 'cats', cats: [...ranked, ...(uncat ? [uncat] : [])], base: w.staff_with_work })}>View All {fmt(cats.length)} Categories ›</button> : <span />}</div>}
        </div>}
        </div>}
        {side && <div className="ins-side">
          {has('handling') && <div className="panel">
            <div className="ins-donut">
              <div className="ins-ring"><ChartBox deps={[w, theme]} config={() => ({ type: 'doughnut', data: { labels: w.handling.map(h => h.name), datasets: [{ data: w.handling.map(h => h.activities), backgroundColor: w.handling.map(h => css(natVar(h.name))), borderColor: css('--surface'), borderWidth: 2 }] },
                options: { cutout: '70%', onClick: (e, el) => { if (el.length) { const h = w.handling[el[0].index]; acts(`${h.name} activities`, { handling: h.name }) } }, plugins: { legend: { display: false } } } })} />
                <div className="ins-center"><b>{pcs(manual.activities, handled)}</b><span>{manual.name}</span></div></div>
              <ul className="rv-legend">{w.handling.map(h => <li key={h.name}><button disabled={!h.activities} onClick={() => acts(`${h.name} activities`, { handling: h.name })}>
                <i style={{ background: natCol(h.name) }} /><span>{h.name}</span><b>{pcs(h.activities, handled)}</b></button></li>)}</ul>
            </div>
          </div>}
          {has('automation') && <div className="panel">
            <h3>{L('ins.autopanel')}</h3>
            <div className="gauge"><ChartBox deps={[w, theme]} config={() => ({ type: 'doughnut', data: { datasets: [{ data: [w.automation.activities, w.activities - w.automation.activities], backgroundColor: [css('--teal'), css('--surface-2')], borderWidth: 0 }] },
              options: { rotation: -90, circumference: 180, cutout: '74%', plugins: { legend: { display: false }, tooltip: { enabled: false } } } })} />
              <div className="gauge-c"><b>{autoPct}%</b><span>{fmt(w.automation.activities)} of {fmt(w.activities)} activities</span></div></div>
            {has('handling') && w.automation.activities > 0 && <div className="chips" style={{ justifyContent: 'center' }}>{w.automation.by_handling.filter(x => x.activities).map(x => <span key={x.name} className="hchip"><i style={{ background: natCol(x.name) }} />{x.name}: <b>{pcs(x.activities, w.automation.activities)}</b></span>)}</div>}
            {w.automation.activities > 0 && <div style={{ textAlign: 'center' }}><button className="linkbtn" onClick={() => acts('Candidates for automation', { automation: 'Yes' })}>View the activities ›</button></div>}
          </div>}
          {has('frequency') && w.frequency?.length > 0 && <div className="panel">
            <h3>{L('ins.freq')}</h3>
            <ul className="ins-bars">{w.frequency.map(f => <li key={f.name}><button onClick={() => acts(`${f.name} activities`, { frequency: f.name })}>
              <span>{f.name}</span><i className="bar thin"><i style={{ width: pct(f.activities, w.frequency[0].activities) + '%', background: 'var(--teal)' }} /></i>
              <b>{pcs(f.activities, w.activities)}</b><em>{fmt(f.staff)} employee{f.staff === 1 ? '' : 's'}</em></button></li>)}</ul>
          </div>}
        </div>}
      </div>

      {has('volume') && w.volume?.activities > 0 && <VolumePanel v={w.volume} single={w.by_function.filter(f => f.activities).length <= 1} theme={theme} acts={acts} byTheme={showTh} byCat={showCat} />}
      {w.by_function.filter(f => f.activities).length > 1 && <div style={{ marginTop: 18 }}><FunctionChart w={w} has={has} theme={theme} acts={acts} mode="handling" /></div>}
      <EmployeeRanking sel={sel} includeFlagged={includeFlagged} et={et} role={role} multi={w.by_function.length > 1} showLine={showLine} />
    </>}
    {modal?.kind === 'cats' && <BrowseModal startByTheme={false} title={L('ins.catpanel')} flt={flt} sel={sel} includeFlagged={includeFlagged} onClose={() => setModal(null)} />}
    {modal?.kind === 'browse' && <BrowseModal title={L('ins.activities')} vol={modal.vol} flt={flt} sel={sel} includeFlagged={includeFlagged} onClose={() => setModal(null)} />}
    {modal?.kind === 'acts' && <ActivitiesModal {...modal} sel={sel} includeFlagged={includeFlagged} onClose={() => setModal(null)} />}
  </section>
}


// activities of each function, split by processing mode (or one colour when processing mode is hidden)
const RVAR = { Service: '--svc', Support: '--sup' }
function FunctionChart({ w, has, theme, acts, mode }) {
  const fns = w.by_function.filter(f => f.activities).sort((a, b) => b.activities - a.activities)
  const isRole = mode === 'role'
  const split = isRole || has('handling')
  const vars = isRole ? RVAR : Object.fromEntries(prefs.nature.options.map(n => [n, natVar(n)]))
  const segs = Object.keys(vars)
  const val = (f, m) => isRole ? (m === 'Service' ? f.service_activities : f.support_activities) || 0 : (f.handling || {})[m] || 0
  const rest = isRole ? 'Not yet marked' : 'Not recorded'
  const title = isRole ? 'Service or Support Work by Function' : L('ins.byfunction')
  const total = { id: 'fnTotals', afterDatasetsDraw(chart) {
    const { ctx } = chart, meta = chart.getDatasetMeta(0)
    fns.forEach((f, i) => { const bar = meta.data[i]; if (!bar) return
      ctx.save(); ctx.fillStyle = css('--ink'); ctx.font = '700 12px Manrope, Segoe UI, sans-serif'; ctx.textBaseline = 'middle'
      ctx.fillText(Number(f.activities).toLocaleString('en-US'), chart.scales.x.getPixelForValue(f.activities) + 8, bar.y); ctx.restore() })
  } }
  const labels = [...segs, rest]
  const segName = m => isRole ? m + ' employees' : m
  return <div className="panel">
    <div className="rhead"><h3>{title}</h3>{split && <span className="legend">{segs.map(m => <span key={m}><i style={{ background: `var(${vars[m]})` }} />{segName(m)}</span>)}{fns.some(f => f.activities > segs.reduce((a, m) => a + val(f, m), 0)) && <span><i style={{ background: 'var(--none)' }} />{rest}</span>}</span>}</div>
    <div className="rv-bars" style={{ height: Math.max(200, fns.length * 38 + 30) }}>
      <ChartBox deps={[w, theme, mode]} config={() => ({ type: 'bar', plugins: [total],
        data: { labels: fns.map(f => f.name), datasets: split
          ? [...segs.map(m => ({ label: segName(m), data: fns.map(f => val(f, m)), backgroundColor: css(vars[m]), borderRadius: 3, barThickness: 20 })),
             { label: rest, data: fns.map(f => Math.max(0, f.activities - segs.reduce((a, m) => a + val(f, m), 0))), backgroundColor: css('--none'), borderRadius: 3, barThickness: 20 }]
          : [{ label: 'Activities', data: fns.map(f => f.activities), backgroundColor: css('--teal'), borderRadius: 4, barThickness: 20 }] },
        options: { indexAxis: 'y', layout: { padding: { right: 44 } },
          onClick: (e, el) => { if (!el.length) return; const f = fns[el[0].index], m = split ? labels[el[0].datasetIndex] : null, seg = m && m !== rest
            acts(seg ? `${f.name}: ${segName(m)}` : f.name, seg ? (isRole ? { functions: String(f.id), role: m } : { functions: String(f.id), handling: m }) : { functions: String(f.id) }) },
          onHover: (e, el) => { e.native.target.style.cursor = el.length ? 'pointer' : 'default' },
          scales: { x: { stacked: true, ticks: { precision: 0 }, grid: { color: css('--line') } }, y: { stacked: true, grid: { display: false }, ticks: { callback(v) { const t = this.getLabelForValue(v); return t.length > 28 ? t.slice(0, 27) + '…' : t } } } },
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => ` ${c.dataset.label}: ${Number(c.raw).toLocaleString('en-US')}` } } } } })} />
    </div>
  </div>
}

// activity themes: each theme with its employees and activities; its categories underneath
function ThemePanel({ w, acts }) {
  const [all, setAll] = useState(false)
  const top = w.themes.slice(0, 10)   // the 10 largest; the rest in a popup
  return <div className="panel">
    <div className="rhead"><h3>{L('ins.themepanel')}</h3>{w.themes.length > 10 && <span className="formula">Top 10 of {fmt(w.themes.length)}</span>}</div>
    <ThemeRows ts={top} all={w.themes} acts={acts} />
    {w.themes.length > 10 && <div className="pfoot"><span /><button className="linkbtn" onClick={() => setAll(true)}>View All {fmt(w.themes.length)} Themes ›</button></div>}
    {all && <Modal wide title={L('ins.themepanel')} sub={`${fmt(w.themes.length)} themes`} onClose={() => setAll(false)}>
      <ThemeRows ts={w.themes} all={w.themes} acts={(...x) => { setAll(false); acts(...x) }} /></Modal>}
  </div>
}

function ThemeRows({ ts, all, acts }) {
  const max = Math.max(1, ...all.map(t => t.staff))
  return <ul className="th-list">{ts.map(t => <li key={t.name} className={t.name === 'No Theme' ? 'none' : ''}>
    <button type="button" className="th-row" onClick={() => acts(t.name, { theme: t.name })}>
      <span className="th-dot" style={{ background: themeColor(t.name) }} />
      <span className="th-name"><b>{t.name}</b></span>
      <span className="th-bar"><i style={{ width: t.staff / max * 100 + '%', background: themeColor(t.name) }} /></span>
      <span className="th-val"><b>{fmt(t.staff)}</b> employees<small>{[t.functions > 1 && `${fmt(t.functions)} functions`, `${fmt(t.activities)} activities`].filter(Boolean).join(' · ')}</small>
        {(t.fte_staff > 0 || t.ftc_staff > 0) && <small className="th-fx">FTE {fmt(t.fte_staff) === '-' ? 0 : fmt(t.fte_staff)} · FTC {fmt(t.ftc_staff) === '-' ? 0 : fmt(t.ftc_staff)}</small>}</span>
      <span className="th-caret">›</span></button></li>)}</ul>
}

// volume per day: by function (or by unit when one function is on show) and by activity category
function VolumePanel({ v, single, theme, acts, byTheme, byCat }) {
  const left = single && v.by_unit.length > 1 ? { title: L('ins.vol.unit'), rows: v.by_unit, pick: r => acts(`${r.name}: activities with volume`, { volume: 'true', units: r.name }) }
    : { title: L('ins.vol.function'), rows: v.by_function, pick: r => acts(`${r.name}: activities with volume`, { volume: 'true', functions: String(r.id) }) }
  // the second chart follows the admin's settings: by activity theme when themes are shown, otherwise by category
  const right = byTheme ? { title: L('ins.vol.theme'), rows: (v.by_theme || []).slice(0, 10), pick: r => acts(`${r.name}: activities with volume`, { volume: 'true', theme: r.name }) }
    : byCat ? { title: L('ins.vol.category'), rows: v.by_category.slice(0, 10), pick: r => acts(`${r.name}: activities with volume`, { volume: 'true', category: r.name }) } : null
  const boxes = [left, right].filter(Boolean)
  return <div className={'grid vol-grid' + (boxes.length > 1 ? ' g2' : '')} style={{ marginTop: 18 }}>
    {boxes.map((b, k) => <div key={k} className="panel">
      <div className="rhead"><h3>{b.title}</h3>{b.rows.some(r => r.file_per_day > 0) && <span className="legend"><span><i style={{ background: VOL_COL.txn }} />{L('vol.txn')}</span><span><i style={{ background: VOL_COL.file }} />{L('vol.file')}</span></span>}</div>
      <VolBars rows={b.rows.slice(0, 10)} onPick={b.pick} theme={theme} />
    </div>)}
  </div>
}

function VolBars({ rows, onPick, theme }) {
  // each bar: activity based and file based volume, stacked; after the bar the two figures (not a total)
  const split = rows.some(r => r.file_per_day > 0)
  const txn = r => Math.max(0, r.per_day - (r.file_per_day || 0))
  const lab = { id: 'volLabels', afterDatasetsDraw(chart) {
    const { ctx } = chart, meta = chart.getDatasetMeta(chart.data.datasets.length - 1)
    rows.forEach((r, i) => { const bar = meta.data[i]; if (!bar) return
      let x = chart.scales.x.getPixelForValue(r.per_day) + 8
      ctx.save(); ctx.font = '700 11.5px Manrope, Segoe UI, sans-serif'; ctx.textBaseline = 'middle'
      const parts = split ? [[txn(r), css('--x-txn')], [r.file_per_day || 0, css('--x-file')]].filter(([v]) => v > 0) : [[r.per_day, null]]
      parts.forEach(([v, c]) => {
        if (c) { ctx.fillStyle = c; ctx.fillRect(x, bar.y - 4, 8, 8); x += 11 }
        const t = vfmt(v); ctx.fillStyle = css('--ink'); ctx.fillText(t, x, bar.y); x += ctx.measureText(t).width + 10 })
      ctx.restore() })
  } }
  const tip = c => ` ${split ? c.dataset.label + ': ' : ''}${vfmt(c.raw)} a day`
  return <div className="rv-bars" style={{ height: Math.max(160, rows.length * 34 + 30) }}>
    <ChartBox deps={[rows, theme]} config={() => ({ type: 'bar', plugins: [lab],
      data: { labels: rows.map(r => r.name), datasets: split
        ? [{ label: L('vol.txn'), data: rows.map(txn), backgroundColor: css('--x-txn'), borderRadius: 3, barThickness: 18 },
           { label: L('vol.file'), data: rows.map(r => r.file_per_day || 0), backgroundColor: css('--x-file'), borderRadius: 3, barThickness: 18 }]
        : [{ label: L('ins.volume'), data: rows.map(r => r.per_day), borderRadius: 4, barThickness: 18, backgroundColor: css('--x-txn') }] },
      options: { indexAxis: 'y', layout: { padding: { right: split ? 118 : 56 } },
        onClick: (e, el) => { if (el.length) onPick(rows[el[0].index]) },
        onHover: (e, el) => { e.native.target.style.cursor = el.length ? 'pointer' : 'default' },
        scales: { x: { stacked: true, grid: { color: css('--line') }, ticks: { precision: 0, callback: v => vfmt(v) } }, y: { stacked: true, grid: { display: false }, ticks: { callback(val) { const t = this.getLabelForValue(val); return t.length > 30 ? t.slice(0, 29) + '…' : t } } } },
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: tip, footer: items => `${rows[items[0].dataIndex].activities} activities` } } } } })} />
  </div>
}

// the two volumes side by side (activity based and file based), not added together
export function VolPair({ total, file }) {
  const f = file || 0, t = Math.max(0, (total || 0) - f)
  return <span className="ex-vpair">
    <span title={Math.round(t).toLocaleString('en-US') + ' a day'}><em><i style={{ background: 'var(--x-txn)' }} />{L('vol.txn')}</em><b>{vfmt(t)}</b></span>
    <span title={Math.round(f).toLocaleString('en-US') + ' a day'}><em><i style={{ background: 'var(--x-file)' }} />{L('vol.file')}</em><b>{vfmt(f)}</b></span>
  </span>
}

function CatList({ cats, base, start = 1, onPick }) {
  const T0 = prefs.showTime
  const max = Math.max(1, ...cats.map(c => T0 ? c.hours : c.staff))
  return <ol className="catlist">{cats.map((c, i) => <li key={c.name}><button onClick={() => onPick(c)}>
    <span className="cn">{start + i}</span>
    <span className="ct"><b>{c.name}</b><span className="bar thin"><i style={{ width: (T0 ? c.hours : c.staff) / max * 100 + '%' }} /></span></span>
    <span className="cv">{T0 ? <><b>{c.fte.toFixed(1)}</b> FTE</> : <><b>{fmt(c.staff)}</b> employee{c.staff === 1 ? '' : 's'}</>}<small>{T0 ? `${fmt(c.staff)} employees` : `${pcs(c.staff, base)} of employees`}</small></span>
  </button></li>)}</ol>
}

// employees ranked by the number of activities; click for their categories, then the activities
function EmpTable({ rows, all, multi, onPick, max }) {
  const unit = all.some(r => r.unit), reg = all.some(r => r.region), role = all.some(r => r.service_type)
  return <div className="tw"><table className="ranktab">
    <thead><tr><th className="num">#</th><th>Employee</th>{multi && <th>Function</th>}{unit && <th>Unit</th>}{reg && <th>Region</th>}{role && <th>Type of Work</th>}<th style={{ width: '22%' }}>Activities</th></tr></thead>
    <tbody>{rows.map(r => <tr key={r.code} className="click" onClick={() => onPick(r)}>
      <td className="num formula">{all.indexOf(r) + 1}</td>
      <td><b>{r.name}</b><div className="formula">{[r.position, r.grade].filter(Boolean).join(' · ')}</div></td>
      {multi && <td>{r.function}</td>}{unit && <td>{r.unit}</td>}{reg && <td>{r.region}</td>}
      {role && <td>{r.service_type && <span className="tpill" style={{ '--tc': TYPE_COL[r.service_type] }}>{r.service_type}</span>}</td>}
      <td><div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><div className="bar thin" style={{ flex: 1, minWidth: 60 }}><i style={{ width: r.activities / max * 100 + '%', background: 'var(--teal)' }} /></div><b style={{ minWidth: 24, textAlign: 'right' }}>{fmt(r.activities)}</b></div></td></tr>)}
      {!rows.length && <tr><td colSpan={7} className="formula">No one matches.</td></tr>}</tbody></table></div>
}

function EmployeeRanking({ sel, includeFlagged, et, role, multi, showLine }) {
  const [all, setAll] = useState(false)
  const [q, setQ] = useState('')
  const [pick, setPick] = useState(null)
  const [d] = useLive(() => api(`/api/dashboard/employees?functions=${(sel || []).join(',')}&include_flagged=${includeFlagged}&emp_type=${et}&role=${role || ''}&limit=2000${unitQS()}`).catch(() => ({ rows: [], total: 0 })),
    [(sel || []).join(','), includeFlagged, et, role, unitQS()])
  if (!d) return <div className="loading">Loading employees…</div>
  const max = Math.max(1, ...d.rows.map(r => r.activities))
  const ql = q.trim().toLowerCase()
  const found = d.rows.filter(r => !ql || (r.name + ' ' + r.code + ' ' + r.position + ' ' + r.unit + ' ' + r.function + ' ' + r.region).toLowerCase().includes(ql))
  return <div className="panel" style={{ marginTop: 18 }}>
    <div className="rhead"><div><h3>{L('ins.ranking')}</h3></div>
      {d.total > 10 && <button className="btn" onClick={() => setAll(true)}>View All {fmt(d.total)}</button>}</div>
    <EmpTable rows={d.rows.slice(0, 10)} all={d.rows} multi={multi} onPick={setPick} max={max} />
    {all && <Modal wide onClose={() => setAll(false)} title={L('ins.ranking')} sub={`${fmt(d.total)} employees`}>
      <input className="inp" placeholder="Find an employee, unit or region" value={q} onChange={e => setQ(e.target.value)} style={{ marginBottom: 10, minWidth: 280 }} />
      <EmpTable rows={found.slice(0, 500)} all={d.rows} multi={multi} onPick={setPick} max={max} />
      {found.length > 500 && <p className="formula">Showing 500 of {fmt(found.length)}. Search to narrow the list.</p>}</Modal>}
    {pick && <EmployeeCats emp={pick} sel={sel} includeFlagged={includeFlagged} et={et} role={role} showLine={showLine} onClose={() => setPick(null)} />}
  </div>
}

function EmployeeCats({ emp, sel, includeFlagged, et, role, showLine, onClose }) {
  return <Modal wide onClose={onClose} title={emp.name}
    sub={[emp.position, emp.grade, emp.function, emp.unit, emp.region, emp.service_type].filter(Boolean).join(' · ')}>
    {showLine && <div className="row-actions" style={{ marginBottom: 8 }}><button className="btn" onClick={() => showLine(emp.code)}>Reporting Line</button></div>}
    <ThemeCatBrowser filter={{ emp_type: et || '', role: role || '', code: emp.code }} sel={sel} includeFlagged={includeFlagged} />
  </Modal>
}

// the volume choices of the filter bar, and the query each one sends
const volQ = v => v === 'with' ? { volume: 'true' } : v === 'without' ? { novolume: 'true' } : v === 'file' || v === 'txn' ? { vtype: v } : {}
const volOf = f => f.vtype === 'file' || f.vtype === 'txn' ? f.vtype : f.volume ? 'with' : f.novolume ? 'without' : ''

// Activities by theme or by category: tick By Theme for theme > category > activities, untick for category > activities.
// filterBar: a bar on top to narrow by function (several functions on show) or unit (one function), and by volume
// (volume based, activity based, file based, non volume based); it starts from what was clicked.
export function ThemeCatBrowser({ filter, sel, includeFlagged = true, startByTheme = true, initTheme = null, initCat = null, filterBar = false }) {
  const canTheme = prefs.showThemes
  const [byTheme, setByTheme] = useState(canTheme && startByTheme && (!initCat || !!initTheme))
  const [th, setTh] = useState(initTheme)  // the theme opened
  const [cat, setCat] = useState(initCat)  // the category opened ('*' = every activity of the theme)
  const [q, setQ] = useState('')
  const [qq, setQq] = useState('')          // the search, a moment after typing stops
  // the filter bar: what was clicked fills it in; the rest of the filter stays as given
  const { volume: _v, novolume: _n, vtype: _t, functions: f0, units: u0, ...base0 } = filter
  const many = f0 && String(f0).includes(',')   // several functions given: they stay the scope
  const base = many ? { ...base0, functions: f0 } : base0
  const [fv, setFv] = useState(() => ({ vol: volOf(filter), fn: f0 && !many ? String(f0) : '', unit: u0 || '' }))
  const [opts, setOpts] = useState(null)    // { fns, units, vol }: the choices
  useEffect(() => { const t = setTimeout(() => setQq(q.trim()), 300); return () => clearTimeout(t) }, [q])
  const eff = filterBar ? { ...base, ...volQ(fv.vol), ...(fv.fn ? { functions: fv.fn } : {}), ...(fv.unit ? { units: fv.unit } : {}) } : filter
  const fkey = JSON.stringify(filter), ekey = JSON.stringify(eff)
  const fns0 = (sel || []).join(',')
  useEffect(() => { setTh(initTheme); setCat(initCat) }, [fkey])
  const [d, dBusy] = useLive(() => api('/api/dashboard/activities?' + new URLSearchParams({ functions: fns0, include_flagged: includeFlagged, ...eff, groups: 'true' }) + (eff.units ? '' : unitQS()))
    .catch(() => ({ rows: [], total: 0, groups: { themes: [], categories: [] } })), [ekey, fns0, includeFlagged])
  useEffect(() => {   // the choices: functions on show (without the bar's own choices), and the units of the function chosen
    if (!filterBar) return
    // limited to the theme or category opened, so every function and unit offered has activities there
    const where = { ...(th ? { theme: th } : {}), ...(cat && cat !== '*' ? { category: cat } : {}) }
    const one = (fn) => api('/api/dashboard/activities?' + new URLSearchParams({ functions: fns0, include_flagged: includeFlagged, ...base, ...where, ...(fn ? { functions: fn } : {}), groups: 'true', limit: '0' }) + unitQS())
    Promise.all([one(''), fv.fn ? one(fv.fn) : null]).then(([a, b]) => setOpts({ fns: a.groups.functions || [], units: ((b || a).groups.units) || [], vol: (a.groups.per_day || 0) > 0 }))
      .catch(() => setOpts({ fns: [], units: [], vol: false }))
  }, [JSON.stringify(base), fv.fn, fns0, includeFlagged, th, cat])
  const setF = (k, v) => setFv(x => ({ ...x, [k]: v, ...(k === 'fn' ? { unit: '' } : {}) }))
  if (!d) return <div className="loading" style={{ padding: 16 }}>Loading…</div>
  const g = d.groups || { themes: [], categories: [] }
  const showTick = canTheme && g.themes.some(t => t.name !== 'No Theme') && !catHidden()
  const useTh = canTheme && g.themes.some(t => t.name !== 'No Theme') && (byTheme || catHidden())
  const tRow = useTh && th ? g.themes.find(t => t.name === th) : null
  const crumbs = [{ l: useTh ? 'All Themes' : 'All Categories', go: () => { setTh(null); setCat(null) } }]
  if (useTh && th) crumbs.push({ l: th })
  else if (cat) crumbs.push({ l: cat === '*' ? 'All Activities' : cat })
  const lf = { ...eff, ...(cat && cat !== '*' ? { category: cat } : {}), ...(th ? { theme: th } : {}) }
  let body
  if (qq) body = <ActivityList filter={{ ...lf, q: qq }} sel={sel} includeFlagged={includeFlagged} />
  else if (cat) body = <ActivityList filter={lf} sel={sel} includeFlagged={includeFlagged} />
  else if (tRow) body = <><GroupRows rows={tRow.categories} onPick={r => setCat(r.name)} />
    <button type="button" className="linkbtn" style={{ marginTop: 8 }} onClick={() => setCat('*')}>View All {fmt(tRow.activities)} Activities of {th} ›</button></>
  else if (useTh) body = <GroupRows rows={g.themes} onPick={r => { setTh(r.name); setCat('*') }} themed />
  else body = <GroupRows rows={g.categories} sub={r => themeOf(r.name)} onPick={r => setCat(r.name)} />
  const fnList = opts?.fns || [], unitList = opts?.units || []
  const oneFn = !!fv.fn || fnList.length === 1
  // the bar: function first (unit once a function is chosen, or when only one function is on show);
  // volume first (activity or file based once Volume Based is chosen)
  const isVol = ['with', 'txn', 'file'].includes(fv.vol)
  const bar = filterBar && opts && (fnList.length > 1 || (oneFn && unitList.length > 1) || opts.vol) && <div className="tcb-filters">
    {fnList.length > 1 && <label className="tcb-f"><span>Function</span><select value={fv.fn} onChange={e => setF('fn', e.target.value)}>
      <option value="">All functions</option>{fnList.map(f => <option key={f.id} value={String(f.id)}>{f.name} ({fmt(f.activities)})</option>)}</select></label>}
    {oneFn && unitList.length > 1 && <label className="tcb-f"><span>Unit</span><select value={fv.unit} onChange={e => setF('unit', e.target.value)}>
      <option value="">All units</option>{unitList.map(u => <option key={u.name} value={u.name}>{u.name} ({fmt(u.activities)})</option>)}</select></label>}
    {opts.vol && <span className="seg sm tcb-vol" role="group" aria-label="Volume">{[['', 'All Activities'], ['with', L('ins.volbased')], ['without', L('ins.nonvol')]].map(([k, l]) =>
      <button key={k} type="button" aria-pressed={k === 'with' ? isVol : fv.vol === k} onClick={() => setF('vol', k)}>{l}</button>)}</span>}
    {opts.vol && isVol && <span className="seg sm tcb-vol" role="group" aria-label="Volume type">{[['with', 'All Volume'], ['txn', L('vol.txn')], ['file', L('vol.file')]].map(([k, l]) =>
      <button key={k} type="button" aria-pressed={fv.vol === k} onClick={() => setF('vol', k)}>{l}</button>)}</span>}
    {(fv.fn || fv.unit || fv.vol) && <button type="button" className="linkbtn" onClick={() => setFv({ vol: '', fn: '', unit: '' })}>Clear Filters</button>}
  </div>
  return <div className={'tcb' + (dBusy ? ' busy' : '')}>
    {bar}
    <div className="tcb-bar">
      <div className="tcb-crumbs">{crumbs.map((c, i) => <React.Fragment key={i}>{i > 0 && <span className="tcb-sep">›</span>}
        {c.go && i < crumbs.length - 1 ? <button type="button" className="linkbtn" onClick={c.go}>{c.l}</button> : <b>{c.l}</b>}</React.Fragment>)}</div>
      <input className="inp tcb-search" type="search" placeholder={`Search ${cat && cat !== '*' ? cat : th || 'activities'}: employee, description, process…`} value={q} onChange={e => setQ(e.target.value)} />
      {!qq && <span className="formula">{fmt(tRow ? tRow.activities : d.total)} activities</span>}
      {showTick && <label className="chk tcb-tick"><input type="checkbox" checked={byTheme} onChange={e => { setByTheme(e.target.checked); setTh(null); setCat(null) }} /><span>By Theme</span></label>}
    </div>
    {!d.total ? <p className="formula">No activities{filterBar && (fv.fn || fv.unit || fv.vol) ? ' for these filters' : ''}.</p> : (tRow || !th || !useTh) ? body : <p className="formula">No activities of {th} for these filters.</p>}
  </div>
}

function GroupRows({ rows, onPick, sub, themed }) {
  const max = Math.max(1, ...rows.map(r => r.activities))
  return <ul className="tcb-rows">{rows.map((r, i) => <li key={r.name}><button type="button" onClick={() => onPick(r)}>
    <span className="th-dot" style={themed ? { background: themeColor(r.name) } : { visibility: 'hidden', width: 0 }} />
    <span className="tcb-n"><b>{r.name}</b>{sub && sub(r) && <small>{sub(r)}</small>}</span>
    <span className="bar thin"><i style={{ width: r.activities / max * 100 + '%', background: themed ? themeColor(r.name) : 'var(--teal)' }} /></span>
    <span className="tcb-v"><b>{fmt(r.activities)}</b> activit{r.activities === 1 ? 'y' : 'ies'}<small>{fmt(r.staff)} employee{r.staff === 1 ? '' : 's'}</small></span>
    <span className="th-go">›</span></button></li>)}</ul>
}

function BrowseModal({ title, vol, flt, sel, includeFlagged, onClose, startByTheme = true }) {
  return <Modal wide title={title} onClose={onClose}>
    <ThemeCatBrowser filter={{ ...flt, ...volQ(vol || '') }} sel={sel} includeFlagged={includeFlagged} startByTheme={startByTheme} filterBar />
  </Modal>
}

function ActivityList({ filter, sel, includeFlagged = true }) {
  const [d, busy] = useLive(() => api('/api/dashboard/activities?' + new URLSearchParams({ functions: (sel || []).join(','), include_flagged: includeFlagged, ...filter }) + (filter.units ? '' : unitQS()))
    .catch(() => ({ rows: [], total: 0 })), [JSON.stringify(filter), (sel || []).join(','), includeFlagged])
  const [emp, setEmp] = useState(null)   // the employee opened (the same popup as Employee Activities)
  if (!d) return <div className="loading" style={{ padding: 16 }}>Loading…</div>
  const has = f => !d.fields || d.fields.includes(f)
  const proc = has('process') || has('product') || has('channel')
  return <div className={'actlist' + (busy ? ' busy' : '')}>
    {filter.q && <p className="formula" style={{ margin: '0 0 8px' }}>{d.total ? `${fmt(d.total)} activit${d.total === 1 ? 'y' : 'ies'} found` : 'No activities match the search.'}</p>}
    <div className="tw"><table className="acttab">
      <thead><tr><th>Employee</th>{proc && <th>{has('process') ? 'Process' : 'Product / channel'}</th>}<th style={{ minWidth: 280 }}>Activity</th>{has('frequency') && <th>Frequency</th>}{has('volume') && <th className="num">Avg Volume</th>}{prefs.showTime && <><th className="num">Min / Item</th><th className="num">Daily H</th></>}{has('handling') && <th>{prefs.nature.label}</th>}{has('automation') && <th>Automation</th>}</tr></thead>
      <tbody>{d.rows.map(r => <tr key={r.id}>
        <td><button type="button" className="emp-link" onClick={() => setEmp(r)} title="Open this employee's activities">{r.name}</button><div className="formula">{[r.grade, r.region, sel?.length === 1 ? '' : r.function].filter(Boolean).join(' · ')}</div></td>
        {proc && <td>{has('process') && r.process}<div className="formula">{[r.unit, has('product') && r.product, has('channel') && r.channel].filter(Boolean).join(' · ')}</div></td>}
        <td>{has('category') && (catHidden()
          ? (!filter.theme && <b style={{ fontWeight: 650 }}>{themeOf(r.category) || 'No theme'}</b>)
          : (!filter.category && r.category && <>{!filter.theme && themeOf(r.category) && <div className="formula">{themeOf(r.category)}</div>}<b style={{ fontWeight: 650 }}>{r.category}</b></>))}{has('description') && <Expand text={r.description} />}</td>
        {has('frequency') && <td>{r.frequency}</td>}{has('volume') && <td className="num" title={r.volume != null ? num2(r.volume) : ''}>{r.volume != null ? vfmt(r.volume) : ''}{r.volume_type === VOL_FILE && <div className="formula">{L('vol.file')}</div>}</td>}{prefs.showTime && <><td className="num">{r.minutes ?? ''}</td><td className="num"><b>{r.daily_hours.toFixed(2)}</b></td></>}
        {has('handling') && <td>{r.handling}</td>}{has('automation') && <td>{r.automation}</td>}</tr>)}</tbody></table></div>
    {d.total > d.rows.length && <p className="formula">Showing {fmt(d.rows.length)} of {fmt(d.total)}.</p>}
    {emp && <EmployeePopup code={emp.code} fid={emp.function_id} codes={d.rows.filter(r => r.function_id === emp.function_id).map(r => r.code)} onClose={() => setEmp(null)} />}
  </div>
}

// the activities behind a figure: by theme or category (with search), or the list itself when one category is chosen
function ActivitiesModal({ title, filter, sel, includeFlagged, onClose }) {
  const { theme: th, category: ct, ...rest } = filter
  const one = ct != null && ct !== ''
  return <Modal title={title} sub={prefs.showTime ? 'Largest daily man-hours first' : undefined} onClose={onClose} wide>
    <ThemeCatBrowser filter={rest} sel={sel} includeFlagged={includeFlagged} filterBar
      initTheme={th || null} initCat={th ? '*' : one ? ct : null} startByTheme={!one} /></Modal>
}
