# Updating the VM to version 2.11 (keeps all captured data)

This update replaces **the code only**. The database (`portal.db`), `secret.key`, the SSL certificate and the Python environment (`venv`) stay exactly as they are. Nobody needs a new password.

On first start, version 2.11 makes these one-time changes to the existing data:

- **Nature of Work.** Old names are renamed: Manual → **Core Physical**, File Based → **System Based**, System Based → **Straight Through Processing (STP)**. A guard makes sure this runs only once.
- **Resigned staff.** Employees who report to someone marked resigned are moved to that person's line manager.
- **New columns.** Three empty columns are added: `users.view_units`, `feedback.change` and `feedback.function_id`. No existing data is touched.

VM folder: `/data/opt/ops-portal`. Service: `ops-portal`.

Run the steps one by one. Each block can be copied and pasted as a whole.

---

## Step 1: Copy the zip to the VM

From your PC, use WinSCP or Command Prompt:

```
scp ops-portal-v2.11-update.zip YOUR_VM_USER@hblassist.domestic.hbl.com:/tmp/
```

## Step 2: Back up first (do not skip)

This step stops the portal, then takes two backups:

- a **clean copy** made by SQLite's own backup, which is safe even with `-wal` files present;
- a **copy of the whole code folder**, so you can roll back.

```
sudo systemctl stop ops-portal
STAMP=$(date +%Y%m%d_%H%M)
sudo mkdir -p /data/opt/ops-portal/backups
sudo python3 -c "import sqlite3,sys; s=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); d=sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close(); print('database backed up')" /data/opt/ops-portal/backups/portal_before_2.11_$STAMP.db
sudo tar -czf /data/opt/ops-portal/backups/code_before_2.11_$STAMP.tgz -C /data/opt/ops-portal --exclude backend/venv --exclude backend/data --exclude backups .
sudo cp -a /data/opt/ops-portal/backend/data/secret.key /data/opt/ops-portal/backups/secret.key.$STAMP
ls -lh /data/opt/ops-portal/backups/
```

Next, check that the backup is readable and see how much it holds:

```
sudo python3 -c "import sqlite3,glob; f=sorted(glob.glob('/data/opt/ops-portal/backups/portal_before_2.11_*.db'))[-1]; c=sqlite3.connect(f); print(f); print(c.execute('pragma integrity_check').fetchone()[0], c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities')"
```

It must print `ok`, then your employee and activity counts. **Write the two numbers down.**

**Optional, recommended:** also copy the backup file to your PC with WinSCP. It is in `/data/opt/ops-portal/backups/`.

## Step 3: Install the new code

These commands leave three things untouched: `backend/data` (the database, key and SSL), `backend/venv` and `backups`.

```
rm -rf /tmp/ops-update && python3 -m zipfile -e /tmp/ops-portal-v2.11-update.zip /tmp/ops-update
ls /tmp/ops-update/ops-portal/backend/app/main.py && echo "zip OK"
sudo rsync -a --exclude 'backend/data' --exclude 'backend/venv' --exclude 'backups' --exclude 'wheels' /tmp/ops-update/ops-portal/ /data/opt/ops-portal/
```

If `rsync` is not installed, use this instead. It replaces only the program files:

```
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo cp -r /tmp/ops-update/ops-portal/backend/app /tmp/ops-update/ops-portal/backend/static /data/opt/ops-portal/backend/
sudo cp -r /tmp/ops-update/ops-portal/deploy /tmp/ops-update/ops-portal/UPDATE_v2.md /data/opt/ops-portal/
```

No `pip install` is needed: the Python libraries are the same as in 2.10.

## Step 4: Set the owner and permissions

This step also prevents the "readonly database" and "203/EXEC" errors you had before.

```
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 700 /data/opt/ops-portal/backend/data
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/secret.key
sudo chmod -R a+rX /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo chmod 755 /data/opt/ops-portal/backend/venv/bin/*
sudo semanage fcontext -a -t bin_t "/data/opt/ops-portal/backend/venv/bin(/.*)?" 2>/dev/null || true
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
```

If `semanage` says the rule already exists, that is fine.

## Step 5: Start the portal and check it

```
sudo systemctl start ops-portal
sleep 8
sudo systemctl status ops-portal --no-pager | head -5
sudo journalctl -u ops-portal -n 30 --no-pager
```

Check three things:

- The status shows **active (running)**.
- The log ends with `Application startup complete` and has no `Traceback`.
- The counts are the same as the ones you wrote down in step 2, and the old names are now the new ones. Run:

```
sudo -u opsportal python3 -c "import sqlite3; c=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); print(c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities'); print(c.execute('select handling, count(*) from work_items group by 1').fetchall())"
```

You should see **Core Physical**, **System Based** and **Straight Through Processing (STP)**, plus possibly a blank for activities with nothing recorded. **Manual** and **File Based** should no longer appear.

## Step 6: Check in the browser

1. Open https://hblassist.domestic.hbl.com and press **Ctrl+F5** so the browser loads the new version. Ask every user to press Ctrl+F5 once as well.
2. Sign in as admin with your usual password, then check each page:
   - **Sidebar:** Dashboard, Activity Insights, Employee Activities, Geographical Spread. The small "Insights" label is gone.
   - **Activity Insights:** Nature of Work with the new names and Daily Volume. Activity Themes stay hidden until you turn them on (see below).
   - **Admin, Activity Categories:** the review page (filters, possible duplicates, themes).
   - **Admin, Lists:** the Nature of Work block, where you can rename the heading and add, rename or remove options.
   - **Admin, Settings:** "Hide resigned employees everywhere" is ticked.
   - **Admin, Feedback:** "Requests from Data Capture" on top, then "Feedback and Employee Changes".
3. Clean up:

```
rm -rf /tmp/ops-update /tmp/ops-portal-v2.11-update.zip
```

---

## Activity themes: hidden until you turn them on

Themes are **off** after the update, so Activity Insights and the Excel export show nothing blank. Set them up and switch them on when ready:

1. Go to **Admin, Activity Categories** and type a theme name, for example *Governance and Control*. Click **Add Theme**.
2. Tick the categories that belong to it, choose the theme in the bar that appears, and click **Apply**. You can also pick a theme in the row's drop-down.
3. Tick **Show Themes on Activity Insights** at the top of the Activity Themes panel. The same switch is in **Admin, Settings**. Then:
   - Activity Themes appears **first** on Activity Insights, above Activity Category. Clicking a theme lists its categories with employees and activities; clicking a category opens its detailed activities.
   - The volume chart switches from "by Activity Category" to "by Activity Theme".
   - The Excel export gets the theme columns and the "Activity themes" sheet.

   - Wherever categories are listed (the Activities box, View All Categories, employee popups), a **By Theme** tick lets people go theme → categories → activities, or untick for category → activities.

   Untick it to hide them again; your themes are kept. **Show Categories**, next to it, hides or shows the Activity Category panel (categories still open from each theme).
4. **Possible Duplicates** lists near-identical spellings. Click **Tick These**, check the standard name, and click **Merge**. **Undo Last Merge** reverses it.

## Reviewing activities in Excel (descriptions, categories, themes)

**Admin, Activity Categories, Review in Excel**:

1. **Download Activities**. One row per activity. Edit only the green columns: *Activity description*, *Activity category*, *Activity theme*. Do not change the Activity ID or delete rows.
2. **Upload Changes**. A preview lists what will change. Nothing changes until you click **Apply Changes**.
3. **Undo Last Upload** puts everything back as it was before the last upload.

A file exported earlier with **Export** also works (sheet *Employee activities*). Add a column headed **Theme** for the themes. Rows whose activity has changed in the portal since the export are listed and left out.

**Best way to edit:** keep the exported columns untouched and add new columns headed **Revised description**, **Revised category**, **Revised frequency**, **Revised volume**, **Revised nature** and **Theme**. Fill in only what changes; blanks leave the portal's value. Frequency must be Daily, Weekly, Fortnightly, Monthly or Quarterly (or your own list in Admin, Lists) and Nature of Work one of its options; anything else is listed in the preview and skipped.

**Merged activities:** delete the extra rows in Excel and edit the remaining row (description, category, volume). In the preview, tick **Also remove these activities** to take the deleted rows out of the portal as well. Undo Last Upload brings them back.

## Renaming labels without a code change

**Admin, Labels** lists the page titles, sidebar items, boxes and chart headings of the Dashboard, Activity Insights and Geographical Spread. Type a new name next to any label and press Enter; it shows at once. Clear the box, or click **Reset**, to go back to the standard text.

## Unit logins

Go to **Admin, Users** and click **Create a login** (or **Edit access** on an existing login):

1. Under Dashboards, choose **Selected functions** and tick the function.
2. Tick one or more of its **units**.

The login then sees only those units: dashboard, insights, Employee Activities and export. The function head appears for context but is not counted.

---

## If something goes wrong: roll back to 2.10 (about 2 minutes)

This puts back the old code and the database exactly as it was before the update.

```
sudo systemctl stop ops-portal
DB=$(ls -t /data/opt/ops-portal/backups/portal_before_2.11_*.db | head -1); CODE=$(ls -t /data/opt/ops-portal/backups/code_before_2.11_*.tgz | head -1); echo "$DB"; echo "$CODE"
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo tar -xzf "$CODE" -C /data/opt/ops-portal
sudo cp "$DB" /data/opt/ops-portal/backend/data/portal.db
sudo rm -f /data/opt/ops-portal/backend/data/portal.db-wal /data/opt/ops-portal/backend/data/portal.db-shm
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
sudo systemctl start ops-portal
```

Rolling back the database also removes anything entered after the update. Do it only if the new version does not work.

## Daily backups (recommended, set up once)

```
sudo chmod +x /data/opt/ops-portal/deploy/backup_db.sh
( sudo crontab -l 2>/dev/null; echo "0 1 * * * /data/opt/ops-portal/deploy/backup_db.sh" ) | sudo crontab -
sudo /data/opt/ops-portal/deploy/backup_db.sh && ls -lh /data/opt/ops-portal/backups | tail -3
```

This keeps a clean copy every night at 01:00 in `/data/opt/ops-portal/backups` and deletes copies older than 30 days. To take a backup at any time, run `sudo /data/opt/ops-portal/deploy/backup_db.sh`.

To restore one of these backups, follow the rollback steps above but leave out the two `tar` and `rm -rf` lines, so that the current code stays:

```
sudo systemctl stop ops-portal
sudo cp /data/opt/ops-portal/backups/portal_YYYYMMDD_HHMM.db /data/opt/ops-portal/backend/data/portal.db
sudo rm -f /data/opt/ops-portal/backend/data/portal.db-wal /data/opt/ops-portal/backend/data/portal.db-shm
sudo chown opsportal:opsportal /data/opt/ops-portal/backend/data/portal.db
sudo systemctl start ops-portal
```

## Common problems

| What you see | What to do |
|---|---|
| `status` shows `failed` | Run `sudo journalctl -u ops-portal -n 50 --no-pager` and look at the last lines. |
| `203/EXEC` or "Permission denied" | Run step 4 again, then `sudo systemctl restart ops-portal`. |
| "attempt to write a readonly database" | Run the `chown` and `chmod` lines in step 4 again, then restart. |
| Old pages or old names still show | Press **Ctrl+F5** in the browser. |
| A user sees "This login sees only some units of this function" | It is a unit login. The template download and the review are whole-function pages, so only POCs and admins use them. |
