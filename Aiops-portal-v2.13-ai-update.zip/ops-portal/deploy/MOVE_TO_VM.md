# Moving the portal from your PC to the VM

This moves **everything** captured on your PC: employees, activities, logins and passwords, settings, feedback and the audit log. It replaces the database on the VM and installs the latest version at the same time.

PC folder: the portal folder on your PC (the one with `run_windows.bat`). VM folder: `/data/opt/ops-portal`.

---

## Part A: on your PC

1. **Stop the portal.** In the black window that runs it, press `Ctrl+C` and close the window. Also close the Cloudflare tunnel window. Nobody should enter data on the PC from now on.

2. **Make one clean copy of the database.** Open Command Prompt in the portal's `backend` folder (in File Explorer, open `backend`, type `cmd` in the address bar and press Enter), then run:

   ```
   .venv\Scripts\python -c "import sqlite3; s=sqlite3.connect('data/portal.db'); d=sqlite3.connect('portal_transfer.db'); s.backup(d); d.close(); s.close(); print('done')"
   ```

   This creates `backend\portal_transfer.db`: a single file holding everything. Do not copy `portal.db` by hand: its `-wal` file may hold the latest changes.

3. **Copy two files to the VM**, using WinSCP or Command Prompt:

   ```
   scp portal_transfer.db ops-portal-v2.10-update.zip YOUR_VM_USER@hblassist.domestic.hbl.com:/tmp/
   ```

---

## Part B: on the VM

Run these one by one.

1. **Stop the portal**

   ```
   sudo systemctl stop ops-portal
   ```

2. **Keep a backup of the VM's current database** (in case you need to go back)

   ```
   sudo mkdir -p /data/opt/ops-portal/backups
   sudo cp /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backups/portal_before_move_$(date +%Y%m%d_%H%M).db
   ```

3. **Check the PC database arrived intact**

   ```
   python3 -c "import sqlite3; c=sqlite3.connect('/tmp/portal_transfer.db'); print(c.execute('pragma integrity_check').fetchone()[0], c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities')"
   ```

   It should print `ok`, followed by your employee and activity counts.

4. **Install the latest version** (the code only; the data folder and the Python environment are left alone)

   ```
   rm -rf /tmp/ops-update && python3 -m zipfile -e /tmp/ops-portal-v2.10-update.zip /tmp/ops-update
   sudo rsync -a --exclude 'backend/data' --exclude 'backend/venv' /tmp/ops-update/ops-portal/ /data/opt/ops-portal/
   cd /data/opt/ops-portal/backend
   sudo chown -R opsportal:opsportal /data/opt/ops-portal
   sudo -u opsportal ./venv/bin/pip install --no-index --find-links ../wheels -r requirements.txt
   ```

   If `rsync` is not installed, use `sudo cp -r /tmp/ops-update/ops-portal/backend/app /tmp/ops-update/ops-portal/backend/static /data/opt/ops-portal/backend/` instead.

5. **Remove the VM database and put the PC database in its place**

   ```
   sudo rm -f /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/portal.db-wal /data/opt/ops-portal/backend/data/portal.db-shm
   sudo cp /tmp/portal_transfer.db /data/opt/ops-portal/backend/data/portal.db
   sudo chown opsportal:opsportal /data/opt/ops-portal/backend/data/portal.db
   sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db
   sudo restorecon -Rv /data/opt/ops-portal >/dev/null 2>&1 || true
   ```

   Keep the VM's `data/ssl` folder and `secret.key` as they are. Do not copy them from the PC.

6. **Start the portal and check it**

   ```
   sudo systemctl start ops-portal
   sudo systemctl status ops-portal --no-pager
   sudo journalctl -u ops-portal -n 30 --no-pager
   ```

   The status should show `active (running)`.

7. **Sign in** at https://hblassist.domestic.hbl.com with the **same admin login and password you use on your PC**. Logins and passwords come from the PC database, so the VM's old admin password no longer works. Check that the dashboard figures and a few employees' activities match your PC.

8. **Tidy up**

   ```
   rm -f /tmp/portal_transfer.db
   rm -rf /tmp/ops-update
   ```

Everyone has to sign in again once; that is expected.

---

## If something goes wrong: go back to the VM's old data

```
sudo systemctl stop ops-portal
sudo cp /data/opt/ops-portal/backups/portal_before_move_*.db /data/opt/ops-portal/backend/data/portal.db
sudo rm -f /data/opt/ops-portal/backend/data/portal.db-wal /data/opt/ops-portal/backend/data/portal.db-shm
sudo chown opsportal:opsportal /data/opt/ops-portal/backend/data/portal.db
sudo systemctl start ops-portal
```

(If there is more than one backup file, name the one you want instead of using `*`.)

## Common problems

| What you see | What to do |
|---|---|
| `status` shows `failed` | Run `sudo journalctl -u ops-portal -n 50 --no-pager` and look at the last error lines. |
| "attempt to write a readonly database" in the log | Run the `chown` and `chmod` lines in step 5 again, then `sudo systemctl restart ops-portal`. |
| The page loads but your login fails | Use the admin password from your PC. To reset it, sign in with another admin login and change it under Admin, Users. |
| Old pages still show after the update | Press `Ctrl+F5` in the browser. |
