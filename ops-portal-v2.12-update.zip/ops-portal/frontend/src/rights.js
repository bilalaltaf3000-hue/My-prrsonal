// What a signed-in user may do, derived from /api/auth/me
export const canDash = u => !!u && (u.is_admin || (u.view_functions || []).length > 0)
export const canInput = u => !!u && (u.is_admin || (u.input_functions || []).length > 0)
export const canRead = u => canDash(u) || canInput(u)
export const canExport = u => !!u && (u.is_admin || u.can_export)
export function accessLabel(u) {
  if (u.is_admin) return 'Administrator'
  const parts = []
  const inp = u.input_functions || []
  if (inp.length) parts.push(inp.length === 1 ? `Input: ${inp[0].name}` : `Input: ${inp.length} functions`)
  if (u.sees_everything) parts.push('Dashboards: whole organisation')
  else if ((u.view_functions || []).length) parts.push(u.view_functions.length === 1 ? `Dashboards: ${u.view_functions[0].name}` : `Dashboards: ${u.view_functions.length} functions`)
  return parts.join(' · ') || 'No access'
}
